@echo off

emcc -I . -I D:/wasm/include -std=c++23 -DGLM_ENABLE_EXPERIMENTAL %* ^
     D:/wasm/lib/libSDL3.a ^
     D:/wasm/lib/libSDL3_image.a ^
     D:/wasm/lib/libtiff.a ^
     D:/wasm/lib/libwebp.a ^
     D:/wasm/lib/libpng16.a ^
     D:/wasm/lib/libavif_internal.a ^
     D:/wasm/lib/libsharpyuv.a ^
     D:/wasm/lib/libzlibstatic.a ^
     D:/wasm/lib/libwebpmux.a ^
     D:/wasm/lib/libwebpdemux.a ^
     D:/wasm/lib/libdav1d.a ^
     D:/wasm/lib/libaom.a ^
     --embed-file ./assets/sdl.png@/assets/sdl.png -o SDL3WasmDemo.html
