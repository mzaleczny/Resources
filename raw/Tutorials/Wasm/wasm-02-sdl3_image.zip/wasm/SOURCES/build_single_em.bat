@echo off

emcc -I . -I D:/wasm/include -std=c++23 -DGLM_ENABLE_EXPERIMENTAL %* D:/wasm/lib/libSDL3.a -o SDL3WasmDemo.html
