@echo off

emcmake cmake -DSDLIMAGE_ZLIB=ON -DSDLIMAGE_PNG=ON -DSDLIMAGE_JPG=ON -DSDLIMAGE_VENDORED=ON -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_PREFIX_PATH="D:/wasm" -DCMAKE_INSTALL_PREFIX=D:/wasm -DSDL3_DIR="d:\wasm\lib\cmake\SDL3" -DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
cmake --build out -j8
cmake --install out
