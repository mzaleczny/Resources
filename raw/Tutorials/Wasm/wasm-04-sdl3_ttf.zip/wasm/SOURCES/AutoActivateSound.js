(function() {
    const div = document.createElement('div');
    div.id = 'audio-unlock';
    div.style.position = 'absolute';
    div.style.top = '0';
    div.style.left = '0';
    div.style.width = '100%';
    div.style.height = '100%';
    div.style.display = 'flex';
    div.style.alignItems = 'center';
    div.style.justifyContent = 'center';
    div.style.background = 'rgba(0,0,0,0.6)';
    div.style.color = 'white';
    div.style.fontSize = '32px';
    div.style.fontFamily = 'sans-serif';
    div.style.cursor = 'pointer';
    div.innerText = 'Kliknij, aby włączyć dźwięk';
    document.body.appendChild(div);
})();

document.addEventListener("click", () => {
    Module.ccall("UnlockAudio", null, [], []);
});

/*
window.addEventListener('load', function (ev) {
    Module.onRuntimeInitialized = function() {
        setTimeout(() => { console.log("START PLAY!!!!!!!!!!!!!!"); Module.ccall("UnlockAudio", null, [], []); }, 2000);
    };
});
*/