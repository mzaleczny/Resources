@echo off

emcc -I . -I D:/wasm/include -std=c++23 -DGLM_ENABLE_EXPERIMENTAL %* ^
     D:/wasm/lib/libSDL3.a ^
     D:/wasm/lib/libSDL3_mixer.a ^
     D:/wasm/lib/libSDL3_mixer.a ^
     D:/wasm/lib/libFLAC.a ^
     D:/wasm/lib/libFLAC++.a ^
     D:/wasm/lib/libmpg123.a ^
     D:/wasm/lib/libogg.a ^
     D:/wasm/lib/libvorbis.a ^
     D:/wasm/lib/libvorbisfile.a ^
     --embed-file ./assets/music.mp3@/assets/music.mp3 ^
     --embed-file ./assets/spring.wav@/assets/spring.wav ^
     -sEXPORTED_RUNTIME_METHODS=['ccall','cwrap'] ^
     -o SDL3WasmDemo.html
