@echo off

emcc -I . -I D:/wasm/include -std=c++23 -DGLM_ENABLE_EXPERIMENTAL %* ^
     D:/wasm/lib/libSDL3.a ^
     D:/wasm/lib/libSDL3_ttf.a ^
     D:/wasm/lib/libharfbuzz.a ^
     D:/wasm/lib/libfreetype.a ^
     --embed-file ./assets/allerrg.ttf@/assets/allerrg.ttf ^
     -o SDL3WasmDemo.html
