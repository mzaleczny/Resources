#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>

static SDL_Window *window = NULL;
static SDL_Renderer *renderer = NULL;
static TTF_Font* Font{};

void DrawString(SDL_Renderer* Renderer, TTF_Font* Font, const char* String, float x, float y);

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    SDL_SetAppMetadata("Example Renderer Clear", "1.0", "com.example.renderer-clear");

    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("Couldn't initialize SDL: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    if (!TTF_Init())
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "TTF_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }


    if (!SDL_CreateWindowAndRenderer("examples/renderer/clear", 640, 480, SDL_WINDOW_RESIZABLE, &window, &renderer)) {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    SDL_SetRenderLogicalPresentation(renderer, 800, 640, SDL_LOGICAL_PRESENTATION_LETTERBOX);

    std::string FontPath = "/assets/allerrg.ttf";
    Font = TTF_OpenFont(FontPath.c_str(), 64.0f);
    if (!Font)
    {
        SDL_Log("Couldn't open font [%s]: %s", FontPath.c_str(), SDL_GetError());
        return SDL_APP_FAILURE;
    }

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    if (event->type == SDL_EVENT_QUIT) {
        return SDL_APP_SUCCESS;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    const double now = ((double)SDL_GetTicks()) / 1000.0;
    const float red = (float) (0.5 + 0.5 * SDL_sin(now));
    const float green = (float) (0.5 + 0.5 * SDL_sin(now + SDL_PI_D * 2 / 3));
    const float blue = (float) (0.5 + 0.5 * SDL_sin(now + SDL_PI_D * 4 / 3));
    
    SDL_SetRenderDrawColorFloat(renderer, 0.0f, 0.0f, 0.0f, SDL_ALPHA_OPAQUE_FLOAT);
    SDL_RenderClear(renderer);
    SDL_SetRenderDrawColorFloat(renderer, red, green, blue, SDL_ALPHA_OPAQUE_FLOAT);
    DrawString(renderer, Font, "Witaj w świecie", 20.0f, 20.0f);
    DrawString(renderer, Font, "WebAssembly!", 20.0f, 90.0f);
    SDL_RenderPresent(renderer);

    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    if (Font)
    {
        TTF_CloseFont(Font);
    }
    if (window)
    {
        SDL_DestroyWindow(window);
    }
    if (renderer)
    {
        SDL_DestroyRenderer(renderer);
    }
    TTF_Quit();
    SDL_Quit();
}



void DrawString(SDL_Renderer* Renderer, TTF_Font* Font, const char* String, float x, float y)
{
    SDL_Color Color = { 255, 255, 0, 255 };
    SDL_Surface* TextSurface = TTF_RenderText_Blended(Font, String, 0, Color);
    if (TextSurface)
    {
        SDL_Texture* TextTexture = SDL_CreateTextureFromSurface(Renderer, TextSurface);
        if (TextTexture)
        {
            SDL_FRect DestRect;
            DestRect.x = x;
            DestRect.y = y;
            DestRect.w = static_cast<float>(TextTexture->w);
            DestRect.h = static_cast<float>(TextTexture->h);

            SDL_RenderTexture(Renderer, TextTexture, nullptr, &DestRect);
            SDL_DestroyTexture(TextTexture);
        }

        SDL_DestroySurface(TextSurface);
    }
}
