@echo off

cd external\ogg
emcmake cmake ^
  -DCMAKE_CXX_COMPILER=clang++ ^
  -DCMAKE_C_COMPILER=clang ^
  -DCMAKE_PREFIX_PATH=D:/wasm ^
  -DCMAKE_INSTALL_PREFIX=D:/wasm ^
  -DCMAKE_MODULE_PATH=D:/wasm/lib/cmake ^
  -S . -B out
cmake --build out -j8
copy out\libogg.a D:\wasm\lib\
cd ..\..
