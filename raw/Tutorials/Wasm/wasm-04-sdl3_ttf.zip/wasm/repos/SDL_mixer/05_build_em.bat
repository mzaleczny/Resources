@echo off

emcmake cmake ^
  -DCMAKE_CXX_COMPILER=clang++ ^
  -DCMAKE_C_COMPILER=clang ^
  -DCMAKE_PREFIX_PATH=D:/wasm ^
  -DCMAKE_INSTALL_PREFIX=D:/wasm ^
  -DCMAKE_MODULE_PATH=D:/wasm/lib/cmake ^
  -DSDL3_DIR=D:/wasm/lib/cmake/SDL3 ^
  -DOgg_DIR=D:/wasm/lib/cmake/ogg ^
  -DVorbis_DIR=D:/wasm/lib/cmake/vorbis ^
  -DVorbisFile_DIR=D:/wasm/lib/cmake/vorbisfile ^
  -Dmpg123_DIR=D:/wasm/lib/cmake/mpg123 ^
  -DFLAC_DIR=D:/wasm/lib/cmake/FLAC ^
  -DSDL3_DIR=D:/wasm/lib/cmake/SDL3 ^
  -DCMAKE_BUILD_TYPE=MinSizeRel ^
  -DCMAKE_C_FLAGS="-ID:/wasm/repos/SDL_mixer/external/mpg123/src/include -ID:/wasm/repos/SDL_mixer/external/vorbis/include -ID:/wasm/repos/SDL_mixer/external/ogg/include -ID:/wasm/repos/SDL_mixer/external/ogg/out/include" ^
  -S . -B out
cmake --build out -j8
cmake --install out
