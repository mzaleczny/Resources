@echo off

cd external\mpg123\src\libmpg123
copy d:\wasm\repos\SDL_mixer\03_build_mpg123_STUB.c stub_int123.c
copy d:\wasm\repos\SDL_mixer\03_build_mpg123_config.h ..\config.h
emcc -O3 -c -I../ -I../../ -ID:/wasm/repos/SDL_mixer/external/mpg123/src/include -ID:/wasm/repos/SDL_mixer/external/mpg123/src ^
  dct64.c ^
  format.c ^
  frame.c ^
  id3.c ^
  icy.c ^
  layer1.c ^
  layer2.c ^
  layer3.c ^
  libmpg123.c ^
  ntom.c ^
  parse.c ^
  readers.c ^
  stringbuf.c ^
  synth.c ^
  synth_8bit.c ^
  stub_int123.c ^
  tabinit.c
emar rcs libmpg123.a *.o
copy libmpg123.a D:\wasm\lib\
del *.o libmpg123.a
cd ..\..\..\..
