@echo off

cd external\flac
emcmake cmake ^
  -DCMAKE_CXX_COMPILER=clang++ ^
  -DCMAKE_C_COMPILER=clang ^
  -DCMAKE_PREFIX_PATH=D:/wasm ^
  -DCMAKE_INSTALL_PREFIX=D:/wasm ^
  -DCMAKE_MODULE_PATH=D:/wasm/lib/cmake ^
  -DOgg_DIR=D:/wasm/lib/cmake/ogg ^
  -DCMAKE_C_FLAGS="-ID:/wasm/repos/SDL_mixer/external/mpg123/src/include -ID:/wasm/repos/SDL_mixer/external/vorbis/include -ID:/wasm/repos/SDL_mixer/external/ogg/include -ID:/wasm/repos/SDL_mixer/external/ogg/out/include" ^
  -S . -B out
cmake --build out -j8
cmake --install out
cd ..\..
