@echo off

copy d:\wasm\repos\SDL_ttf\sdlttf_CMakeLists.txt CMakeLists.txt
emcmake cmake -DSDLTTF_VENDORED=OFF ^
    -DSDLTTF_HARFBUZZ_VENDORED=OFF ^
    -DSDLTTF_FREETYPE_VENDORED=OFF ^
    -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang ^
    -DCMAKE_PREFIX_PATH="D:/wasm" ^
    -DCMAKE_INSTALL_PREFIX=D:/wasm ^
    -DCMAKE_MODULE_PATH=D:/wasm/lib/cmake ^
    -DSDL3_DIR="d:\wasm\lib\cmake\SDL3" ^
    -DFreetype_DIR=D:/wasm/lib/cmake/Freetype ^
    -DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
cmake --build out -j8
cmake --install out
copy out\external\freetype-build\libfreetype.a ..\..\lib\libfreetype.a
copy out\external\harfbuzz-build\libharfbuzz.a ..\..\lib\libharfbuzz.a
copy out\external\plutosvg-guild\libplutosvg.a ..\..\lib\libplutosvg.a
copy out\external\plutovg-build\libplutovg.a ..\..\lib\libplutovg.a
