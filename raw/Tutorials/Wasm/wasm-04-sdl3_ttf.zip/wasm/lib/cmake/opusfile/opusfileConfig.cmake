set(OPUSFILE_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../include")
set(OPUSFILE_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libopusfile.a")

add_library(Opus::opusfile STATIC IMPORTED)
set_target_properties(Opus::opusfile PROPERTIES
    IMPORTED_LOCATION "${OPUSFILE_LIBRARY}"
    INTERFACE_INCLUDE_DIRECTORIES "${OPUSFILE_INCLUDE_DIR}"
)
