set(MPG123_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../repos/SDL_mixer/external/mpg123/src;${CMAKE_CURRENT_LIST_DIR}/../../../repos/SDL_mixer/external/mpg123/src/include")
set(MPG123_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libmpg123.a")

add_library(mpg123::mpg123 STATIC IMPORTED)
set_target_properties(mpg123::mpg123 PROPERTIES
    IMPORTED_LOCATION "${MPG123_LIBRARY}"
    INTERFACE_INCLUDE_DIRECTORIES "${MPG123_INCLUDE_DIR}"
)
