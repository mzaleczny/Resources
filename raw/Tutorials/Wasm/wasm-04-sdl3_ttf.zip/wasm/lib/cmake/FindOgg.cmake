set(OGG_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/ogg/../../../include")
set(OGG_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/ogg/../../../lib/libogg.a")

include("${CMAKE_CURRENT_LIST_DIR}/ogg/oggConfig.cmake")

# MODULE mode variables expected by FLAC
set(OGG_FOUND TRUE)
