set(OPUS_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../include")
set(OPUS_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libopus.a")

add_library(Opus::opus STATIC IMPORTED)
set_target_properties(Opus::opus PROPERTIES
    IMPORTED_LOCATION "${OPUS_LIBRARY}"
    INTERFACE_INCLUDE_DIRECTORIES "${OPUS_INCLUDE_DIR}"
)
