#include "PlayerSnake.h"
#include "Fruit.h"
#include "World.h"
#include <SDL3/SDL.h>

TPlayerSnake::TPlayerSnake()
{
	m_SnakeBody.front().m_Position = { 5, 5 };
}

void TPlayerSnake::Move()
{
	TSnakeSegment Head = m_SnakeBody.front();

	if (m_GrowBy > 0)
	{
		m_SnakeBody.emplace_back(0, 0);
		m_GrowBy -= 1;
	}


	TSnakeSegment Tail = m_SnakeBody.back();
	Tail.m_Position.X = Head.m_Position.X;
	Tail.m_Position.Y = Head.m_Position.Y;
	m_SnakeBody.pop_back();
	m_SnakeBody.push_front(Tail);

	auto HeadIter = m_SnakeBody.begin();

	switch (m_Direction)
	{
	case EDirection::Left:
		--HeadIter->m_Position.X;
		if (GameObject.World->XOffset > 0)
		{
			if (HeadIter->m_Position.X - GameObject.World->XOffset <= 0.25 * GameObject.World->TilesPerRow)
			{
				GameObject.World->ScrollRight();
			}
		}
		break;
	case EDirection::Right:
		++HeadIter->m_Position.X;
		if (GameObject.World->XOffset + GameObject.World->TilesPerRow < GameObject.World->WholeTilesPerRow)
		{
			if (HeadIter->m_Position.X - GameObject.World->XOffset >= 0.75 * GameObject.World->TilesPerRow)
			{
				GameObject.World->ScrollLeft();
			}
		}
		break;
	case EDirection::Up:
		--HeadIter->m_Position.Y;
		if (GameObject.World->YOffset > 0)
		{
			if (HeadIter->m_Position.Y - GameObject.World->YOffset <= 0.25 * GameObject.World->TilesPerHeight)
			{
				GameObject.World->ScrollDown();
			}
		}
		break;
	case EDirection::Down:
		++HeadIter->m_Position.Y;
		if (GameObject.World->YOffset + GameObject.World->TilesPerHeight < GameObject.World->WholeTilesPerHeight)
		{
			if (HeadIter->m_Position.Y - GameObject.World->YOffset >= 0.75 * GameObject.World->TilesPerHeight)
			{
				GameObject.World->ScrollUp();
			}
		}
		break;
	default:
		break;
	}

	if (TFruit* Fruit = GameObject.World->GetFruitAtPosition(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		GrowBy(Fruit->GetGrowByValue());
		Fruit->SetRandomPosition();
	}
	else if (TSnakeSegment* Segment = GetSegmentWithoutHead(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		Die();
	}
	else if (TSnakeSegment* Segment = GameObject.World->Enemy->GetSegmentWithoutHead(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		Die();
	}
	else if (TObstacle* Obstacle = GameObject.World->GetObstacleAtPosition(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		Die();
	}
}


SDL_AppResult TPlayerSnake::HandleEvent(SDL_Event* event)
{
	switch (event->type)
	{
	case SDL_EVENT_FINGER_DOWN:
	{
		int x = static_cast<int>(event->tfinger.x * GameObject.WindowWidth);
		int y = static_cast<int>(event->tfinger.y * GameObject.WindowHeight);
		const int Margin = 400;
		if ((x < Margin && y < Margin) || (x >= (GameObject.WindowWidth - Margin) && y < Margin))
		{
			SetDirection(EDirection::Up);
			return SDL_APP_CONTINUE;
		}
		else if ((x < Margin && y >= GameObject.WindowHeight - Margin) || (x >= (GameObject.WindowWidth - Margin) && y >= GameObject.WindowHeight - Margin))
		{
			SetDirection(EDirection::Down);
			return SDL_APP_CONTINUE;
		}
		else if (x < Margin)
		{
			SetDirection(EDirection::Left);
			return SDL_APP_CONTINUE;
		}
		else if (x >= (GameObject.WindowWidth - Margin))
		{
			SetDirection(EDirection::Right);
			return SDL_APP_CONTINUE;
		}
		return SDL_APP_SUCCESS;
	}
	case SDL_EVENT_KEY_DOWN:
		switch (event->key.key)
		{
		case SDLK_UP:
			SetDirection(EDirection::Up);
			break;
		case SDLK_DOWN:
			SetDirection(EDirection::Down);
			break;
		case SDLK_LEFT:
			SetDirection(EDirection::Left);
			break;
		case SDLK_RIGHT:
			SetDirection(EDirection::Right);
			break;
		}
	}

	return SDL_APP_CONTINUE;
}
