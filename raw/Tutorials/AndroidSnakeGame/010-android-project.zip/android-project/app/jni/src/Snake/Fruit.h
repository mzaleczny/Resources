#pragma once
#include "../Core.h"

class TFruit
{
public:
	TFruit() : m_Size(TileSize)
	{
		SetRandomPosition();
		m_DestinationRect.w = TileSize;
		m_DestinationRect.h = TileSize;
	};
	void Render(SDL_Renderer* Renderer);
	void SetRandomPosition();
	TVector2d GetPosition() const { return m_Position; };
protected:
	int m_Size;
	TVector2d m_Position;
	SDL_FRect m_DestinationRect;
};
