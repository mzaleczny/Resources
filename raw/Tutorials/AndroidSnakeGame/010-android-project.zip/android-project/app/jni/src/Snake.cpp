#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <SDL3_image/SDL_image.h>
#include "Core.h"
#include <string>
#include "Snake/Snake.h"
#include "Snake/Fruit.h"

SDL_Window* Window{};
SDL_Renderer* Renderer{};
TTF_Font* Font{};
FGameObject GameObject;


void Update(float DeltaTime);

SDL_AppResult SDL_AppInit(void** appstate, int argc, char* argv[])
{
    SDL_SetAppMetadata("Basic SDL3 App", "1.0", "com.example.MyGame");

    if (!SDL_Init(SDL_INIT_EVENTS | SDL_INIT_VIDEO))
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "SDL_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    if (!TTF_Init())
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "TTF_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    if (!SDL_CreateWindowAndRenderer("examples/MyGame", 1200, 600, 0, &Window, &Renderer))
    {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
    Font = TTF_OpenFont(FontPath.c_str(), 48.0f);
    if (!Font)
    {
        SDL_Log("Couldn't open font [%s]: %s", FontPath.c_str(), SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_GetWindowSize(Window, &GameObject.WindowWidth, &GameObject.WindowHeight);

    GameObject.TileMap = IMG_LoadTexture(Renderer, (std::string(SDL_GetBasePath()) + "snake.png").c_str());
    if (!GameObject.TileMap)
    {
        SDL_Log("Couldn't load texture [%s]: %s", (std::string(SDL_GetBasePath()) + "snake.png").c_str(), SDL_GetError());
        return SDL_APP_FAILURE;
    }

    GameObject.Snake = new TSnake();
    if (!GameObject.Snake)
    {
        SDL_Log("Couldn't create TSnake object");
        return SDL_APP_FAILURE;
    }

    GameObject.Fruit = new TFruit();
    if (!GameObject.Fruit)
    {
        SDL_Log("Couldn't create TFruit object");
        return SDL_APP_FAILURE;
    }

    GameObject.t = ((double)SDL_GetTicks()) / 1000.0;
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void* appstate, SDL_Event* event)
{
    switch (event->type)
    {
    case SDL_EVENT_QUIT:
        return SDL_APP_SUCCESS;
    case SDL_EVENT_FINGER_DOWN:
    {
        int x = event->tfinger.x * GameObject.WindowWidth;
        int y = event->tfinger.y * GameObject.WindowHeight;
        if ((x < 200 && y < 200) || (x >= (GameObject.WindowWidth - 200) && y < 200))
        {
            GameObject.Snake->SetDirection(EDirection::Up);
            return SDL_APP_CONTINUE;
        }
        else if ((x < 200 && y >= GameObject.WindowHeight - 200) || (x >= (GameObject.WindowWidth - 200) && y >= GameObject.WindowHeight - 200))
        {
            GameObject.Snake->SetDirection(EDirection::Down);
            return SDL_APP_CONTINUE;
        }
        else if (x < 200)
        {
            GameObject.Snake->SetDirection(EDirection::Left);
            return SDL_APP_CONTINUE;
        }
        else if (x >= (GameObject.WindowWidth - 200))
        {
            GameObject.Snake->SetDirection(EDirection::Right);
            return SDL_APP_CONTINUE;
        }
        return SDL_APP_SUCCESS;
    }
    case SDL_EVENT_KEY_DOWN:
        switch (event->key.key)
        {
        case SDLK_UP:
            GameObject.Snake->SetDirection(EDirection::Up);
            break;
        case SDLK_DOWN:
            GameObject.Snake->SetDirection(EDirection::Down);
            break;
        case SDLK_LEFT:
            GameObject.Snake->SetDirection(EDirection::Left);
            break;
        case SDLK_RIGHT:
            GameObject.Snake->SetDirection(EDirection::Right);
            break;
        }
    }

    return SDL_APP_CONTINUE;
}

void Update(float DeltaTime)
{
    GameObject.Snake->Update(DeltaTime);
}

SDL_AppResult SDL_AppIterate(void* appstate)
{
    double t = ((double)SDL_GetTicks()) / 1000.0;
    GameObject.DeltaTime = t - GameObject.t;

    Update(GameObject.DeltaTime);

    SDL_SetRenderDrawColorFloat(Renderer, 0.0f, 0.0f, 0.0f, SDL_ALPHA_OPAQUE_FLOAT);
    SDL_RenderClear(Renderer);

    //SDL_snprintf(GameObject.Text.data(), 254, "Witaj programisto C++! Aktualny czas: %.3f. FPS: %d", GameObject.t, static_cast<int>(GameObject.FrameCounter / GameObject.t));
    //DrawString(Renderer, GameObject.Text.c_str(), 10.0f, 10.0f);

    /*
    SDL_FRect r{ 0, 0, 200, 200 };
    SDL_SetRenderDrawColor(Renderer, 255, 0, 0, SDL_ALPHA_OPAQUE);
    SDL_RenderFillRect(Renderer, &r);
    r = { 0, static_cast<float>(GameObject.WindowHeight - 200), 200, 200 };
    SDL_SetRenderDrawColor(Renderer, 0, 255, 0, SDL_ALPHA_OPAQUE);
    SDL_RenderFillRect(Renderer, &r);
    r = { static_cast<float>(GameObject.WindowWidth - 200), 0, 200, 200 };
    SDL_SetRenderDrawColor(Renderer, 0, 0, 255, SDL_ALPHA_OPAQUE);
    SDL_RenderFillRect(Renderer, &r);
    r = { static_cast<float>(GameObject.WindowWidth - 200), static_cast<float>(GameObject.WindowHeight - 200), 200, 200 };
    SDL_SetRenderDrawColor(Renderer, 255, 255, 0, SDL_ALPHA_OPAQUE);
    SDL_RenderFillRect(Renderer, &r);
    */

    GameObject.Fruit->Render(Renderer);
    GameObject.Snake->Render(Renderer);

    SDL_RenderPresent(Renderer);

    GameObject.FrameCounter += 1;
    GameObject.t = t;
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void* appstate, SDL_AppResult result)
{
    if (GameObject.Fruit)
    {
        delete GameObject.Fruit;
    }
    if (GameObject.Snake)
    {
        delete GameObject.Snake;
    }
    if (GameObject.TileMap)
    {
        SDL_DestroyTexture(GameObject.TileMap);
    }
    if (Font)
    {
        TTF_CloseFont(Font);
    }
    if (Window)
    {
        SDL_DestroyWindow(Window);
    }
    if (Renderer)
    {
        SDL_DestroyRenderer(Renderer);
    }
    TTF_Quit();
    SDL_Quit();
}

void DrawString(SDL_Renderer* Renderer, const char* String, float x, float y)
{
    SDL_Color Color = { 255, 255, 0, 255 };
    SDL_Surface* TextSurface = TTF_RenderText_Blended(Font, String, 0, Color);
    if (TextSurface)
    {
        SDL_Texture* TextTexture = SDL_CreateTextureFromSurface(Renderer, TextSurface);
        if (TextTexture)
        {
            SDL_FRect DestRect;
            DestRect.x = x;
            DestRect.y = y;
            DestRect.w = TextTexture->w;
            DestRect.h = TextTexture->h;

            SDL_RenderTexture(Renderer, TextTexture, nullptr, &DestRect);
            SDL_DestroyTexture(TextTexture);
        }
        
        SDL_DestroySurface(TextSurface);
    }
}
