#include "Fruit.h"

void TFruit::Render(SDL_Renderer* Renderer)
{
	m_DestinationRect.x = m_Position.X * m_Size;
	m_DestinationRect.y = m_Position.Y * m_Size;
	SDL_SetRenderDrawColor(Renderer, 255, 0, 0, SDL_ALPHA_OPAQUE);
	SDL_RenderFillRect(Renderer, &m_DestinationRect);
}

void TFruit::SetRandomPosition()
{
	int MaxPosX = GameObject.WindowWidth / m_Size;
	int MaxPosY = GameObject.WindowHeight / m_Size;
	m_Position.X = SDL_randf() * MaxPosX;
	m_Position.Y = SDL_randf() * MaxPosY;
}
