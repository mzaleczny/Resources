#pragma once

#include <list>
#include <SDL3/SDL.h>
#include "../Core.h"

struct TSnakeSegment
{
	TVector2d m_Position;
	TSnakeSegment(int x, int y) : m_Position(x, y) {}
};

using TSnakeContainer = std::list<TSnakeSegment>;
enum class EDirection { None, Up, Down, Left, Right };

constexpr const SDL_FRect GetRect(int x, int y)
{
	return SDL_FRect{ static_cast<float>(x * TileSize), static_cast<float>(y * TileSize), static_cast<float>(TileSize), static_cast<float>(TileSize) };
}

class TSnake
{
public:
	TSnake();
	void Update(float DeltaTime);
	void Move();
	void Render(SDL_Renderer* Renderer);
	void SetDirection(EDirection Direction);
	void GrowBy(int Amount)
	{
		m_GrowBy += Amount;
	}
	EDirection GetNextSegmentDirection(std::list<TSnakeSegment>::iterator CurrentSegment);

protected:
	TSnakeContainer m_SnakeBody;
	int m_Size;
	EDirection m_Direction;
	float m_Speed{ 5.0f };
	float m_MoveDistance{};
	int m_GrowBy{ 10 };
	SDL_FRect m_DestinationRect;

	SDL_FRect HeadLeftRect{ GetRect(7, 4) };
	SDL_FRect HeadRightRect{ GetRect(7, 6) };
	SDL_FRect HeadUpRect{ GetRect(7, 3) };
	SDL_FRect HeadDownRect{ GetRect(7, 5) };
};
