#include "LevelStartScreen.h"
#include "LevelGame.h"
#include "../../Core.h"
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>

TLevelStartScreen::TLevelStartScreen()
{
	SnakeTex = IMG_LoadTexture(Renderer, (std::string(SDL_GetBasePath()) + "snakehead.png").c_str());
	if (!SnakeTex)
	{
		SDL_Log("Couldn't load texture [%s]: %s", (std::string(SDL_GetBasePath()) + "snakehead.png").c_str(), SDL_GetError());
		return;
	}
}

TLevelStartScreen::~TLevelStartScreen()
{
	if (SnakeTex)
	{
		SDL_DestroyTexture(SnakeTex);
	}
}

void TLevelStartScreen::Update(float DeltaTime)
{
#ifdef ANDROID
	Alpha += DeltaTime / 15.0f;
#else
	Alpha += DeltaTime / 5.0f;
#endif
	if (Alpha > 1.0f)
	{
		Alpha = 1.0f;
	}
}

void TLevelStartScreen::Render(SDL_Renderer* Renderer)
{
	DrawString(Renderer, Font, "Nowa gra", 10.0f, 10.0f);
	DrawString(Renderer, Font, "Wyjście z gry", 10.0f, 80.0f);

	SDL_FRect SourceRect{ GetRect(2, 0, 1000) };
	SourceRect.y += 200;
	SourceRect.h -= 270;
	SDL_FRect DestRect{};
	DestRect.x = GameObject.WindowWidth - 1000;
	DestRect.y = 0;
	DestRect.w = 1000;
	DestRect.h = GameObject.WindowHeight;

	SDL_SetTextureBlendMode(SnakeTex, SDL_BLENDMODE_BLEND);
	SDL_SetTextureAlphaModFloat(SnakeTex, Alpha);

	SDL_RenderTexture(Renderer, SnakeTex, &SourceRect, &DestRect);
}

SDL_AppResult TLevelStartScreen::HandleEvent(SDL_Event* event)
{
	int ChosenOption = -1;
	if (event->type == SDL_EVENT_MOUSE_BUTTON_DOWN)
	{
		if (event->button.button == SDL_BUTTON_LEFT)
		{
			ChosenOption = ChooseClickedMenuOption(event->button.x, event->button.y);
		}
	}
	else if (event->type == SDL_EVENT_FINGER_DOWN)
	{
		int x = static_cast<int>(event->tfinger.x * GameObject.WindowWidth);
		int y = static_cast<int>(event->tfinger.y * GameObject.WindowHeight);
		ChosenOption = ChooseClickedMenuOption(x, y);
	}

    if (ChosenOption == 1)
	{
		TLevel* NewLevel = new TLevelGame();
		if (NewLevel)
		{
			GameObject.LevelToSet = NewLevel;
			GameObject.LevelNumber = 1;
			GameObject.Lives = LivesAtStart;
			GameObject.Points = 0;
			GameObject.FruitsToNextLevel = 5;
			GameObject.WorldExtraSizeX = 0;
			GameObject.WorldExtraSizeY = 0;
		}
	}
    else if (ChosenOption == 2)
	{
		return SDL_APP_SUCCESS;
	}

	return SDL_APP_CONTINUE;
}

int TLevelStartScreen::ChooseClickedMenuOption(float x, float y)
{
	if (x >= 10 && x <= 400)
	{
		// Kliknieto opcję "Nowa gra"
		if (y >= 10 && y <= 80)
		{
			return 1;
		}
		// Kliknieto opcję "Wyjście z gry"
		else if (y >= 80 && y <= 150)
		{
			return 2;
		}
	}
	return -1;
}

