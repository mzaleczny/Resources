#pragma once
#include <SDL3/SDL.h>
#include <SDL3_ttf/SDL_ttf.h>
#include "../../Core.h"
#include "../Level.h"
#include "../Score.h"

class TLevelScore : public TLevel
{
public:
	TLevelScore();
	virtual ~TLevelScore();

	virtual void Update(float DeltaTime) {}
	virtual void Render(SDL_Renderer* Renderer) override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event);

protected:
	TScore m_Score;
	SDL_FRect ScoreRc{ 570, 90, 430, 400 };
	TTF_Font* m_Font{};
};
