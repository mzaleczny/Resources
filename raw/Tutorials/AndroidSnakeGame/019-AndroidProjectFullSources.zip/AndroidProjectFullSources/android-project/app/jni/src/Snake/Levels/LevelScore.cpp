#include "LevelScore.h"
#include "LevelGame.h"
#include "../../Core.h"

TLevelScore::TLevelScore()
{
	std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
	m_Font = TTF_OpenFont(FontPath.c_str(), 20.0f);
}

TLevelScore::~TLevelScore()
{
	TTF_CloseFont(m_Font);
}

void TLevelScore::Render(SDL_Renderer* Renderer)
{
	SDL_SetRenderDrawColor(Renderer, 0, 0, 0, 255);
	SDL_RenderFillRect(Renderer, &ScoreRc);
	float x = ScoreRc.x + 20;
	float y = ScoreRc.y + 20;
	for (size_t i = 0; i < m_Score.m_Items.size(); ++i)
	{
		DrawString(Renderer, m_Font, std::to_string(m_Score.m_Items[i].Lp).c_str(), x, y);
		x += 50;
		DrawString(Renderer, m_Font, m_Score.m_Items[i].Name.c_str(), x, y);
		x += 150;
		DrawString(Renderer, m_Font, std::to_string(m_Score.m_Items[i].Points).c_str(), x, y);
		x = ScoreRc.x + 20;
		y += 30;
	}
}

SDL_AppResult TLevelScore::HandleEvent(SDL_Event* event)
{
	if (event->type == SDL_EVENT_KEY_DOWN)
	{
		m_Score.Insert(rand() % 100 + 1, "Snake");
	}
	else if (event->type == SDL_EVENT_MOUSE_BUTTON_DOWN)
	{
		if (event->button.button == SDL_BUTTON_LEFT)
		{
			SDL_FPoint pt{ event->button.x, event->button.y };
			
			if (SDL_PointInRectFloat(&pt, &ScoreRc))
			{
				delete GameObject.LevelScore;
				GameObject.LevelScore = nullptr;
			}
		}
	}
	return SDL_APP_CONTINUE;
}
