#include "LevelGame.h"
#include "LevelPause.h"
#include "../World.h"
#include "../Snake.h"
#include "../../Core.h"

TLevelGame::TLevelGame()
{
    GameObject.World = new TWorld();
    GameObject.CurrentFruits = 0;
    if (!GameObject.World)
    {
        SDL_Log("Couldn't create world object");
        return;
    }
    GameObject.World->Reset();
}

TLevelGame::~TLevelGame()
{
    if (GameObject.World)
    {
        delete GameObject.World;
        GameObject.World = nullptr;
    }
}

void TLevelGame::Update(float DeltaTime)
{
    if (GameObject.LevelPause == nullptr)
    {
        GameObject.World->Update(DeltaTime);
    }
}

void TLevelGame::Render(SDL_Renderer * Renderer)
{
    GameObject.World->Render(Renderer);
    SDL_snprintf(GameObject.Text.data(), 254, "Pozostałe życia: %d,  Level: %d,  Points: %d,  Owoce: %d/%d", GameObject.Lives, GameObject.LevelNumber, GameObject.Points,
        GameObject.CurrentFruits, GameObject.FruitsToNextLevel);
    DrawString(Renderer, Font, GameObject.Text.c_str(), 10.0f, 10.0f);

    if (GameObject.LevelPause)
    {
        GameObject.LevelPause->Render(Renderer);
    }
}

SDL_AppResult TLevelGame::HandleEvent(SDL_Event * event)
{
    SDL_AppResult Result = SDL_APP_CONTINUE;
    switch (event->type)
    {
    case SDL_EVENT_KEY_DOWN:
        if (event->key.key == SDLK_P)
        {
            if (GameObject.LevelPause == nullptr)
            {
                GameObject.LevelPause = new TLevelPause();
            }
            else
            {
                delete GameObject.LevelPause;
                GameObject.LevelPause = nullptr;
            }
        }
    }

    if (GameObject.World)
    {
        Result = GameObject.World->Snake->HandleEvent(event);
    }
    return Result;
}
