#include "Score.h"
#include "../Core.h"
#include <SDL3/SDL.h>
#include <fstream>

TScore::TScore()
{
	std::string DataFile = std::string(SDL_GetBasePath()) + "score.txt";
	std::string Data;
	std::fstream File(DataFile, std::ios::in | std::ios::beg | std::ios::binary);
	size_t FileSize;

	if (File)
	{
		File.seekg(0, std::ios_base::end);
		FileSize = File.tellg();
		Data.reserve(FileSize);
		File.seekg(0, std::ios_base::beg);
		File.read(Data.data(), FileSize);
		File.close();
	}

	if (Data.length() == 0)
	{
		const char* MaleNames[] { "Paweł", "Tomasz", "Łukasz" };
		const char* FemaleNames[] { "Patrycja", "Joanna", "Małgorzata" };
		const char** Names[]{ MaleNames, FemaleNames };

		for (int i = 1; i <= 10; ++i)
		{
			int Male = rand() % 2;
			Data += std::to_string(i) + "|" + std::to_string(100 - (i - 1) * 10) + "|";
			Data += Names[Male][rand() % 3];
			Data += "\n";
		}
		File.open(DataFile, std::ios::out | std::ios::trunc | std::ios::binary);
		File.write(Data.data(), Data.length());
		File.close();
	}

	std::vector<std::string> Lines;
	std::vector<std::string> Items;
	TScoreItem Item;
	Explode('\n', Data, Lines);
	for (int i = 0; i < Lines.size(); ++i)
	{
		Explode('|', Lines[i], Items);
		if (Items.size() == 3)
		{
			Item.Lp = std::stoi(Items[0]);
			Item.Points = std::stoi(Items[1]);
			Item.Name = Items[2];
			m_Items.push_back(Item);
		}
	}
}

TScore::~TScore()
{
	m_Items.clear();
}

void TScore::Save()
{
	std::string DataFile = std::string(SDL_GetBasePath()) + "score.txt";
	std::string Data = GetDataForItems();
	std::fstream File(DataFile, std::ios::out | std::ios::trunc | std::ios::binary);
	File.write(Data.data(), Data.length());
	File.close();
}

void TScore::Insert(int Points, std::string Name)
{
	int Index = GetInsertPosition(Points);
	if (Index != -1)
	{
		TScoreItem Item;
		Item.Lp = Index + 1;
		Item.Points = Points;
		Item.Name = Name.substr(0, 25);
		for (int i = 9; i > Index; --i)
		{
			m_Items[i] = m_Items[i - 1];
			m_Items[i].Lp = i + 1;
		}
		m_Items[Index] = Item;
		Save();
	}
}

int TScore::GetInsertPosition(int Points)
{
	for (int i = 0; i < m_Items.size(); ++i)
	{
		if (Points >= m_Items[i].Points && i < 10)
		{
			return i;
		}
	}

	return -1;
}

std::string TScore::GetDataForItems()
{
	std::string Data;
	for (int i = 0; i < m_Items.size(); ++i)
	{
		Data += std::to_string(m_Items[i].Lp) + "|" + std::to_string(m_Items[i].Points) + "|";
		Data += m_Items[i].Name;
		Data += "\n";
	}
	return Data;
}
