#pragma once
#include <SDL3/SDL.h>
#include "../../Core.h"
#include "../Level.h"

class TLevelGame : public TLevel
{
public:
	TLevelGame();
	virtual ~TLevelGame();

	virtual void Update(float DeltaTime) override;
	virtual void Render(SDL_Renderer* Renderer) override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) override;
};
