#pragma once

#include <list>
#include <SDL3/SDL.h>
#include "../Core.h"
#include "Snake.h"
#include "Animation.h"

class TPlayerSnake : public TSnake
{
public:
	TPlayerSnake();
	virtual void Move() override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) override;
	virtual void Die() override;
};
