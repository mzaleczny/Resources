set(Sources 
    "${SourcesDir}/Snake.cpp" "${SourcesDir}/Core.cpp" "${SourcesDir}/Core.h"
    "${SourcesDir}/Snake/Snake.cpp" "${SourcesDir}/Snake/Snake.h"
    "${SourcesDir}/Snake/PlayerSnake.cpp" "${SourcesDir}/Snake/PlayerSnake.h"
    "${SourcesDir}/Snake/EnemySnake.cpp" "${SourcesDir}/Snake/EnemySnake.h"
    "${SourcesDir}/Snake/Fruit.cpp" "${SourcesDir}/Snake/Fruit.h"
    "${SourcesDir}/Snake/World.cpp" "${SourcesDir}/Snake/World.h"
    "${SourcesDir}/Snake/Animation.cpp" "${SourcesDir}/Snake/Animation.h"
    "${SourcesDir}/Snake/Obstacle.cpp" "${SourcesDir}/Snake/Obstacle.h"
    "${SourcesDir}/Snake/Level.cpp" "${SourcesDir}/Snake/Level.h"
    "${SourcesDir}/Snake/Levels/LevelStartScreen.cpp" "${SourcesDir}/Snake/Levels/LevelStartScreen.h"
    "${SourcesDir}/Snake/Levels/LevelGame.cpp" "${SourcesDir}/Snake/Levels/LevelGame.h"
)
