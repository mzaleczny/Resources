#include "LevelStartScreen.h"
#include "LevelGame.h"

void TLevelStartScreen::Update(float DeltaTime)
{
}

void TLevelStartScreen::Render(SDL_Renderer* Renderer)
{
	DrawString(Renderer, "Nowa gra", 10.0f, 10.0f);
	DrawString(Renderer, "Wyjście z gry", 10.0f, 80.0f);
}

SDL_AppResult TLevelStartScreen::HandleEvent(SDL_Event* event)
{
	int ChosenOption = -1;
	if (event->type == SDL_EVENT_MOUSE_BUTTON_DOWN)
	{
		if (event->button.button == SDL_BUTTON_LEFT)
		{
			ChosenOption = ChooseClickedMenuOption(event->button.x, event->button.y);
		}
	}
	else if (event->type == SDL_EVENT_FINGER_DOWN)
	{
		int x = static_cast<int>(event->tfinger.x * GameObject.WindowWidth);
		int y = static_cast<int>(event->tfinger.y * GameObject.WindowHeight);
		ChosenOption = ChooseClickedMenuOption(x, y);
	}

    if (ChosenOption == 1)
	{
		TLevel* NewLevel = new TLevelGame();
		if (NewLevel)
		{
			GameObject.LevelToSet = NewLevel;
		}
	}
    else if (ChosenOption == 2)
	{
		return SDL_APP_SUCCESS;
	}

	return SDL_APP_CONTINUE;
}

int TLevelStartScreen::ChooseClickedMenuOption(float x, float y)
{
	if (x >= 10 && x <= 400)
	{
		// Kliknieto opcję "Nowa gra"
		if (y >= 10 && y <= 80)
		{
			return 1;
		}
		// Kliknieto opcję "Wyjście z gry"
		else if (y >= 80 && y <= 150)
		{
			return 2;
		}
	}
	return -1;
}

