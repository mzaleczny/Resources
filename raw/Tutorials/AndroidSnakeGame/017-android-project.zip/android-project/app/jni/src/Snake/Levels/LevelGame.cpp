#include "LevelGame.h"
#include "../World.h"
#include "../Snake.h"

TLevelGame::TLevelGame()
{
    GameObject.Lives = LivesAtStart;
    GameObject.World = new TWorld();
    if (!GameObject.World)
    {
        SDL_Log("Couldn't create world object");
        return;
    }
    GameObject.World->Reset();
}

TLevelGame::~TLevelGame()
{
    if (GameObject.World)
    {
        delete GameObject.World;
        GameObject.World = nullptr;
    }
}

void TLevelGame::Update(float DeltaTime)
{
    GameObject.World->Update(DeltaTime);
}

void TLevelGame::Render(SDL_Renderer * Renderer)
{
    GameObject.World->Render(Renderer);
    SDL_snprintf(GameObject.Text.data(), 254, "Pozostałe życia: %d", GameObject.Lives);
    DrawString(Renderer, GameObject.Text.c_str(), 10.0f, 10.0f);
}

SDL_AppResult TLevelGame::HandleEvent(SDL_Event * event)
{
    SDL_AppResult Result = SDL_APP_CONTINUE;
    if (GameObject.World)
    {
        Result = GameObject.World->Snake->HandleEvent(event);
    }
    return Result;
}
