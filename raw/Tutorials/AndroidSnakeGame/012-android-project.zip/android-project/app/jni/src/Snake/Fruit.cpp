#include "Fruit.h"
#include "World.h"

void TFruit::Render(SDL_Renderer* Renderer)
{
	m_DestinationRect.x = static_cast<float>(m_Position.X * m_Size);
	m_DestinationRect.y = static_cast<float>(m_Position.Y * m_Size);
	SDL_SetRenderDrawColor(Renderer, 255, 0, 0, SDL_ALPHA_OPAQUE);
	SDL_RenderFillRect(Renderer, &m_DestinationRect);
}

void TFruit::SetRandomPosition()
{
	int MaxPosX = GameObject.WindowWidth / m_Size - 1;
	int MaxPosY = GameObject.WindowHeight / m_Size - 1;
	int X, Y;

	do
	{
		X = static_cast<int>(SDL_randf() * MaxPosX);
		Y = static_cast<int>(SDL_randf() * MaxPosY);
	} while (!GameObject.World->IsFieldAvaialable(X, Y));

	m_Position.X = X;
	m_Position.Y = Y;
}

bool TFruit::IsOccupiedByFruit(int X, int Y)
{
	if (m_Position.X == X && m_Position.Y == Y)
	{
		return true;
	}

	return false;
}
