#pragma once

#include <SDL3/SDL.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>

extern SDL_Window* Window;
extern SDL_Renderer* Renderer;
extern TTF_Font* Font;

#ifdef ANDROID
constexpr const int TileScale = 4;
constexpr const int TileSize = 16 * TileScale;
#else
constexpr const int TileScale = 2;
constexpr const int TileSize = 16 * TileScale;
#endif

struct TVector2d
{
    int X;
    int Y;
    TVector2d(int x = 0, int y = 0) : X(x), Y(y) {}
};

class TWorld;

struct FGameObject
{
    double t{};
    float DeltaTime{};
    long long int FrameCounter{ 0 };
    std::string Text{ std::string(255, '\0') };
    SDL_Texture* TileMap{};
    TWorld* World{};
    int WindowWidth{};
    int WindowHeight{};
};
extern FGameObject GameObject;

constexpr const SDL_FRect GetRect(int x, int y)
{
    return SDL_FRect{ static_cast<float>(x * TileSize), static_cast<float>(y * TileSize), static_cast<float>(TileSize), static_cast<float>(TileSize) };
}

void DrawString(SDL_Renderer* Renderer, const char* String, float x, float y);
