#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>
#include "Snake/Snake.h"

SDL_Window* Window{};
SDL_Renderer* Renderer{};
TTF_Font* Font{};

struct FGameObject
{
    double t{};
    float DeltaTime;
    long long int FrameCounter{ 0 };
    std::string Text{ std::string(255, '\0') };
    TSnake Snake{ TSnake(32) };
} GameObject;


void DrawString(SDL_Renderer* Renderer, const char* String, float x, float y);
void Update(float DeltaTime);

SDL_AppResult SDL_AppInit(void** appstate, int argc, char* argv[])
{
    SDL_SetAppMetadata("Basic SDL3 App", "1.0", "com.example.MyGame");

    if (!SDL_Init(SDL_INIT_EVENTS | SDL_INIT_VIDEO))
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "SDL_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    if (!TTF_Init())
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "TTF_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    if (!SDL_CreateWindowAndRenderer("examples/MyGame", 640, 480, 0, &Window, &Renderer))
    {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }
    std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
    Font = TTF_OpenFont(FontPath.c_str(), 26.0f);
    if (!Font)
    {
        SDL_Log("Couldn't open font [%s]: %s", FontPath.c_str(), SDL_GetError());
        return SDL_APP_FAILURE;
    }

    GameObject.t = ((double)SDL_GetTicks()) / 1000.0;
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void* appstate, SDL_Event* event)
{
    switch (event->type)
    {
    case SDL_EVENT_QUIT:
    case SDL_EVENT_FINGER_UP:
        return SDL_APP_SUCCESS;
    }

    return SDL_APP_CONTINUE;
}

void Update(float DeltaTime)
{
    GameObject.Snake.Update(DeltaTime);
}

SDL_AppResult SDL_AppIterate(void* appstate)
{
    double t = ((double)SDL_GetTicks()) / 1000.0;
    GameObject.DeltaTime = t - GameObject.t;

    Update(GameObject.DeltaTime);

    SDL_SetRenderDrawColorFloat(Renderer, 0.0f, 0.0f, 0.0f, SDL_ALPHA_OPAQUE_FLOAT);
    SDL_RenderClear(Renderer);

    SDL_snprintf(GameObject.Text.data(), 254, "Aktualny czas: %.3f. FPS: %d", GameObject.t, static_cast<int>(GameObject.FrameCounter / GameObject.t));
    DrawString(Renderer, GameObject.Text.c_str(), 10.0f, 10.0f);

    GameObject.Snake.Render(Renderer);

    SDL_RenderPresent(Renderer);

    GameObject.FrameCounter += 1;
    GameObject.t = t;
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void* appstate, SDL_AppResult result)
{
    if (Font)
    {
        TTF_CloseFont(Font);
    }
    if (Window)
    {
        SDL_DestroyWindow(Window);
    }
    if (Renderer)
    {
        SDL_DestroyRenderer(Renderer);
    }
    TTF_Quit();
    SDL_Quit();
}

void DrawString(SDL_Renderer* Renderer, const char* String, float x, float y)
{
    SDL_Color Color = { 255, 255, 0, 255 };
    SDL_Surface* TextSurface = TTF_RenderText_Blended(Font, String, 0, Color);
    if (TextSurface)
    {
        SDL_Texture* TextTexture = SDL_CreateTextureFromSurface(Renderer, TextSurface);
        if (TextTexture)
        {
            SDL_FRect DestRect;
            DestRect.x = x;
            DestRect.y = y;
            DestRect.w = TextTexture->w;
            DestRect.h = TextTexture->h;

            SDL_RenderTexture(Renderer, TextTexture, nullptr, &DestRect);
            SDL_DestroyTexture(TextTexture);
        }
        SDL_DestroySurface(TextSurface);
    }
}
