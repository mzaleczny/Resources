#include "Snake.h"

TSnake::TSnake(int BlockSize)
	: m_Size(BlockSize)
{
	m_SnakeBody.emplace_back(5, 5);
	m_Direction = EDirection::Right;

	m_DestinationRect.w = m_Size;
	m_DestinationRect.h = m_Size;
}

void TSnake::Update(float DeltaTime)
{
	if (m_SnakeBody.empty() || m_Direction == EDirection::None)
	{
		return;
	}

	m_MoveDistance += DeltaTime * m_Speed;
	if (m_MoveDistance >= 1.0f)
	{
		Move();
		m_MoveDistance -= 1.0f;
	}
}

void TSnake::Move()
{
	switch (m_Direction)
	{
	case EDirection::Left:
		--m_SnakeBody.begin()->m_Position.X;
		break;
	case EDirection::Right:
		++m_SnakeBody.begin()->m_Position.X;
		break;
	case EDirection::Up:
		--m_SnakeBody.begin()->m_Position.Y;
		break;
	case EDirection::Down:
		++m_SnakeBody.begin()->m_Position.Y;
		break;
	default:
		break;
	}
}

void TSnake::Render(SDL_Renderer* Renderer)
{
	if (m_SnakeBody.empty())
	{
		return;
	}

	auto SegmentIter = m_SnakeBody.begin();
	m_DestinationRect.x = SegmentIter->m_Position.X * m_Size;
	m_DestinationRect.y = SegmentIter->m_Position.Y * m_Size;
	SDL_SetRenderDrawColor(Renderer, 255, 255, 0, SDL_ALPHA_OPAQUE);
	SDL_RenderFillRect(Renderer, &m_DestinationRect);
}
