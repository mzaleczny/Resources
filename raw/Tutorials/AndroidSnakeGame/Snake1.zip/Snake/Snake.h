#pragma once

#include <list>
#include <SDL3/SDL.h>

struct TVector2d
{
	int X;
	int Y;
	TVector2d(int x, int y) : X(x), Y(y) {}
};

struct TSnakeSegment
{
	TVector2d m_Position;
	TSnakeSegment(int x, int y) : m_Position(x, y) {}
};

using TSnakeContainer = std::list<TSnakeSegment>;
enum class EDirection { None, Up, Down, Left, Right };


class TSnake
{
public:
	TSnake(int BlockSize);
	void Update(float DeltaTime);
	void Move();
	void Render(SDL_Renderer* Renderer);

protected:
	TSnakeContainer m_SnakeBody;
	int m_Size;
	EDirection m_Direction;
	float m_Speed{ 5.0f };
	float m_MoveDistance{};

	SDL_FRect m_DestinationRect;
};
