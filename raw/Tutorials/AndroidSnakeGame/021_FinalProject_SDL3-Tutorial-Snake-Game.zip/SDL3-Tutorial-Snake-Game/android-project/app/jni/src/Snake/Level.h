#pragma once
#include <SDL3/SDL.h>
#include "../Core.h"

class TLevel
{
public:
	TLevel() {};
	virtual ~TLevel() {};

	virtual void Update(float DeltaTime) = 0;
	virtual void Render(SDL_Renderer* Renderer) = 0;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) = 0;
};