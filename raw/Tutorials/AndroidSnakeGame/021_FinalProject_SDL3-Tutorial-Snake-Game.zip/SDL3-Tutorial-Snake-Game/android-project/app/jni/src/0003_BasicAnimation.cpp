#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

struct FGameObject
{
    float red{};
    float green{};
    float blue{};
} GameObject;

SDL_Window *Window{};
SDL_Renderer *Renderer{};

void Update();

SDL_AppResult SDL_AppInit(void** appstate, int argc, char* argv[])
{
    SDL_SetAppMetadata("Basic SDL3 App", "1.0", "com.example.001_BasicSDL3App");

    if (!SDL_Init(SDL_INIT_EVENTS | SDL_INIT_VIDEO))
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "SDL_Init failed (%s)", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    if (!SDL_CreateWindowAndRenderer("examples/001_BasicOldFashionedApp", 640, 480, 0, &Window, &Renderer))
    {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void* appstate, SDL_Event* event)
{
    switch (event->type)
    {
    case SDL_EVENT_QUIT:
    case SDL_EVENT_FINGER_UP:
        SDL_Log("0003_BasicAnimation: Exit requested by user");
        return SDL_APP_SUCCESS;
    }

    return SDL_APP_CONTINUE;
}

void Update()
{
    const double now = ((double)SDL_GetTicks()) / 1000.0;
    GameObject.red = (float)(0.5 + 0.5 * SDL_sin(now));
    GameObject.green = (float)(0.5 + 0.5 * SDL_sin(now + SDL_PI_D * 2 / 3));
    GameObject.blue = (float)(0.5 + 0.5 * SDL_sin(now + SDL_PI_D * 4 / 3));
}

SDL_AppResult SDL_AppIterate(void* appstate)
{
    Update();

    SDL_SetRenderDrawColorFloat(Renderer, GameObject.red, GameObject.green, GameObject.blue, SDL_ALPHA_OPAQUE_FLOAT);
    SDL_RenderClear(Renderer);
    SDL_RenderPresent(Renderer);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void* appstate, SDL_AppResult result)
{
    if (Window)
    {
        SDL_DestroyWindow(Window);
    }
    if (Renderer)
    {
        SDL_DestroyRenderer(Renderer);
    }
    SDL_Quit();
}
