#pragma once

#include <string>
#include <vector>

struct TScoreItem
{
	int Lp;
	int Points;
	std::string Name;
};


class TScore
{
public:
	TScore();
	~TScore();
	std::vector<TScoreItem> m_Items;

	void Save();
	void Insert(int Points, std::string Name);
	int GetInsertPosition(int Points);

protected:
	std::string GetDataForItems();
};
