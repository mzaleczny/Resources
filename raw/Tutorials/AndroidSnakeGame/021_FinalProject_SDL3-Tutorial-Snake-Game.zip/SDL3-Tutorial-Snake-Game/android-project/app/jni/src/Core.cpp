#include "Core.h"

void DrawString(SDL_Renderer* Renderer, TTF_Font* Font, const char* String, float x, float y, SDL_Color Color)
{
    SDL_Surface* TextSurface = TTF_RenderText_Blended(Font, String, 0, Color);
    if (TextSurface)
    {
        SDL_Texture* TextTexture = SDL_CreateTextureFromSurface(Renderer, TextSurface);
        if (TextTexture)
        {
            SDL_FRect DestRect;
            DestRect.x = x;
            DestRect.y = y;
            DestRect.w = static_cast<float>(TextTexture->w);
            DestRect.h = static_cast<float>(TextTexture->h);

            SDL_RenderTexture(Renderer, TextTexture, nullptr, &DestRect);
            SDL_DestroyTexture(TextTexture);
        }

        SDL_DestroySurface(TextSurface);
    }
}

SDL_Texture* ScaleTexture(SDL_Renderer* Renderer, SDL_Texture* SourceTexture, float ScaleFactor)
{
    SDL_Texture* ScaledTexture = SDL_CreateTexture(Renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_TARGET, SourceTexture->w * ScaleFactor, SourceTexture->h * ScaleFactor);
    if (!ScaledTexture)
    {
        SDL_Log("Couldn't create texture: %s", SDL_GetError());
        return nullptr;
    }
    SDL_SetRenderTarget(Renderer, ScaledTexture);
    SDL_RenderTexture(Renderer, SourceTexture, nullptr, nullptr);
    SDL_SetRenderTarget(Renderer, nullptr);
    return ScaledTexture;
}

void GetTextSize(TTF_Font* Font, const char* String, int& Width, int& Height)
{
    Width = 0;
    Height = 0;

    if (TTF_TextEngine* Engine = TTF_CreateSurfaceTextEngine())
    {
        if (TTF_Text* Text = TTF_CreateText(Engine, Font, String, 0))
        {
            TTF_GetTextSize(Text, &Width, &Height);
            TTF_DestroyText(Text);
        }
        TTF_DestroySurfaceTextEngine(Engine);
    }
}

void Explode(char ExplodeChar, const std::string& Text, std::vector<std::string>& Items)
{
    std::string CurrentString;
    const char* String = Text.c_str();
    Items.clear();
    for (size_t i = 0; i < Text.length(); ++i)
    {
        if (String[i] == ExplodeChar)
        {
            Items.push_back(CurrentString);
            CurrentString = "";
        }
        else
        {
            CurrentString += String[i];
        }
    }
    if (!CurrentString.empty())
    {
        Items.push_back(CurrentString);
    }
}
