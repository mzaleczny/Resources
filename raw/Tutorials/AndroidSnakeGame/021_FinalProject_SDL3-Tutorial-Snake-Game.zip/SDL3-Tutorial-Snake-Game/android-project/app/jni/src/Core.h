#pragma once

#include <SDL3/SDL.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>
#include <vector>

extern SDL_Window* Window;
extern SDL_Renderer* Renderer;
extern TTF_Font* Font;

#ifdef ANDROID
constexpr const int TilePadding = 2;
constexpr const int TileScale = 4;
constexpr const int TileSize = 16 * TileScale;
#else
constexpr const int TilePadding = 1;
constexpr const int TileScale = 2;
constexpr const int TileSize = 16 * TileScale;
#endif

constexpr const int LivesAtStart = 3;

struct TVector2d
{
    int X;
    int Y;
    TVector2d(int x = 0, int y = 0) : X(x), Y(y) {}
};

class TWorld;
class TLevel;

struct FGameObject
{
    double t{};
    float DeltaTime{};
    long long int FrameCounter{ 0 };
    std::string Text{ std::string(255, '\0') };
    SDL_Texture* TileMap{};
    SDL_Texture* FruitsTileMap{};
    TWorld* World{};
    int WindowWidth{};
    int WindowHeight{};
    MIX_Mixer* Mixer{};
    MIX_Track* Track{};
    MIX_Audio* Audio{};
    TLevel* Level{};
    TLevel* LevelToSet{};
    TLevel* LevelPause{};
    TLevel* LevelScore{};
    int Lives{ 3 };
    int Points{};
    int LevelNumber{1};
    int FruitsToNextLevel{ 5 };
    int CurrentFruits{};
    int WorldExtraSizeX{};
    int MaxWorldExtraSizeX{50};
    int WorldExtraSizeY{};
    int MaxWorldExtraSizeY{50};
    bool PromoteToNextLevel{};
};
extern FGameObject GameObject;

constexpr const SDL_FRect GetRect(int x, int y)
{
    return SDL_FRect{ static_cast<float>(x * TileSize + TilePadding), static_cast<float>(y * TileSize + TilePadding), static_cast<float>(TileSize - 2*TilePadding), static_cast<float>(TileSize - 2*TilePadding) };
}
constexpr const SDL_FRect GetRect(int x, int y, int TileSize)
{
    return SDL_FRect{ static_cast<float>(x * TileSize + TilePadding), static_cast<float>(y * TileSize + TilePadding), static_cast<float>(TileSize - 2*TilePadding), static_cast<float>(TileSize - 2*TilePadding) };
}

void DrawString(SDL_Renderer* Renderer, TTF_Font* Font, const char* String, float x, float y, SDL_Color Color = SDL_Color{255, 255, 0, 255});
SDL_Texture* ScaleTexture(SDL_Renderer* Renderer, SDL_Texture* SourceTexture, float ScaleFactor);
void GetTextSize(TTF_Font* Font, const char* String, int& Width, int& Height);
void Explode(char ExplodeChar, const std::string& Text, std::vector<std::string>& Items);
