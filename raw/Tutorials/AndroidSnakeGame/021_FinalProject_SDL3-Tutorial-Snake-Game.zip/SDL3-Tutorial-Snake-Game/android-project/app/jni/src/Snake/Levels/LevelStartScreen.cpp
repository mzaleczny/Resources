#include "LevelStartScreen.h"
#include "LevelScore.h"
#include "LevelGame.h"
#include "../../Core.h"
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>

TLevelStartScreen::TLevelStartScreen()
{
	SnakeTex = IMG_LoadTexture(Renderer, (std::string(SDL_GetBasePath()) + "snakehead.png").c_str());
	if (!SnakeTex)
	{
		SDL_Log("Couldn't load texture [%s]: %s", (std::string(SDL_GetBasePath()) + "snakehead.png").c_str(), SDL_GetError());
		return;
	}
	std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
#ifdef ANDROID
	m_Font = TTF_OpenFont(FontPath.c_str(), 96.0f);
#else
	m_Font = TTF_OpenFont(FontPath.c_str(), 48.0f);
#endif
}

TLevelStartScreen::~TLevelStartScreen()
{
	if (SnakeTex)
	{
		SDL_DestroyTexture(SnakeTex);
	}
	if (m_Font)
	{
		TTF_CloseFont(m_Font);
	}
}

void TLevelStartScreen::Update(float DeltaTime)
{
#ifdef ANDROID
	Alpha += DeltaTime / 15.0f;
#else
	Alpha += DeltaTime / 5.0f;
#endif
	if (Alpha > 1.0f)
	{
		Alpha = 1.0f;
	}
}

void TLevelStartScreen::Render(SDL_Renderer* Renderer)
{
	int y = 10;
	DrawString(Renderer, m_Font, "Nowa gra", 10.0f, y);
	y += m_LineHeight;
	DrawString(Renderer, m_Font, "Top Ten", 10.0f, y);
	y += m_LineHeight;
	DrawString(Renderer, m_Font, "Wyjście z gry", 10.0f, y);

	SDL_FRect SourceRect{ GetRect(2, 0, 1000) };
	SourceRect.y += 200;
	SourceRect.h -= 270;
	SDL_FRect DestRect{};
	DestRect.y = 0;
#ifdef ANDROID
	DestRect.w = 1.5 * GameObject.WindowHeight;
	DestRect.x = GameObject.WindowWidth - DestRect.w + 100;
#else
	DestRect.w = 1000;
	DestRect.x = GameObject.WindowWidth - 900;
#endif
	DestRect.h = GameObject.WindowHeight;

	SDL_SetTextureBlendMode(SnakeTex, SDL_BLENDMODE_BLEND);
	SDL_SetTextureAlphaModFloat(SnakeTex, Alpha);

	SDL_RenderTexture(Renderer, SnakeTex, &SourceRect, &DestRect);

	if (GameObject.LevelScore)
	{
		GameObject.LevelScore->Render(Renderer);
	}
}

SDL_AppResult TLevelStartScreen::HandleEvent(SDL_Event* event)
{
	int ChosenOption = -1;

	if (GameObject.LevelScore)
	{
		return GameObject.LevelScore->HandleEvent(event);
	}

	if (event->type == SDL_EVENT_MOUSE_BUTTON_DOWN)
	{
		if (event->button.button == SDL_BUTTON_LEFT)
		{
			ChosenOption = ChooseClickedMenuOption(event->button.x, event->button.y);
		}
	}
	else if (event->type == SDL_EVENT_FINGER_DOWN)
	{
		int x = static_cast<int>(event->tfinger.x * GameObject.WindowWidth);
		int y = static_cast<int>(event->tfinger.y * GameObject.WindowHeight);
		ChosenOption = ChooseClickedMenuOption(x, y);
	}

    if (ChosenOption == 1)
	{
		TLevel* NewLevel = new TLevelGame();
		if (NewLevel)
		{
			GameObject.LevelToSet = NewLevel;
			GameObject.LevelNumber = 1;
			GameObject.Lives = LivesAtStart;
			GameObject.Points = 0;
			GameObject.FruitsToNextLevel = 5;
			GameObject.WorldExtraSizeX = 0;
			GameObject.WorldExtraSizeY = 0;
		}
	}
    else if (ChosenOption == 2)
	{
		GameObject.LevelScore = new TLevelScore();
	}
    else if (ChosenOption == 3)
	{
		return SDL_APP_SUCCESS;
	}

	return SDL_APP_CONTINUE;
}

int TLevelStartScreen::ChooseClickedMenuOption(float x, float y)
{
	float StartY = 10;
	if (x >= 10 && x <= 700)
	{
		// Kliknieto opcję "Nowa gra"
		if (y >= 10 && y <= StartY + m_LineHeight )
		{
			return 1;
		}
		// Kliknieto opcję "Top Ten"
		else if (y >= 80 && y <= StartY + m_LineHeight + m_LineHeight)
		{
			return 2;
		}
		// Kliknieto opcję "Wyjście z gry"
		else if (y >= 150 && y <= StartY + m_LineHeight + m_LineHeight + m_LineHeight)
		{
			return 3;
		}
	}
	return -1;
}

