#include "LevelGame.h"
#include "LevelPause.h"
#include "LevelStartScreen.h"
#include "../World.h"
#include "../Snake.h"
#include "../../Core.h"
#include "../Score.h"
#include <SDL3_image/SDL_image.h>
TLevelGame::TLevelGame()
{
    m_EnterNameTexture = IMG_LoadTexture(Renderer, (std::string(SDL_GetBasePath()) + "EnterName.png").c_str());
    if (!GameObject.TileMap)
    {
        SDL_Log("Couldn't load texture [%s]: %s", (std::string(SDL_GetBasePath()) + "EnterName.png").c_str(), SDL_GetError());
        return;
    }

    std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
#ifdef ANDROID
    m_Font = TTF_OpenFont(FontPath.c_str(), 50.0f);
#else
    m_Font = TTF_OpenFont(FontPath.c_str(), 20.0f);
#endif

    GameObject.World = new TWorld();
    GameObject.CurrentFruits = 0;
    if (!GameObject.World)
    {
        SDL_Log("Couldn't create world object");
        return;
    }
    GameObject.World->Reset();
}

TLevelGame::~TLevelGame()
{
    if (m_Font)
    {
        TTF_CloseFont(m_Font);
    }
    if (m_EnterNameTexture)
    {
        SDL_DestroyTexture(m_EnterNameTexture);
        m_EnterNameTexture = nullptr;
    }
    if (GameObject.World)
    {
        delete GameObject.World;
        GameObject.World = nullptr;
    }
}

void TLevelGame::Update(float DeltaTime)
{
    if (GameObject.LevelPause == nullptr && m_EnterName == false)
    {
        GameObject.World->Update(DeltaTime);
    }
}

void TLevelGame::Render(SDL_Renderer* Renderer)
{
    GameObject.World->Render(Renderer);
    SDL_snprintf(GameObject.Text.data(), 254, "Pozostałe życia: %d,  Level: %d,  Points: %d,  Owoce: %d/%d", GameObject.Lives, GameObject.LevelNumber, GameObject.Points,
        GameObject.CurrentFruits, GameObject.FruitsToNextLevel);
    DrawString(Renderer, Font, GameObject.Text.c_str(), 10.0f, 10.0f);

    if (GameObject.LevelPause)
    {
        GameObject.LevelPause->Render(Renderer);
    }

    if (m_EnterNameTexture && m_EnterName && m_Position >= 0 && m_Position <= 9)
    {
        int TextWidth, TextHeight;
        float w, h;
#ifdef ANDROID
        w = m_EnterNameTexture->w;
        h = m_EnterNameTexture->h;

        SDL_FRect DestRect{
            (GameObject.WindowWidth - m_EnterNameTexture->w) / 2.0f,
            (GameObject.WindowHeight - m_EnterNameTexture->h) / 2.0f,
            static_cast<float>(m_EnterNameTexture->w),
            static_cast<float>(m_EnterNameTexture->h)
        };
#else
        w = 800.0f;
        h = 534.0f;
        SDL_FRect DestRect{
            (GameObject.WindowWidth - 800) / 2.0f,
            (GameObject.WindowHeight - 534) / 2.0f,
            800.0f,
            534.0f
        };
#endif
        SDL_RenderTexture(Renderer, m_EnterNameTexture, nullptr, &DestRect);
        GetTextSize(m_Font, m_Name.c_str(), TextWidth, TextHeight);
        float x = (GameObject.WindowWidth - TextWidth) / 2.0f;
        float y = (GameObject.WindowHeight - TextHeight) / 2.0f;
#ifdef ANDROID
        DrawString(Renderer, m_Font, m_Name.c_str(), x, y - 38, { 0, 0, 0, 255 });
        OkRect = { x - 120, y + 60, 380.0f, 110.0f };
#else
        DrawString(Renderer, m_Font, m_Name.c_str(), x, y - 20, { 0, 0, 0, 255 });
        OkRect = { x - 100, y + 25, 180.0f, 48.0f };
#endif
        //SDL_FRect Tmp{ x - 120, y + 60, 380.0f, 110.0f };
        //SDL_SetRenderDrawColor(Renderer, 255, 255, 255, 255);
        //SDL_RenderFillRect(Renderer, &Tmp);
    }
}

SDL_AppResult TLevelGame::HandleEvent(SDL_Event * event)
{
    int x, y;
    const int Margin = 400;
    SDL_AppResult Result = SDL_APP_CONTINUE;


    switch (event->type)
    {
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (m_EnterName)
        {
            SDL_FPoint pt;
            pt.x = event->button.x;
            pt.y = event->button.y;
            if (event->button.button == SDL_BUTTON_LEFT && SDL_PointInRectFloat(&pt, &OkRect))
            {
                DoAcceptEneteredName();
            }
        }
        break;
    case SDL_EVENT_FINGER_DOWN:
        if (m_EnterName == false)
        {
            x = static_cast<int>(event->tfinger.x * GameObject.WindowWidth);
            y = static_cast<int>(event->tfinger.y * GameObject.WindowHeight);
            if ((x < Margin) || (x >= GameObject.WindowWidth - Margin))
            {
                break;
            }
            DoPauseGame();
            /*
            GameObject.Lives = 0;
            GameObject.Points = 75;
            GameObject.World->Snake->Die();
            */
        }
        else
        {
            SDL_FPoint pt;
            pt.x = event->tfinger.x;
            pt.y = event->tfinger.x;
            if (event->button.button == SDL_BUTTON_LEFT && SDL_PointInRectFloat(&pt, &OkRect))
            {
                DoAcceptEneteredName();
            }
        }
        return Result;
    case SDL_EVENT_KEY_DOWN:
        if (m_EnterName == false)
        {
            if (event->key.key == SDLK_P)
            {
                DoPauseGame();
                return Result;
            }
        }
        else
        {
            if (event->key.key == SDLK_BACKSPACE)
            {
                m_Name = m_Name.substr(0, m_Name.length() - 1);
            }
            else if (event->key.key == SDLK_RETURN)
            {
                DoAcceptEneteredName();
            }
        }
        break;
    case SDL_EVENT_TEXT_INPUT:
        if (m_EnterName)
        {
            if (m_Name.length() < 10)
            {
                m_Name.push_back(event->text.text[0]);
            }
        }
        break;
    }

    if (GameObject.World)
    {
        Result = GameObject.World->Snake->HandleEvent(event);
    }

    return Result;
}

void TLevelGame::DoPauseGame()
{
    if (GameObject.LevelPause == nullptr)
    {
        GameObject.LevelPause = new TLevelPause();
    }
    else
    {
        delete GameObject.LevelPause;
        GameObject.LevelPause = nullptr;
    }
}

void TLevelGame::DoEnterName()
{
    TScore Score;

    m_Position = Score.GetInsertPosition(GameObject.Points);
    if (m_Position >= 0 && m_Position <= 9)
    {
        m_EnterName = true;
#ifdef ANDROID
        m_Name = "Android";
#else
        SDL_StartTextInput(Window);
#endif
    }
    else
    {
        TLevel* NewLevel = new TLevelStartScreen();
        if (NewLevel)
        {
            GameObject.LevelToSet = NewLevel;
        }
    }
}

void TLevelGame::DoAcceptEneteredName()
{
    TScore Score;
    Score.Insert(GameObject.Points, m_Name);
    TLevel* NewLevel = new TLevelStartScreen();
    if (NewLevel)
    {
        GameObject.LevelToSet = NewLevel;
    }
}
