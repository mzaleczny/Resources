#include "LevelPause.h"
#include "LevelGame.h"
#include "../../Core.h"

TLevelPause::TLevelPause()
{
	std::string FontPath = std::string(SDL_GetBasePath()) + "allerrg.ttf";
#ifdef ANDROID
	m_Font = TTF_OpenFont(FontPath.c_str(), 120.0f);
#else
	m_Font = TTF_OpenFont(FontPath.c_str(), 60.0f);
#endif

	int Width, Height;
	GetTextSize(m_Font, "Pauza", Width, Height);
	m_TextPositionX = static_cast<int>((GameObject.WindowWidth - Width) / 2.0);
	m_TextPositionY = static_cast<int>((GameObject.WindowHeight - Height) / 2.0);

	TexPause = SDL_CreateTexture(Renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_TARGET, GameObject.WindowWidth, GameObject.WindowHeight);
}

TLevelPause::~TLevelPause()
{
	if (TexPause)
	{
		SDL_DestroyTexture(TexPause);
	}
	if (m_Font)
	{
		TTF_CloseFont(m_Font);
	}
}

void TLevelPause::Render(SDL_Renderer* Renderer)
{
	SDL_SetRenderTarget(Renderer, TexPause);

	SDL_SetTextureBlendMode(TexPause, SDL_BLENDMODE_BLEND);
	SDL_SetTextureAlphaModFloat(TexPause, 0.5f);

	SDL_SetRenderDrawColor(Renderer, 0, 0, 0, 255);
	SDL_RenderClear(Renderer);
	DrawString(Renderer, m_Font, "Pauza", m_TextPositionX, m_TextPositionY);

	SDL_SetRenderTarget(Renderer, nullptr);
	SDL_RenderTexture(Renderer, TexPause, nullptr, nullptr);
}
