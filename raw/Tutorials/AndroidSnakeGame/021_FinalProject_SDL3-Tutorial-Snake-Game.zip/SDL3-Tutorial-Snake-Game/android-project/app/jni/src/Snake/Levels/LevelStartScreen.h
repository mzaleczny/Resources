#pragma once
#include <SDL3/SDL.h>
#include "../../Core.h"
#include "../Level.h"

class TLevelStartScreen : public TLevel
{
public:
	TLevelStartScreen();
	virtual ~TLevelStartScreen();

	virtual void Update(float DeltaTime) override;
	virtual void Render(SDL_Renderer* Renderer) override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) override;

protected:
	int ChooseClickedMenuOption(float x, float y);
	SDL_Texture* SnakeTex{};
	float Alpha{};
	TTF_Font* m_Font{};
#ifdef ANDROID
	int m_LineHeight = 140;
#else
	int m_LineHeight = 70;
#endif
};
