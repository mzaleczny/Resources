#pragma once
#include <SDL3/SDL.h>
#include "../../Core.h"
#include "../Level.h"

class TLevelPause : public TLevel
{
public:
	TLevelPause();
	virtual ~TLevelPause();

	virtual void Update(float DeltaTime) {}
	virtual void Render(SDL_Renderer* Renderer) override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) { return SDL_APP_CONTINUE; }
protected:
	SDL_Texture* TexPause{};
	int m_TextPositionX;
	int m_TextPositionY;
	TTF_Font* m_Font{};
};
