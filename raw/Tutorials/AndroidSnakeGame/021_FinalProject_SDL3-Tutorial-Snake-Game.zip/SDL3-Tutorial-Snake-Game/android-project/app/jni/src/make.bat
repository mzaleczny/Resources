cl -MD -EHsc -std:c++latest -I f:/libs/SDL3/include f:/libs/SDL3/SDL3.lib f:/libs/SDL3/SDL3_ttf.lib "%1"
del *.obj