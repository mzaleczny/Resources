#include "Snake.h"
#include "Fruit.h"
#include "World.h"
#include <SDL3/SDL.h>

TSnake::TSnake()
	: m_Size(TileSize)
{
	m_SnakeBody.emplace_back(5, 5);
	m_Direction = EDirection::Right;
	m_State = ESnakeState::Moving;

	m_DestinationRect.w = static_cast<float>(m_Size);
	m_DestinationRect.h = static_cast<float>(m_Size);
}

void TSnake::Update(float DeltaTime)
{
	if (m_SnakeBody.empty() || m_Direction == EDirection::None)
	{
		return;
	}

	m_MoveDistance += DeltaTime * m_Speed;
	if (m_MoveDistance >= 1.0f)
	{
		Move();
		m_MoveDistance -= 1.0f;
	}

	HeadLeft.Update(DeltaTime);
	HeadRight.m_CurrentFrame = HeadLeft.m_CurrentFrame;
	HeadRight.m_TimeElapsed = HeadLeft.m_TimeElapsed;
	HeadUp.m_CurrentFrame = HeadLeft.m_CurrentFrame;
	HeadUp.m_TimeElapsed = HeadLeft.m_TimeElapsed;
	HeadDown.m_CurrentFrame = HeadLeft.m_CurrentFrame;
	HeadDown.m_TimeElapsed = HeadLeft.m_TimeElapsed;
}

void TSnake::Render(SDL_Renderer* Renderer)
{
	if (m_SnakeBody.empty())
	{
		return;
	}
	EDirection PrevDirection, NextSegmentDirection;
	SDL_FRect SourceRect;

	for (auto SegmentIter = m_SnakeBody.begin(); SegmentIter != m_SnakeBody.end(); ++SegmentIter)
	{
		m_DestinationRect.x = static_cast<float>((SegmentIter->m_Position.X - GameObject.World->XOffset) * m_Size);
		m_DestinationRect.y = static_cast<float>((SegmentIter->m_Position.Y - GameObject.World->YOffset) * m_Size);
		m_DestinationRect.w = TileSize;
		m_DestinationRect.h = TileSize;

		NextSegmentDirection = GetNextSegmentDirection(SegmentIter);
		if (SegmentIter == m_SnakeBody.begin())
		{
			EDirection PhysicalDirection = GetSnakePhysicalDirection();
			switch (PhysicalDirection)
			{
			case EDirection::Left:
				SourceRect = HeadLeft.GetCurrentFrameRect();
				break;
			case EDirection::Right:
			case EDirection::None:
				SourceRect = HeadRight.GetCurrentFrameRect();
				break;
			case EDirection::Up:
				SourceRect = HeadUp.GetCurrentFrameRect();
				break;
			case EDirection::Down:
				SourceRect = HeadDown.GetCurrentFrameRect();
				break;
			}
			PrevDirection = GetOppositeDirection(PhysicalDirection);
		}
		else if (NextSegmentDirection == EDirection::None)
		{
			switch (GetOppositeDirection(PrevDirection))
			{
			case EDirection::Left:
				SourceRect = SegmentTailLeftRect;
				break;
			case EDirection::Right:
				SourceRect = SegmentTailRightRect;
				break;
			case EDirection::Up:
				SourceRect = SegmentTailUpRect;
				break;
			case EDirection::Down:
				SourceRect = SegmentTailDownRect;
				break;
			}
		}
		else
		{
			EDirection DirectionTowardHead = GetOppositeDirection(PrevDirection);

			if ((DirectionTowardHead == EDirection::Up && NextSegmentDirection == EDirection::Down) || (DirectionTowardHead == EDirection::Down && NextSegmentDirection == EDirection::Up))
			{
				SourceRect = SegmentUpDownRect;
			}
			else if ((DirectionTowardHead == EDirection::Left && NextSegmentDirection == EDirection::Right) || (DirectionTowardHead == EDirection::Right && NextSegmentDirection == EDirection::Left))
			{
				SourceRect = SegmentLeftRightRect;
			}
			else if ((DirectionTowardHead == EDirection::Left && NextSegmentDirection == EDirection::Up) || (DirectionTowardHead == EDirection::Up && NextSegmentDirection == EDirection::Left))
			{
				SourceRect = SegmentLeftUpRect;
			}
			else if ((DirectionTowardHead == EDirection::Right && NextSegmentDirection == EDirection::Up) || (DirectionTowardHead == EDirection::Up && NextSegmentDirection == EDirection::Right))
			{
				SourceRect = SegmentRightUpRect;
			}
			else if ((DirectionTowardHead == EDirection::Left && NextSegmentDirection == EDirection::Down) || (DirectionTowardHead == EDirection::Down && NextSegmentDirection == EDirection::Left))
			{
				SourceRect = SegmentLeftDownRect;
			}
			else if ((DirectionTowardHead == EDirection::Right && NextSegmentDirection == EDirection::Down) || (DirectionTowardHead == EDirection::Down && NextSegmentDirection == EDirection::Right))
			{
				SourceRect = SegmentRightDownRect;
			}
			PrevDirection = NextSegmentDirection;
		}
		GameObject.World->RenderTile(Renderer, GameObject.TileMap, SourceRect, SegmentIter->m_Position.X, SegmentIter->m_Position.Y, m_Size);
	}
}

void TSnake::SetDirection(EDirection Direction)
{
	EDirection PhysicalDirection = GetSnakePhysicalDirection();
	if (Direction == EDirection::Right && PhysicalDirection == EDirection::Left) return;
	if (Direction == EDirection::Left && PhysicalDirection == EDirection::Right) return;
	if (Direction == EDirection::Up && PhysicalDirection == EDirection::Down) return;
	if (Direction == EDirection::Down && PhysicalDirection == EDirection::Up) return;
	m_Direction = Direction;
}

EDirection TSnake::GetOppositeDirection(EDirection Direction)
{
	switch (Direction)
	{
	case EDirection::Left:
		return EDirection::Right;
	case EDirection::Right:
		return EDirection::Left;
	case EDirection::Up:
		return EDirection::Down;
	case EDirection::Down:
		return EDirection::Up;
	case EDirection::None:
		return EDirection::None;
	}
	return EDirection::None;
}

EDirection TSnake::GetNextSegmentDirection(std::list<TSnakeSegment>::iterator CurrentSegment)
{
	std::list<TSnakeSegment>::iterator NextSegment = CurrentSegment;
	++NextSegment;
	if (NextSegment == m_SnakeBody.end())
	{
		return EDirection::None;
	}

	if (CurrentSegment->m_Position.X == NextSegment->m_Position.X)
	{
		if (NextSegment->m_Position.Y > CurrentSegment->m_Position.Y) return EDirection::Down;
		else  return EDirection::Up;
	}
	else if (CurrentSegment->m_Position.Y == NextSegment->m_Position.Y)
	{
		if (NextSegment->m_Position.X > CurrentSegment->m_Position.X) return EDirection::Right;
		else  return EDirection::Left;
	}

	return EDirection::None;
}

bool TSnake::IsOccupiedBySegment(int X, int Y)
{
	for (auto SegmentIter = m_SnakeBody.begin(); SegmentIter != m_SnakeBody.end(); ++SegmentIter)
	{
		if (SegmentIter->m_Position.X == X && SegmentIter->m_Position.Y == Y)
		{
			return true;
		}
	}

	return false;
}

TSnakeSegment* TSnake::GetSegmentWithoutHead(int X, int Y)
{
	for (auto SegmentIter = m_SnakeBody.begin(); SegmentIter != m_SnakeBody.end(); ++SegmentIter)
	{
		if (SegmentIter == m_SnakeBody.begin()) continue;
		if (SegmentIter->m_Position.X == X && SegmentIter->m_Position.Y == Y)
		{
			return &(*SegmentIter);
		}
	}

	return nullptr;
}

void TSnake::Die()
{
	m_State = ESnakeState::Dead;
	m_Direction = EDirection::None;
}
