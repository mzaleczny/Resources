#pragma once
#include <SDL3/SDL.h>
#include "../../Core.h"
#include "../Level.h"
#include <string>

class TLevelGame : public TLevel
{
public:
	TLevelGame();
	virtual ~TLevelGame();

	virtual void Update(float DeltaTime) override;
	virtual void Render(SDL_Renderer* Renderer) override;
	virtual SDL_AppResult HandleEvent(SDL_Event* event) override;
	void DoPauseGame();
	void DoEnterName();
	bool IsEnterName() {
		return m_EnterName;
	}
protected:
	bool m_EnterName{};
	SDL_Texture* m_EnterNameTexture{};
	TTF_Font* m_Font{};
	std::string m_Name;
	int m_Position{ -1 };
	SDL_FRect OkRect;
	void DoAcceptEneteredName();
};
