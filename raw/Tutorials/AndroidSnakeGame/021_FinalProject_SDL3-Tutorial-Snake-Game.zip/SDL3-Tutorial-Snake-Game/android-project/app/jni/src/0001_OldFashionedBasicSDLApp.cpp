#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

bool DoExit{};
SDL_Window *Window{};
SDL_Renderer *Renderer{};

bool Initialize();
void ProcessInput();
void Update();
void Render();
void Cleanup();

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    if (!Initialize())
    {
        Cleanup();
        return -1;
    }

    while (DoExit == false)
    {
        ProcessInput();
        if (DoExit == false)
        {
            Update();
            Render();
        }
    }
    Cleanup();
    return 0;
}


bool Initialize()
{
    if (!SDL_Init(SDL_INIT_EVENTS | SDL_INIT_VIDEO))
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "SDL_Init failed (%s)", SDL_GetError());
        return false;
    }

    if (!SDL_CreateWindowAndRenderer("examples/001_BasicOldFashionedApp", 640, 480, 0, &Window, &Renderer))
    {
        SDL_Log("Couldn't create window/renderer: %s", SDL_GetError());
        return false;
    }

    return true;
}

void ProcessInput()
{
    SDL_Event Event;
    while (SDL_PollEvent(&Event))
    {
        switch (Event.type)
        {
        case SDL_EVENT_QUIT:
        case SDL_EVENT_FINGER_UP:
            DoExit = true;
            SDL_Log("0001_OldFashionedBasicSDLApp: Exit requested by user");
            return;
        }
    }
}

void Update()
{

}

void Render()
{
    const float red = 0.0f;
    const float green = 0.0f;
    const float blue = 0.0f;
    SDL_SetRenderDrawColorFloat(Renderer, red, green, blue, SDL_ALPHA_OPAQUE_FLOAT);
    SDL_RenderClear(Renderer);
    SDL_RenderPresent(Renderer);
}

void Cleanup()
{
    if (Window)
    {
        SDL_DestroyWindow(Window);
    }
    if (Renderer)
    {
        SDL_DestroyRenderer(Renderer);
    }
    SDL_Quit();
}
