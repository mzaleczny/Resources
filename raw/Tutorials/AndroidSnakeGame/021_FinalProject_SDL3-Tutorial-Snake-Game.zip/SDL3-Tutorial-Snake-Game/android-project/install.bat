@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsx86_arm64.bat"
cd d:\android\SDL3-Tutorial-Snake-Game\android-project
gradlew installDebug -PBUILD_WITH_CMAKE=true
