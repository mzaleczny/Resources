#pragma once

#include <list>
#include <SDL3/SDL.h>
#include "../Core.h"
#include "Snake.h"
#include "Animation.h"

class TEnemySnake : public TSnake
{
public:
	TEnemySnake();
	virtual void Update(float DeltaTime) override;
	virtual void Move() override;
	EDirection GetRandomDirection();
	bool ObstacleInDirection(EDirection Direction);
protected:
	int m_TilesToMove{ 7 };
};
