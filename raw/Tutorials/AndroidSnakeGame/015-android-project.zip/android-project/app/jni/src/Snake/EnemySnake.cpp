#include "EnemySnake.h"
#include "Fruit.h"
#include "World.h"
#include "../Core.h"
#include <SDL3/SDL.h>

TEnemySnake::TEnemySnake()
{
	m_Direction = EDirection::Up;
	m_SnakeBody.front().m_Position = { 20, 5 };
}

void TEnemySnake::Update(float DeltaTime)
{
	float OldMoveDistance = m_MoveDistance;
	TSnake::Update(DeltaTime);
	if (ObstacleInDirection(m_Direction))
	{
		m_Direction = GetRandomDirection();
	}
	if (m_MoveDistance < OldMoveDistance)
	{
		--m_TilesToMove;
		if (m_TilesToMove < 1)
		{
			m_Direction = GetRandomDirection();
			m_TilesToMove = static_cast<int>(SDL_randf() * 6) + 4;
		}
	}
}

void TEnemySnake::Move()
{
	TSnakeSegment Head = m_SnakeBody.front();

	if (m_GrowBy > 0)
	{
		m_SnakeBody.emplace_back(0, 0);
		m_GrowBy -= 1;
	}


	TSnakeSegment Tail = m_SnakeBody.back();
	Tail.m_Position.X = Head.m_Position.X;
	Tail.m_Position.Y = Head.m_Position.Y;
	m_SnakeBody.pop_back();
	m_SnakeBody.push_front(Tail);

	auto HeadIter = m_SnakeBody.begin();

	switch (m_Direction)
	{
	case EDirection::Left:
		--HeadIter->m_Position.X;
		break;
	case EDirection::Right:
		++HeadIter->m_Position.X;
		break;
	case EDirection::Up:
		--HeadIter->m_Position.Y;
		break;
	case EDirection::Down:
		++HeadIter->m_Position.Y;
		break;
	default:
		break;
	}

	if (TFruit* Fruit = GameObject.World->GetFruitAtPosition(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		GrowBy(Fruit->GetGrowByValue());
		Fruit->SetRandomPosition();
	}
	else if (TSnakeSegment* Segment = GetSegmentWithoutHead(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		Die();
	}
	else if (TObstacle* Obstacle = GameObject.World->GetObstacleAtPosition(HeadIter->m_Position.X, HeadIter->m_Position.Y))
	{
		Die();
	}
}

EDirection TEnemySnake::GetRandomDirection()
{
	int Rand;
	int Count = 10;
	do
	{
		do
		{
			Rand = static_cast<int>(SDL_randf() * 3.99) + 1;
		} while (static_cast<EDirection>(Rand) == m_Direction || static_cast<EDirection>(Rand) == GetOppositeDirection(m_Direction));

		Count -= 1;
		if (Count < 1)
		{
			break;
		}
	} while (ObstacleInDirection(static_cast<EDirection>(Rand)));

	return static_cast<EDirection>(Rand);
}

bool TEnemySnake::ObstacleInDirection(EDirection Direction)
{
	int TestX = m_SnakeBody.front().m_Position.X;
	int TestY = m_SnakeBody.front().m_Position.Y;
	switch (Direction)
	{
	case EDirection::Left:
		TestX -= 1;
		break;
	case EDirection::Right:
		TestX += 1;
		break;
	case EDirection::Up:
		TestY -= 1;
		break;
	case EDirection::Down:
		TestY += 1;
		break;
	}

	if (GetSegmentWithoutHead(TestX, TestY)) return true;
	if (GameObject.World->Snake->IsOccupiedBySegment(TestX, TestY)) return true;
	if (GameObject.World->GetObstacleAtPosition(TestX, TestY)) return true;

	return false;
}
