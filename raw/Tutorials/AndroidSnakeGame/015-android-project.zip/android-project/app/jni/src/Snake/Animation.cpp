#include "Animation.h"

void TAnimation::Update(float DeltaTime)
{
	m_TimeElapsed += DeltaTime;
	m_CurrentFrame = static_cast<int>(m_TimeElapsed * m_FramesPerSecond) % m_FrameRects.size();
}
