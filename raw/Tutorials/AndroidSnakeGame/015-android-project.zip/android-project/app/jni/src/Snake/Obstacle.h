#pragma once
#include "../Core.h"
#include <vector>

class TObstacle
{
public:
	TObstacle(int x, int y);
	void Render(SDL_Renderer* Renderer);
	void SetRandomPosition();
	TVector2d GetPosition() const { return m_Position; };
	bool IsOccupied(int X, int Y);
protected:
	int m_Size;
	int m_Type;
	TVector2d m_Position;
	SDL_FRect m_DestinationRect;
	static std::vector<SDL_FRect> m_Types;
};
