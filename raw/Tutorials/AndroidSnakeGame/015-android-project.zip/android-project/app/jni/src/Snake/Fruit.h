#pragma once
#include "../Core.h"
#include <vector>

class TFruit
{
public:
	TFruit();
	void Render(SDL_Renderer* Renderer);
	void SetRandomPosition();
	TVector2d GetPosition() const { return m_Position; };
	bool IsOccupiedByFruit(int X, int Y);
	int GetGrowByValue() const { return m_GrowByValue; }
	void DoRandomFruit();
protected:
	int m_Size;
	int m_Type;
	int m_GrowByValue;
	TVector2d m_Position;
	SDL_FRect m_DestinationRect;
	static std::vector<SDL_FRect> m_FruitTypes;
};
