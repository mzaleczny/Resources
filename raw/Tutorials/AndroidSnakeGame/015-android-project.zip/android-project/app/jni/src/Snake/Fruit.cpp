#include "Fruit.h"
#include "World.h"

std::vector<SDL_FRect> TFruit::m_FruitTypes;

TFruit::TFruit() : m_Size(TileSize)
{
	m_DestinationRect.w = TileSize;
	m_DestinationRect.h = TileSize;
	DoRandomFruit();

	if (m_FruitTypes.size() == 0)
	{
		for (int y = 0; y < 4; ++y)
		{
			for (int x = 0; x < 6; ++x)
			{
				SDL_FRect rc{ static_cast<float>(x * TileSize), static_cast<float>(y * TileSize), static_cast<float>(TileSize), static_cast<float>(TileSize) };
				m_FruitTypes.push_back(rc);
			}
		}
	}
};

void TFruit::Render(SDL_Renderer* Renderer)
{
	GameObject.World->RenderTile(Renderer, GameObject.FruitsTileMap, m_FruitTypes[m_Type], m_Position.X, m_Position.Y, m_Size);
}

void TFruit::SetRandomPosition()
{
	int MaxPosX = GameObject.WindowWidth / m_Size - 1;
	int MaxPosY = GameObject.WindowHeight / m_Size - 1;
	int X, Y;

	do
	{
		X = static_cast<int>(SDL_randf() * MaxPosX);
		Y = static_cast<int>(SDL_randf() * MaxPosY);
	} while (!GameObject.World->IsFieldAvaialable(X, Y));

	m_Position.X = X;
	m_Position.Y = Y;
	DoRandomFruit();
}

bool TFruit::IsOccupiedByFruit(int X, int Y)
{
	if (m_Position.X == X && m_Position.Y == Y)
	{
		return true;
	}

	return false;
}

void TFruit::DoRandomFruit()
{
	m_Type = static_cast<int>(SDL_randf() * 17.999);
	m_GrowByValue = m_Type / 4 + 1;
}
