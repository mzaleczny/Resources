#pragma once
#include <vector>
#include <initializer_list>
#include <SDL3/SDL.h>


class TAnimation
{
public:
	TAnimation(int FramesPerSecond, const std::initializer_list<SDL_FRect>& FrameRectangles)
		: m_FramesPerSecond(FramesPerSecond), m_FrameRects(FrameRectangles)
	{}

	int m_FramesPerSecond{};
	int m_CurrentFrame{};
	float m_TimeElapsed{};

	std::vector<SDL_FRect> m_FrameRects;

	void Update(float DeltaTime);
	SDL_FRect& GetCurrentFrameRect() { return m_FrameRects[m_CurrentFrame]; }
};