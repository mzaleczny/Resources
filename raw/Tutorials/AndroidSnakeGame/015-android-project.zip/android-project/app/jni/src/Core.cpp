#include "Core.h"

void DrawString(SDL_Renderer* Renderer, const char* String, float x, float y)
{
    SDL_Color Color = { 255, 255, 0, 255 };
    SDL_Surface* TextSurface = TTF_RenderText_Blended(Font, String, 0, Color);
    if (TextSurface)
    {
        SDL_Texture* TextTexture = SDL_CreateTextureFromSurface(Renderer, TextSurface);
        if (TextTexture)
        {
            SDL_FRect DestRect;
            DestRect.x = x;
            DestRect.y = y;
            DestRect.w = static_cast<float>(TextTexture->w);
            DestRect.h = static_cast<float>(TextTexture->h);

            SDL_RenderTexture(Renderer, TextTexture, nullptr, &DestRect);
            SDL_DestroyTexture(TextTexture);
        }

        SDL_DestroySurface(TextSurface);
    }
}

SDL_Texture* ScaleTexture(SDL_Renderer* Renderer, SDL_Texture* SourceTexture, float ScaleFactor)
{
    SDL_Texture* ScaledTexture = SDL_CreateTexture(Renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_TARGET, SourceTexture->w * ScaleFactor, SourceTexture->h * ScaleFactor);
    if (!ScaledTexture)
    {
        SDL_Log("Couldn't create texture: %s", SDL_GetError());
        return nullptr;
    }
    SDL_SetRenderTarget(Renderer, ScaledTexture);
    SDL_RenderTexture(Renderer, SourceTexture, nullptr, nullptr);
    SDL_SetRenderTarget(Renderer, nullptr);
    return ScaledTexture;
}
