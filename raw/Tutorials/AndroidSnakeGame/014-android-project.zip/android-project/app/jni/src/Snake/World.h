#pragma once
#include <vector>
#include <SDL3/SDL.h>
#include "../Core.h"

class TSnake;
class TFruit;
class TObstacle;

class TWorld
{
public:
	TWorld();
	~TWorld();

	void Update(float DeltaTime);
	void Render(SDL_Renderer* Renderer);

	TFruit* GetFruitAtPosition(int X, int Y);
	TObstacle* GetObstacleAtPosition(int X, int Y);
	bool IsFieldAvaialable(int X, int Y);

	void Reset();

	TSnake* Snake{};
	int m_FruitsCount;
	std::vector<TFruit*> Fruits;
	int m_ObstacleCount;
	std::vector<TObstacle*> Obstacles;

	std::vector<uint8_t> WorldMap;
	SDL_FRect GroundRects[4] {
		GetRect(0, 1),
		GetRect(1, 1),
		GetRect(2, 1),
		GetRect(3, 1)
	};

	inline void Scroll(int XUnits = 0, int YUnits = 0)
	{
		XOffset += XUnits;
		YOffset += YUnits;
	}
	inline void ScrollLeft() { Scroll(1, 0); }
	inline void ScrollRight() { Scroll(-1, 0); }
	inline void ScrollUp() { Scroll(0, 1); }
	inline void ScrollDown() { Scroll(0, -1); }
	inline bool IsWithinVieport(int x, int y)
	{
		return x >= XOffset && x < XOffset + TilesPerRow && y >= YOffset && y < YOffset + TilesPerHeight;
	}

	int TilesPerRow;
	int TilesPerHeight;
	int WholeTilesPerRow;
	int WholeTilesPerHeight;
	int MaxPosX;
	int MaxPosY;
	int XOffset{};
	int YOffset{};
};