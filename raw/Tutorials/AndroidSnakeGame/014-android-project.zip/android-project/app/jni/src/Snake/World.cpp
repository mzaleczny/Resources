#include "World.h"
#include "Snake.h"
#include "Fruit.h"
#include "Obstacle.h"

TWorld::TWorld()
{
    Snake = new TSnake();
    if (!Snake)
    {
        SDL_Log("Couldn't create TSnake object");
    }

    m_FruitsCount = 10;
    Fruits.reserve(m_FruitsCount);
    for (int i = 0; i < m_FruitsCount; ++i)
    {
        TFruit* Fruit = new TFruit();
        if (Fruit)
        {
            Fruits.push_back(Fruit);
        }
    }

    TilesPerRow = static_cast<int>(ceil(static_cast<float>(GameObject.WindowWidth) / TileSize));
    TilesPerHeight = static_cast<int>(ceil(static_cast<float>(GameObject.WindowHeight) / TileSize));
    WholeTilesPerRow = TilesPerRow + 15;
    WholeTilesPerHeight = TilesPerHeight + 15;
    MaxPosX = TilesPerRow - 1;
    MaxPosY = TilesPerHeight - 1;

    WorldMap.reserve(WholeTilesPerRow * WholeTilesPerHeight);
    for (int i = 0; i < WholeTilesPerRow * WholeTilesPerHeight; ++i)
    {
        WorldMap.emplace_back(static_cast<int>(SDL_randf() * 3.999));
    }

    for (int x = 0; x < WholeTilesPerRow; ++x)
    {
        for (int y = 0; y < WholeTilesPerHeight; ++y)
        {
            if (x == 0 || y == 0 || x == WholeTilesPerRow - 1 || y == WholeTilesPerHeight - 1)
            {
                TObstacle* Obstacle = new TObstacle(x, y);
                if (Obstacle)
                {
                    Obstacles.push_back(Obstacle);
                }
            }
        }
    }
}

TWorld::~TWorld()
{
    for (int i = 0; i < Obstacles.size(); ++i)
    {
        if (TObstacle* Obstacle = Obstacles[i])
        {
            delete Obstacle;
        }
    }
    Obstacles.clear();
    for (int i = 0; i < Fruits.size(); ++i)
    {
        if (TFruit* Fruit = Fruits[i])
        {
            delete Fruit;
        }
    }
    Fruits.clear();
    if (Snake)
    {
        delete Snake;
        Snake = nullptr;
    }
}

void TWorld::Update(float DeltaTime)
{
    Snake->Update(DeltaTime);
}

void TWorld::Render(SDL_Renderer* Renderer)
{
    for (int x = XOffset; x < XOffset + TilesPerRow; ++x)
    {
        for (int y = YOffset; y < YOffset + TilesPerHeight; ++y)
        {
            SDL_FRect GroundSourceRect = GroundRects[WorldMap[x*y]];
            SDL_FRect GroundDestinationRect{
                static_cast<float>((x-XOffset) * TileSize),
                static_cast<float>((y-YOffset) * TileSize),
                static_cast<float>(TileSize),
                static_cast<float>(TileSize)
            };
            SDL_RenderTexture(Renderer, GameObject.TileMap, &GroundSourceRect, &GroundDestinationRect);
        }
    }

    for (int i = 0; i < Fruits.size(); ++i)
    {
        if (IsWithinVieport(Fruits[i]->GetPosition().X, Fruits[i]->GetPosition().Y))
        {
            Fruits[i]->Render(Renderer);
        }
    }

    for (int i = 0; i < Obstacles.size(); ++i)
    {
        if (IsWithinVieport(Obstacles[i]->GetPosition().X, Obstacles[i]->GetPosition().Y))
        {
            Obstacles[i]->Render(Renderer);
        }
    }

    Snake->Render(Renderer);
}

TFruit* TWorld::GetFruitAtPosition(int X, int Y)
{
    for (int i = 0; i < Fruits.size(); ++i)
    {
        if (Fruits[i]->IsOccupiedByFruit(X, Y))
        {
            return Fruits[i];
        }
    }
    return nullptr;
}

TObstacle* TWorld::GetObstacleAtPosition(int X, int Y)
{
    for (int i = 0; i < Obstacles.size(); ++i)
    {
        if (Obstacles[i]->IsOccupied(X, Y))
        {
            return Obstacles[i];
        }
    }
    return nullptr;
}

bool TWorld::IsFieldAvaialable(int X, int Y)
{
    if (Snake->IsOccupiedBySegment(X, Y)) return false;
    if (GetFruitAtPosition(X, Y)) return false;
    if (GetObstacleAtPosition(X, Y)) return false;
    return true;
}

void TWorld::Reset()
{
    for (int i = 0; i < Fruits.size(); ++i)
    {
        Fruits[i]->SetRandomPosition();
    }
}
