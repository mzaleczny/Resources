#include "Obstacle.h"
#include "World.h"

std::vector<SDL_FRect> TObstacle::m_Types{ GetRect(8, 1), GetRect(9, 1),GetRect(8, 8), GetRect(9, 8), GetRect(8, 15), GetRect(9, 15) };

TObstacle::TObstacle(int x, int y) : m_Size(TileSize)
{
	m_DestinationRect.w = TileSize;
	m_DestinationRect.h = TileSize;
	m_Type = static_cast<int>(SDL_randf() * 5.999);
	m_Position.X = x;
	m_Position.Y = y;
};

void TObstacle::Render(SDL_Renderer* Renderer)
{
	m_DestinationRect.x = static_cast<float>((m_Position.X - GameObject.World->XOffset) * m_Size);
	m_DestinationRect.y = static_cast<float>((m_Position.Y - GameObject.World->YOffset) * m_Size);
	SDL_RenderTexture(Renderer, GameObject.TileMap, &m_Types[m_Type], &m_DestinationRect);
}

void TObstacle::SetRandomPosition()
{
	int MaxPosX = GameObject.WindowWidth / m_Size - 1;
	int MaxPosY = GameObject.WindowHeight / m_Size - 1;
	int X, Y;

	do
	{
		X = static_cast<int>(SDL_randf() * MaxPosX);
		Y = static_cast<int>(SDL_randf() * MaxPosY);
	} while (!GameObject.World->IsFieldAvaialable(X, Y));

	m_Position.X = X;
	m_Position.Y = Y;
	m_Type = static_cast<int>(SDL_randf() * 5.999);
}

bool TObstacle::IsOccupied(int X, int Y)
{
	if (m_Position.X == X && m_Position.Y == Y)
	{
		return true;
	}

	return false;
}
