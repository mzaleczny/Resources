set(Sources 
    "${SourcesDir}/Snake.cpp" "${SourcesDir}/Core.cpp" "${SourcesDir}/Core.h"
    "${SourcesDir}/Snake/Snake.cpp" "${SourcesDir}/Snake/Snake.h"
    "${SourcesDir}/Snake/Fruit.cpp" "${SourcesDir}/Snake/Fruit.h"
    "${SourcesDir}/Snake/World.cpp" "${SourcesDir}/Snake/World.h"
)
