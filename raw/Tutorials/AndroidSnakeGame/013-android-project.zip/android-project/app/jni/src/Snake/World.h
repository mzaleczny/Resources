#pragma once
#include <vector>
#include <SDL3/SDL.h>
#include "../Core.h"

class TSnake;
class TFruit;

class TWorld
{
public:
	TWorld();
	~TWorld();

	void Update(float DeltaTime);
	void Render(SDL_Renderer* Renderer);

	TFruit* GetFruitAtPosition(int X, int Y);
	bool IsFieldAvaialable(int X, int Y);

	void Reset();

	TSnake* Snake{};
	int m_FruitsCount;
	std::vector<TFruit*> Fruits;

	std::vector<uint8_t> WorldMap;
	SDL_FRect GroundRects[4] {
		GetRect(0, 1),
		GetRect(1, 1),
		GetRect(2, 1),
		GetRect(3, 1)
	};
protected:
	int TilesPerRow;
	int TilesPerHeight;
	int MaxPosX;
	int MaxPosY;

};