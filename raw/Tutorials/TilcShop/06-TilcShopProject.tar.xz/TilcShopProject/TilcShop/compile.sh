#!/bin/bash

cd /home/mzaleczny/repos/TilcShop
cmake --build out --config Release
