#pragma once

#include "Tilc/Tilc.h"
#include "Tilc/Apps/Www/RequestHandler.h"

void CategoriesList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
void CategoriesAdd(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
void CategoriesUpdate(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
void CategoriesDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
