#include "Products.h"

void ProductsList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsList" << "<br/>";
}

void ProductsAdd(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsAdd" << "<br/>";
}

void ProductsUpdate(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsUpdate" << "<br/>";
}

void ProductsDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsDelete" << "<br/>";
}
