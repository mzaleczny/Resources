#include "Categories.h"

void CategoriesList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesList" << "<br/>";
}

void CategoriesAdd(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesAdd" << "<br/>";
}

void CategoriesUpdate(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesUpdate" << "<br/>";
}

void CategoriesDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesDelete" << "<br/>";
}
