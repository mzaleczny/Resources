#include <iostream>
#include <string>
#include <thread>
#include <string_view>
#include <fstream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <fcgio.h>
#include <fcgiapp.h>
#include <unistd.h>
#include "Tilc/Tilc.h"
#include "Tilc/Apps/Www/RequestHandler.h"

#include "RequestHandlers/Categories.h"
#include "RequestHandlers/Products.h"


int main()
{
    FCGX_Request request;

    FCGX_Init();
    FCGX_InitRequest(&request, 0, 0);

    Tilc::InitTilc();
    Tilc::Apps::Www::Application = new Tilc::Apps::Www::TWwwApp("/var/www/shop.pl", "Shop", "shop", "");
    if (!Tilc::Apps::Www::Application)
    {
        Tilc::CleanupTilc();
        return 0;
    }
    Tilc::Apps::Www::Application->AddAvailableLanguages({"pl", "en"});

    while (FCGX_Accept_r(&request) == 0)
    {
        Tilc::Apps::Www::TRequestHandler rh(&request);
        
        rh.m_RequestHandlers["/categories/list"] = &CategoriesList;
        rh.m_RequestHandlers["/categories/add"] = &CategoriesAdd;
        rh.m_RequestHandlers["/categories/update"] = &CategoriesUpdate;
        rh.m_RequestHandlers["/categories/delete"] = &CategoriesDelete;
        
        rh.m_RequestHandlers["/products/list"] = &ProductsList;
        rh.m_RequestHandlers["/products/add"] = &ProductsAdd;
        rh.m_RequestHandlers["/products/update"] = &ProductsUpdate;
        rh.m_RequestHandlers["/products/delete"] = &ProductsDelete;

        rh.HandleRequest();
        rh << "Hello";
    }

    if (Tilc::Apps::Www::Application)
    {
        delete Tilc::Apps::Www::Application;
        Tilc::Apps::Www::Application = nullptr;
    }

    Tilc::CleanupTilc();
}
