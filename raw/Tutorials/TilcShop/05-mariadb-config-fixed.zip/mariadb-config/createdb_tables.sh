#!/bin/bash

mysql -u shop -p shop <db_tables.sql
