CREATE DATABASE shop DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_polish_ci;
GRANT ALL PRIVILEGES ON shop.* TO 'shop'@'localhost' identified by 'shop';
FLUSH PRIVILEGES;
