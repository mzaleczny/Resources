#!/bin/bash

cd /home/mzaleczny/TilcShopProject/JsonExample
cmake -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_BUILD_TYPE=Release -S . -B out
cmake --build out --config Release
