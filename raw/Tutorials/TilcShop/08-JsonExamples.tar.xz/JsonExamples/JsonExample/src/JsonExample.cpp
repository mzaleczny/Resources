#include <iostream>
#include <string>
#include "Tilc/Utils/JsonParser.h"
#include "Tilc/Utils/StdObject.h"

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " JsonFileName.json" << std::endl;
        return -1;
    }

    Tilc::TJsonParser parser;
    Tilc::TStdObject* JsonRoot = parser.parseFile(argv[1]);
    if (!JsonRoot)
    {
        std::cerr << "Error parsing file: " << argv[1] << ". ";
        std::cerr << parser.getErrorMessage() << std::endl;
        return -2;
    }

    Tilc::TExtString Url = JsonRoot->getAsObject("root")->getAsString("Url");
    std::cout << "Url: " << Url << std::endl;
    Tilc::TStdObject* JsonCommand = JsonRoot->getAsObject("root")->getAsObject("Command");
    if (JsonCommand)
    {
        std::cout << "Command: " << std::endl;
        std::cout << JsonCommand->toJson() << std::endl;
        std::cout << "Action: " << JsonCommand->getAsString("Action") << std::endl;

        Tilc::TPropertiesVector* Items = JsonCommand->getAsArray("Items");
        if (Items)
        {
            std::cout << "Items count: " << Items->size() << std::endl;
            for (int i = 0; i < Items->size(); ++i)
            {
                Tilc::TStdObject* Item = (*Items)[i]->oValue;
                if (Item)
                {
                    std::cout << "Item #" << i << ": " << Item->getAsString("name") << std::endl;
                    Tilc::TPropertiesVector* Values = Item->getAsArray("values");
                    if (Values)
                    {
                        Tilc::TExtString ValuesStr;
                        for (int j = 0; j < Values->size(); ++j)
                        {
                            ValuesStr += std::to_string((*Values)[j]->iValue) + " ";
                        }
                        std::cout << "values: " << ValuesStr << std::endl;
                    }
                }
            }
        }
    }

    delete JsonRoot;
    return 0;
}
