#!/bin/bash

cd /home/mzaleczny/TilcShopProject/JsonExample
cmake --build out --config Release
