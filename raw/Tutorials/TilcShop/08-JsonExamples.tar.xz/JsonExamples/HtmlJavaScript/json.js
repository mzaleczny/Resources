var JsonText = `{
    "Url": "http://local.shop/shop/pl/categories/save",
    "Command": {
        "Action": "Save",
        "Items": [
            {
                "id": "",
                "name": "Kategoria #1"
            },
            {
                "id": "",
                "name": "Kategoria #2"
            },
            {
                "id": "",
                "name": "Kategoria #3"
            },
            {
                "id": "",
                "name": "Kategoria #4"
            },
            {
                "id": "",
                "name": "Kategoria #5"
            },
            {
                "id": "1",
                "name": "Kategoria #1",
                "short_description": "Krótki opis kategorii #1.",
                "values": [5, 10, 15]
            }
        ]
    }
}`;

console.log(JsonText);
var Json = JSON.parse(JsonText);
console.log(Json);
console.log("Url: ", Json.Url);
console.log("Command: ", Json.Command);
console.log("Action: ", Json.Command.Action);
console.log("Action: ", Json.Command["Action"]);
console.log("Items count: ", Json.Command.Items.length);
for (var i = 0; i < Json.Command.Items.length; ++i)
{
    console.log("Item #" + i.toString() + ": ", Json.Command.Items[i].name);
    if (typeof(Json.Command.Items[i].values) == "object")
    {
        var values = "";
        for (var j = 0; j < Json.Command.Items[i].values.length; ++j)
        {
            values += Json.Command.Items[i].values[j].toString() + " ";
        }
        console.log("values: ", values)
    }
}
