clear
./out/DoRequest ./RequestJsons/ProductsList.json
