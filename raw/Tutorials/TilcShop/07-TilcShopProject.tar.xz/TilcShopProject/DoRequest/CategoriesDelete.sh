clear
./out/DoRequest ./RequestJsons/CategoriesDelete.json
