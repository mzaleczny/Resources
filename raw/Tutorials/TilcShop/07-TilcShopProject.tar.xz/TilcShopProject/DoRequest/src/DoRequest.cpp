#include <iostream>
#include <string>
#include <curl/curl.h>
#include "Tilc/Utils/JsonParser.h"
#include "Tilc/Utils/StdObject.h"
#include "Tilc/Net/Http.h"

int main(int argc, char* argv[])
{
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " JsonFileName.json" << std::endl;
        return -1;
    }

    Tilc::TJsonParser parser;
    Tilc::TStdObject* JsonRoot = parser.parseFile(argv[1]);
    if (!JsonRoot)
    {
        std::cerr << "Error parsing file: " << argv[1] << std::endl;
        return -2;
    }
    Tilc::Net::THttp Http;
    Tilc::TExtString ResultCode, FetchedData;
    Tilc::TExtString Url = JsonRoot->getAsObject("root")->getAsString("Url");
    Tilc::TStdObject* JsonData = JsonRoot->getAsObject("root")->getAsObject("PostData");
    std::cout << "POST Url: " << Url << std::endl;

    if (!JsonData)
    {
        FetchedData = Http.DoPost(Url, "", {}, ResultCode);
    }
    else
    {
        FetchedData = Http.DoPost(Url, JsonData->toJson(), {}, ResultCode);
    }
    std::cout << FetchedData << std::endl << std::endl;

    delete JsonRoot;
    return 0;
}
