clear
./out/DoRequest ./RequestJsons/ProductsDelete.json

