clear
./out/DoRequest ./RequestJsons/CategoriesSave.json
