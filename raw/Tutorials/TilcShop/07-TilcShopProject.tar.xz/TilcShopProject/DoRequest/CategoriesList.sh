clear
./out/DoRequest ./RequestJsons/CategoriesList.json
