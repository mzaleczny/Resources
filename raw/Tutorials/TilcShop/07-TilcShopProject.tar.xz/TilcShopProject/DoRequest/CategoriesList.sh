./out/DoRequest ./RequestJsons/CategoriesList.json
