#!/bin/bash

cd /home/mzaleczny/TilcShopProject/DoRequest
cmake --build out --config Release
