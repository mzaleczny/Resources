clear
./out/DoRequest ./RequestJsons/ProductsSave.json
