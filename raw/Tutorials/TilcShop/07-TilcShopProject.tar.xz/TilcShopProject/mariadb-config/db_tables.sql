use shop;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11),
  `left` int(11),
  `right` int(11),
  `name` varchar(255) DEFAULT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `short_description` TEXT DEFAULT NULL,
  `full_description` LONGTEXT DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;


DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `price` decimal(6,2) DEFAULT NULL,
  `price_1` decimal(6,2) DEFAULT NULL,
  `price_2` decimal(6,2) DEFAULT NULL,
  `price_3` decimal(6,2) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `short_description` TEXT DEFAULT NULL,
  `full_description` LONGTEXT DEFAULT NULL,
  `mini_map_file` varchar(255) DEFAULT NULL,
  `css_class` varchar(16) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;


DROP TABLE IF EXISTS `pictures`;
CREATE TABLE `pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `orig_fname` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES products(id)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;


DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `channel` enum('payu','paypal','manual','sms') DEFAULT NULL,
  `ip` varchar(256) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `currency` enum('PLN','EUR','USD') DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `invoice_data` varchar(511) DEFAULT NULL,
  `cart` longtext DEFAULT NULL,
  `order_code` varchar(64) DEFAULT NULL,
  `remote_order_id` varchar(64) DEFAULT NULL,
  `realized_date` datetime DEFAULT NULL,
  `canceled_date` datetime DEFAULT NULL,
  `shipping_address_receiver` varchar(255) DEFAULT NULL,
  `shipping_address_street` varchar(255) DEFAULT NULL,
  `shipping_address_zipcode` varchar(32) DEFAULT NULL,
  `shipping_address_city` varchar(255) DEFAULT NULL,
  `shipping_address_country` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_remote_order_id` (`remote_order_id`)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;


DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(32) DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `address_street` varchar(255) DEFAULT NULL,
  `address_city` varchar(255) DEFAULT NULL,
  `address_zip_code` varchar(16) DEFAULT NULL,
  `address_country` varchar(64) DEFAULT NULL,
  `tin` varchar(16) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT current_timestamp(),
  `hash` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number` (`number`),
  KEY `idx_invoices_number` (`number`)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;


DROP TABLE IF EXISTS `invoices_numeration`;
CREATE TABLE `invoices_numeration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` int(11) DEFAULT NULL,
  `counter` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_polish_ci;
