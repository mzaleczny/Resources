#!/bin/bash

cd /home/mzaleczny/TilcShopProject/TilcShop
cmake --build out --config Release
