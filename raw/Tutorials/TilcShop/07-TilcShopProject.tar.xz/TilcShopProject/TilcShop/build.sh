#!/bin/bash

cd /home/mzaleczny/TilcShopProject/TilcShop
cmake -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_BUILD_TYPE=Release -S . -B out
cmake --build out --config Release
cp out/TilcShop /var/www/shop.pl/public_html/fcgi/TilcShop.fcgi
