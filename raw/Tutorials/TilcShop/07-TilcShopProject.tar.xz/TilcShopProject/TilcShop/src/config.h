#pragma once

constexpr const char* DBHost   = "localhost";
constexpr const char* DBName   = "shop";
constexpr const char* DBUser   = "shop";
constexpr const char* DBPasswd = "shop";
constexpr const char* DBSocket = "/var/run/mysqld/mysqld.sock";
