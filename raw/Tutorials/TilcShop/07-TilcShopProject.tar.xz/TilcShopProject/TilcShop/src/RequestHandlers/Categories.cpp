#include "Categories.h"
#include "../config.h"
#include "Tilc/Data/DbMySQL.h"
#include "Tilc/Data/DataProcessor.h"
#include "Tilc/Utils/JsonParser.h"
#include "Tilc/Utils/StdObject.h"

void CategoriesList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);
    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM categories",
        {"id", "parent_id", "left_id", "right_id", "name", "name_en", "short_description", "full_description", "created", "modified"}
    );
}

void CategoriesSave(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);

    if (rh.Body.length() > 0)
    {
        Tilc::Data::TDataProcessor::SaveItems(rh.os, DB, "categories", rh.Body);
    }

    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM categories",
        {"id", "parent_id", "left_id", "right_id", "name", "name_en", "short_description", "full_description", "created", "modified"}
    );
}

void CategoriesDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);

    if (rh.Body.length() > 0)
    {
        Tilc::Data::TDataProcessor::DeleteItems(rh.os, DB,
            "DELETE FROM categories WHERE id IN (%s)",
            rh.Body
        );
    }

    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM categories",
        {"id", "parent_id", "left_id", "right_id", "name", "name_en", "short_description", "full_description", "created", "modified"}
    );
}
