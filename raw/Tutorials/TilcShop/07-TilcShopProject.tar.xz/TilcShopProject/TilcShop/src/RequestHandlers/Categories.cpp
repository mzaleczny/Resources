#include "Categories.h"
#include "../config.h"
#include "Tilc/Data/DbMySQL.h"
#include "Tilc/Utils/VectorContainer.h"

void CategoriesList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";

    Tilc::Data::TDBDataRows Data;
    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);
    DB.Select("SELECT * FROM categories", Data);
    rh << "{\"items\":";
    Tilc::PrintVectorAsJsonArray(rh.os,
        {"id", "parent_id", "left", "right", "name", "name_en", "short_description", "full_description", "created", "modified"},
        Data);
    rh << ",\"items_count\":\"" << Data.size() << "\"}";
}

void CategoriesAdd(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesAdd" << "<br/>";
}

void CategoriesUpdate(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesUpdate" << "<br/>";
}

void CategoriesDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: CategoriesDelete" << "<br/>";
}
