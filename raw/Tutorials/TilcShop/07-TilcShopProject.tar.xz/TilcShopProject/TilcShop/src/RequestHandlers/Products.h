#pragma once

#include "Tilc/Tilc.h"
#include "Tilc/Apps/Www/RequestHandler.h"

void ProductsList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
void ProductsSave(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
void ProductsDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url);
