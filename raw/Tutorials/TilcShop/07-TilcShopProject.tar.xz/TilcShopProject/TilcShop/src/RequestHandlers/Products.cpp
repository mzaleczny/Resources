#include "Products.h"
#include "../config.h"
#include "Tilc/Data/DbMySQL.h"
#include "Tilc/Data/DataProcessor.h"

void ProductsList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);
    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM products",
        {
            "id", "name", "slug", "name_en", "price", "price_1", "price_2", "price_3", "product_code", "short_description", "full_description",
            "mini_map_file", "css_class", "created", "modified"
        }
    );
}

void ProductsSave(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);

    if (rh.Body.length() > 0)
    {
        Tilc::Data::TDataProcessor::SaveItems(rh.os, DB, "products", rh.Body);
    }

    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM products",
        {
            "id", "name", "slug", "name_en", "price", "price_1", "price_2", "price_3", "product_code", "short_description", "full_description",
            "mini_map_file", "css_class", "created", "modified"
        }
    );
}

void ProductsDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";
    rh.OutputHeaders();

    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);

    if (rh.Body.length() > 0)
    {
        Tilc::Data::TDataProcessor::DeleteItems(rh.os, DB,
            "DELETE FROM products WHERE id IN (%s)",
            rh.Body
        );
    }

    Tilc::Data::TDataProcessor::PrintList(rh.os, DB,
        "SELECT %s FROM products",
        {
            "id", "name", "slug", "name_en", "price", "price_1", "price_2", "price_3", "product_code", "short_description", "full_description",
            "mini_map_file", "css_class", "created", "modified"
        }
    );
}
