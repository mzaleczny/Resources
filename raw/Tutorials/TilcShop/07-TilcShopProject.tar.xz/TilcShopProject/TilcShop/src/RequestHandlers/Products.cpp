#include "Products.h"
#include "../config.h"
#include "Tilc/Data/DbMySQL.h"
#include "Tilc/Utils/VectorContainer.h"

void ProductsList(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh.ContentType = "application/json";

    Tilc::Data::TDBDataRows Data;
    Tilc::Data::TDBMySQL DB(DBHost, DBName, DBUser, DBPasswd, DBSocket);
    DB.Select("SELECT * FROM prodcts", Data);
    rh << "{\"items\":";
    Tilc::PrintVectorAsJsonArray(rh.os,
        {"id", "name", "slug", "name_en", "price", "price_1", "price_2", "price_3", "product_code", "short_description", "full_descripion",
         "mini_map_file", "css_class", "created", "modified"},
        Data);
    rh << ",\"items_count\":\"" << Data.size() << "\"}";
}

void ProductsAdd(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsAdd" << "<br/>";
}

void ProductsUpdate(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsUpdate" << "<br/>";
}

void ProductsDelete(Tilc::Apps::Www::TRequestHandler& rh, const Tilc::TExtString Url)
{
    rh << "Action taken: ProductsDelete" << "<br/>";
}
