#include <iostream>
#include <string>
#include <thread>
#include <string_view>
#include <fstream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <fcgio.h>
#include <fcgiapp.h>
#include <unistd.h>
#include "Tilc/Tilc.h"
#include "Tilc/Apps/Www/RequestHandler.h"

#include "RequestHandlers/Categories.h"
#include "RequestHandlers/Products.h"

#include "config.h"
#include "Tilc/Data/DbMySQL.h"

int main()
{
    FCGX_Request request;

    FCGX_Init();
    FCGX_InitRequest(&request, 0, 0);

    Tilc::InitTilc();
    Tilc::Apps::Www::Application = new Tilc::Apps::Www::TWwwApp("/var/www/shop.pl", "Shop", "shop", "");
    if (!Tilc::Apps::Www::Application)
    {
        Tilc::CleanupTilc();
        return 0;
    }
    Tilc::Apps::Www::Application->AddAvailableLanguages({"pl", "en"});

    Tilc::Apps::Www::TRoutes Routes;
    Routes["/categories/list"] = &CategoriesList;
    Routes["/categories/add"] = &CategoriesAdd;
    Routes["/categories/update"] = &CategoriesUpdate;
    Routes["/categories/delete"] = &CategoriesDelete;
    
    Routes["/products/list"] = &ProductsList;
    Routes["/products/add"] = &ProductsAdd;
    Routes["/products/update"] = &ProductsUpdate;
    Routes["/products/delete"] = &ProductsDelete;

    while (FCGX_Accept_r(&request) == 0)
    {
        Tilc::Apps::Www::TRequestHandler rh(&request, Routes);

        rh.HandleRequest();
    }

    if (Tilc::Apps::Www::Application)
    {
        delete Tilc::Apps::Www::Application;
        Tilc::Apps::Www::Application = nullptr;
    }

    Tilc::CleanupTilc();
}
