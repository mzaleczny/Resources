@echo off

cls
REM rmdir /Q /S out
emcmake cmake -DCMAKE_CXX_COMPILER=em++ -DCMAKE_C_COMPILER=emcc -DCMAKE_INSTALL_PREFIX=D:/wasm -DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
copy out\Tilc\configure.h Tilc\src\Tilc\configure.h

rmdir /Q /S out\TilcDemo

cmake --build out\Tilc -j8
copy out\Tilc\libTilc.a ..\lib\libTilc.a

cmake --build out\TilcDemo -j8

REM cmake --install out
