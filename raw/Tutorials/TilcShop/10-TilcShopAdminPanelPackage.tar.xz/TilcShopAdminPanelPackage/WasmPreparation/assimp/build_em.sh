#!/bin/bash

CurDir=$( pwd )

cp build_em_PATCHED_CMakeLists.txt $HOME/wasm/repos/assimp/CMakeLists.txt
cd $HOME/wasm/repos/assimp

if [ ! -d out ]; then
  emcmake cmake \
    -DASSIMP_BUILD_TESTS=OFF \
    -DASSIMP_BUILD_ASSIMP_TOOLS=OFF \
    -DASSIMP_BUILD_SAMPLES=OFF \
    -DASSIMP_BUILD_SHARED_LIBS=OFF \
    -DBUILD_SHARED_LIBS=OFF \
    -DASSIMP_BUILD_STATIC_LIBS=ON \
    -DASSIMP_NO_EXPORT=ON \
    -DASSIMP_BUILD_NO_EXPORT=ON \
    -DASSIMP_BUILD_SINGLE_FILE=ON \
    -DASSIMP_BUILD_ALL_IMPORTERS_BY_DEFAULT=ON \
    -DASSIMP_BUILD_ALL_EXPORTERS_BY_DEFAULT=OFF \
    -DASSIMP_BUILD_ZLIB=ON \
    -DCMAKE_CXX_COMPILER=clang++ \
    -DCMAKE_C_COMPILER=clang \
    -DCMAKE_MODULE_PATH=$HOME/wasm/lib/cmake \
    -DCMAKE_INSTALL_PREFIX=$HOME/wasm \
    -Dzlib_DIR=$HOME/wasm/lib/cmake/zlib \
    -DCMAKE_BUILD_TYPE=MinSizeRel \
    -S . \
    -B out

  cmake --build out -j8
fi

cmake --install out
