#!/bin/bash

CurDir=$( pwd )

cp sdlttf_CMakeLists.txt $HOME/wasm/repos/SDL_ttf/CMakeLists.txt
cd $HOME/wasm/repos/SDL_ttf

if [ ! -d out ]; then
  emcmake cmake -DSDLTTF_VENDORED=OFF \
    -DSDLTTF_HARFBUZZ_VENDORED=OFF \
    -DSDLTTF_FREETYPE_VENDORED=OFF \
    -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang \
    -DCMAKE_PREFIX_PATH="$HOME/wasm" \
    -DCMAKE_INSTALL_PREFIX="$HOME/wasm" \
    -DCMAKE_MODULE_PATH=D:/wasm/lib/cmake \
    -DSDL3_DIR="$HOME/wasm/lib/cmake/SDL3" \
    -DFreetype_DIR=D:/wasm/lib/cmake/Freetype \
    -DSDLTTF_EXAMPLES=OFF -DSDLTTF_TESTS=OFF -DSDLTTF_TOOLS=OFF \
    -DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
  cmake --build out -j8
fi

cmake --install out
cp out/external/freetype-build/libfreetype.a ../../lib/libfreetype.a
cp out/external/harfbuzz-build/libharfbuzz.a ../../lib/libharfbuzz.a
cp out/external/plutosvg-guild/libplutosvg.a ../../lib/libplutosvg.a
cp out/external/plutovg-build/libplutovg.a ../../lib/libplutovg.a

cd "$CurDir"
