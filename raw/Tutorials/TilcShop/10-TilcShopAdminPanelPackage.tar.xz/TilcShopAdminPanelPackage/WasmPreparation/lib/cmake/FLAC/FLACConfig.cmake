set(FLAC_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../repos/SDL_mixer/external/flac/include")
set(FLAC_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libFLAC.a")

if(NOT TARGET FLAC::FLAC)
    add_library(FLAC::FLAC STATIC IMPORTED)
    set_target_properties(FLAC::FLAC PROPERTIES
        IMPORTED_LOCATION "${FLAC_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${FLAC_INCLUDE_DIR}"
    )
endif()
