set(OGG_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../include")
set(OGG_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libogg.a")

if(NOT TARGET Ogg::ogg)
    add_library(Ogg::ogg STATIC IMPORTED)
    set_target_properties(Ogg::ogg PROPERTIES
        IMPORTED_LOCATION "${OGG_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${OGG_INCLUDE_DIR}"
    )
endif()
