set(OGG_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/ogg/../../../include")
set(OGG_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/ogg/../../../lib/libogg.a")

include("${CMAKE_CURRENT_LIST_DIR}/ogg/oggConfig.cmake")


include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(Ogg DEFAULT_MSG OGG_LIBRARY OGG_INCLUDE_DIR)

if(Ogg_FOUND AND NOT TARGET Ogg::ogg)
    add_library(Ogg::ogg STATIC IMPORTED)
    set_target_properties(Ogg::ogg PROPERTIES
        IMPORTED_LOCATION "${OGG_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${OGG_INCLUDE_DIR}"
    )
endif()

# MODULE mode variables expected by FLAC
set(OGG_FOUND TRUE)
set(Ogg_FOUND TRUE)
