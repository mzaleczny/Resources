set(VORBISFILE_INCLUDE_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../include")
set(VORBISFILE_LIBRARY "${CMAKE_CURRENT_LIST_DIR}/../../../lib/libvorbisfile.a")

if(NOT TARGET Vorbis::vorbisfile)
    add_library(Vorbis::vorbisfile STATIC IMPORTED)
    set_target_properties(Vorbis::vorbisfile PROPERTIES
        IMPORTED_LOCATION "${VORBISFILE_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${VORBISFILE_INCLUDE_DIR}"
    )
endif()
