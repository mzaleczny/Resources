message("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
# Force CONFIG mode instead of MODULE mode
include("${mpg123_DIR}/mpg123Config.cmake")
