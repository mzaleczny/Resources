# Force CONFIG mode instead of MODULE mode
include("${Opus_DIR}/OpusConfig.cmake")
