/* Minimal config.h for mpg123 on Emscripten */

#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_MEMCPY 1
#define HAVE_MEMMOVE 1
#define HAVE_STRCHR 1
#define HAVE_STRRCHR 1
#define HAVE_STRSTR 1

#define HAVE_FSEEKO 0
#define HAVE_FTELLO 0
#define HAVE_LSEEK 0
#define HAVE_LSEEK64 0
#define HAVE_MMAP 0
#define HAVE_GETTIMEOFDAY 0

#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1

#define HAVE_LIMITS_H 1
#define HAVE_STRING_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STDIO_H 1
#define HAVE_MATH_H 1

#define PACKAGE "mpg123"
#define VERSION "1.32.3"

#define SIZEOF_INT 4
#define SIZEOF_LONG 4
#define SIZEOF_LONG_LONG 8
#define SIZEOF_SHORT 2
#define SIZEOF_FLOAT 4
#define SIZEOF_DOUBLE 8

#define WORDS_BIGENDIAN 0

/* Disable ALL CPU optimizations */
#define OPT_GENERIC 1
#define OPT_I386 0
#define OPT_X86_64 0
#define OPT_ARM 0
#define OPT_NEON 0
#define OPT_ALTIVEC 0
#define HAVE_ALTIVEC_H 0

/* Disable ASM completely */
#define NO_ASM 1

/* Force generic decoder paths */
#define REAL_IS_FLOAT 1

/* Disable safe_realloc / wrap_destroy */
//#define INT123_safe_realloc realloc
//#define INT123_wrap_destroy(x) ((void)0)
