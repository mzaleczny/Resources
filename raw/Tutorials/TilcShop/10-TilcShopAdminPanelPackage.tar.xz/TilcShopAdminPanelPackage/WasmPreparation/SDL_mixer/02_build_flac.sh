#!/bin/bash

CurDir=$( pwd )

cd $HOME/wasm/repos/SDL_mixer/external/flac
if [ ! -d out ]; then
  emcmake cmake \
    -DCMAKE_CXX_COMPILER=clang++ \
    -DCMAKE_C_COMPILER=clang \
    -DCMAKE_PREFIX_PATH=$HOME/wasm \
    -DCMAKE_INSTALL_PREFIX=$HOME/wasm \
    -DCMAKE_MODULE_PATH=$HOME/wasm/lib/cmake \
    -DOgg_DIR=$HOME/wasm/lib/cmake/ogg \
    -DCMAKE_C_FLAGS="-I$HOME/wasm/repos/SDL_mixer/external/mpg123/src/include -I$HOME/wasm/repos/SDL_mixer/external/vorbis/include -I$HOME/wasm/repos/SDL_mixer/external/ogg/include -I$HOME/wasm/repos/SDL_mixer/external/ogg/out/include" \
    -S . -B out
  cmake --build out -j8
fi
cmake --install out

cd "$CurDir"
