#!/bin/bash

CurDir=$( pwd )

cd $HOME/wasm/repos/SDL_mixer/external/ogg
if [ ! -d out ]; then
  emcmake cmake \
    -DCMAKE_CXX_COMPILER=clang++ \
    -DCMAKE_C_COMPILER=clang \
    -DCMAKE_PREFIX_PATH=$HOME/wasm \
    -DCMAKE_INSTALL_PREFIX=$HOME/wasm \
    -DCMAKE_MODULE_PATH=$HOME/wasm/lib/cmake \
    -S . -B out
fi
cmake --build out -j8
cp out/libogg.a $HOME/wasm/lib/

cd "$CurDir"

