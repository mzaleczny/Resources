/* stub_int123.c – stubs for internal mpg123 symbols on Emscripten */

#include "mpg123.h"
#include "mpg123lib_intern.h"
#include "decode.h"
#include "optimize.h"
#include <stdlib.h>

/* ------------------------------------------------------------------ */
/* 1. INT123_safe_realloc                                              */
/* ------------------------------------------------------------------ */

void *INT123_safe_realloc(void *ptr, size_t size)
{
    return realloc(ptr, size);
}

/* ------------------------------------------------------------------ */
/* 2. INT123_wrap_destroy                                              */
/* ------------------------------------------------------------------ */

void INT123_wrap_destroy(void *handle)
{
    (void)handle;
}

/* ------------------------------------------------------------------ */
/* 3. INT123_do_equalizer                                              */
/* ------------------------------------------------------------------ */

void INT123_do_equalizer(real *bandPtr, int channel, real equalizer[2][32])
{
    (void)bandPtr;
    (void)channel;
    (void)equalizer;
}

/* ------------------------------------------------------------------ */
/* 4. INT123_dct36_neon                                                */
/* ------------------------------------------------------------------ */

void INT123_dct36_neon(real *in, real *out, int count, int count2, int count3)
{
    (void)in;
    (void)out;
    (void)count;
    (void)count2;
    (void)count3;
}

/* ------------------------------------------------------------------ */
/* 5. INT123_dct64_i386                                                */
/* ------------------------------------------------------------------ */

void INT123_dct64_i386(real *in, real *out, real *third)
{
    (void)in;
    (void)out;
    (void)third;
}

/* ------------------------------------------------------------------ */
/* 6. INT123_frame_cpu_opt                                             */
/* ------------------------------------------------------------------ */

int INT123_frame_cpu_opt(mpg123_handle *fr, const char* cpu)
{
    (void)fr;
    (void)cpu;
    return 0;
}

/* ------------------------------------------------------------------ */
/* 7. INT123_set_synth_functions                                       */
/* ------------------------------------------------------------------ */

int INT123_set_synth_functions(mpg123_handle *fr)
{
    (void)fr;
    return 0;
}

/* ------------------------------------------------------------------ */
/* 8. INT123_defdec                                                    */
/* ------------------------------------------------------------------ */

enum optdec INT123_defdec(void)
{
    return OPT_GENERIC;
}

/* ------------------------------------------------------------------ */
/* 9. INT123_decclass                                                  */
/* ------------------------------------------------------------------ */

enum optcla INT123_decclass(const enum optdec o){
    (void)o;
    return normal;
}
