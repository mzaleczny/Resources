#!/bin/bash

CurDir=$( pwd )

cp 03_build_mpg123_STUB.c $HOME/wasm/repos/SDL_mixer/external/mpg123/src/libmpg123/stub_int123.c
cp 03_build_mpg123_config.h $HOME/wasm/repos/SDL_mixer/external/mpg123/src/config.h

cd $HOME/wasm/repos/SDL_mixer/external/mpg123/src/libmpg123

if [ ! f "$HOME/wasm/lib/libmpg123.a" ]; then
  emcc -O3 -c -I../ -I../../ -I$HOME/wasm/repos/SDL_mixer/external/mpg123/src/include -I$HOME/wasm/repos/SDL_mixer/external/mpg123/src \
    dct64.c \
    format.c \
    frame.c \
    id3.c \
    icy.c \
    layer1.c \
    layer2.c \
    layer3.c \
    libmpg123.c \
    ntom.c \
    parse.c \
    readers.c \
    stringbuf.c \
    synth.c \
    synth_8bit.c \
    stub_int123.c \
    tabinit.c

  emar rcs libmpg123.a *.o
  cp libmpg123.a $HOME/wasm/lib/
  rm *.o libmpg123.a
fi

cd "$CurDir"
