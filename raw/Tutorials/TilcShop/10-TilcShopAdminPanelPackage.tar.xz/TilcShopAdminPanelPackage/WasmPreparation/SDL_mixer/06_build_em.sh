#!/bin/bash

CurDir=$( pwd )

cd $HOME/wasm/repos/SDL_mixer

if [ ! -d out ]; then
  emcmake cmake \
    -DCMAKE_CXX_COMPILER=clang++ \
    -DCMAKE_C_COMPILER=clang \
    -DCMAKE_PREFIX_PATH=$HOME/wasm \
    -DCMAKE_INSTALL_PREFIX=$HOME/wasm \
    -DCMAKE_MODULE_PATH=$HOME/wasm/lib/cmake \
    -DSDL_MIXER_OPUSFILE=OFF \
    -DSDL3_DIR=$HOME/wasm/lib/cmake/SDL3 \
    -DOgg_DIR=$HOME/wasm/lib/cmake/ogg \
    -DVorbis_DIR=$HOME/wasm/lib/cmake/vorbis \
    -DOpus_DIR=$HOME/wasm/lib/cmake/Opus \
    -DVorbisFile_DIR=$HOME/wasm/lib/cmake/vorbisfile \
    -Dmpg123_DIR=$HOME/wasm/lib/cmake/mpg123 \
    -DFLAC_DIR=$HOME/wasm/lib/cmake/FLAC \
    -DSDLMIXER_EXAMPLES=OFF -DSDLMIXER_TESTS=OFF -DSDLMIXER_TOOLS=OFF \
    -DCMAKE_BUILD_TYPE=MinSizeRel \
    -DCMAKE_C_FLAGS="-I$HOME/wasm/repos/SDL_mixer/external/mpg123/src/include -I$HOME/wasm/repos/SDL_mixer/external/vorbis/include -I$HOME/wasm/repos/SDL_mixer/external/ogg/include -I$HOME/wasm/repos/SDL_mixer/external/ogg/out/include" \
    -S . -B out
fi
cmake --build out -j8
cmake --install out

cd "$CurDir"
