#!/bin/bash

WasmDir=$HOME/wasm

rm -rf "$WasmDir/include"
rm -rf "$WasmDir/lib"
rm -rf "$WasmDir/share"

rm -rf "$WasmDir/repos/SDL3/out"
rm -rf "$WasmDir/repos/SDL3_image/out"
rm -rf "$WasmDir/repos/SDL3_ttf/out"
rm -rf "$WasmDir/repos/SDL3_mixer/out"
rm -rf "$WasmDir/repos/assimp/out"
