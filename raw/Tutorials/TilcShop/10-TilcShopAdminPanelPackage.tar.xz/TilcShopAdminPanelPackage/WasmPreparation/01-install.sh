#!/bin/bash

sudo apt install libasound2-dev libjack-dev libpipewire-0.3-dev libpulse-dev libsndio-dev libdrm-dev libgbm-dev libfribidi-dev \
		libthai-dev libunwind-dev libusb-1.0-0-dev libgl-dev libegl-dev \
		libwayland-dev libwayland-egl-backend-dev libwayland-cursor++1 \
		libxkbcommon-dev libdecor-0-dev

