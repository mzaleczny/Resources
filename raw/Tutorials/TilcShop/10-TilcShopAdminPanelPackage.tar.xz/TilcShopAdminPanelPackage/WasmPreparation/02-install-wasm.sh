#!/bin/bash

WasmDir=$HOME/wasm
CurDir=$( pwd )
mkdir -p $WasmDir/repos

cd $HOME/wasm/repos
if [ ! -d SDL ]; then
    git clone --branch release-3.4.x --single-branch https://github.com/libsdl-org/SDL.git
fi
if [ ! -d SDL_ttf ]; then
    git clone --branch release-3.2.x --single-branch --recurse-submodules -j4 https://github.com/libsdl-org/SDL_ttf.git
fi
if [ ! -d SDL_image ]; then
    git clone --branch release-3.4.x --single-branch --recurse-submodules -j4 https://github.com/libsdl-org/SDL_image.git
fi
if [ ! -d SDL_mixer ]; then
    git clone --branch release-3.2.x --single-branch --recurse-submodules -j4 https://github.com/libsdl-org/SDL_mixer.git
fi

if [ ! -d glm ]; then
    git clone --recurse-submodules -j4 https://github.com/g-truc/glm.git
fi
if [ ! -d assimp ]; then
    git clone --recurse-submodules -j4 https://github.com/assimp/assimp.git
fi

cp -r $CurDir/glades .
cp -r $CurDir/lib $WasmDir/

cd $CurDir

cd SDL
    ./build_em.sh
cd ..
cd SDL_image
    ./build_em.sh
cd ..
cd SDL_mixer
    ./01_build_ogg.sh
    ./02_build_flac.sh
    ./03_build_mpg123.sh
    ./04_build_vorbis.sh
    ./05_build_opus.sh
    ./06_build_em.sh
cd ..
cd SDL_ttf
    ./build_em.sh
cd ..
cd assimp
    ./build_em.sh
cd ..
