#!/bin/bash

CurDir=$( pwd )

cd $HOME/wasm/repos/SDL_image
if [ ! -d out ]; then
    emcmake cmake -DSDLIMAGE_ZLIB=ON -DSDLIMAGE_PNG=ON -DSDLIMAGE_JPG=ON -DSDLIMAGE_VENDORED=ON \
		-DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang \
		-DCMAKE_MODULE_PATH=$HOME/wasm/lib/cmake \
		-DCMAKE_PREFIX_PATH="$HOME/wasm" -DCMAKE_INSTALL_PREFIX="$HOME/wasm" -DSDL3_DIR="$HOME/wasm/lib/cmake/SDL3" \
		-DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
fi
cmake --build out -j8
cmake --install out

cd "$CurDir"
