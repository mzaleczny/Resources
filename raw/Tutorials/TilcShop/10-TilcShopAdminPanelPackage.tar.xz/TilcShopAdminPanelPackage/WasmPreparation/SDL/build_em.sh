#!/bin/bash

CurDir=$( pwd )

cd $HOME/wasm/repos/SDL
if [ ! -d out ]; then
    emcmake cmake -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang \
		-DCMAKE_INSTALL_PREFIX=$HOME/wasm \
		-DSDL_SHARED=OFF \
		-DSDL_STATIC=ON \
		-DSDL_TESTS=OFF \
		-DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
fi
cmake --build out -j8
cmake --install out

cd "$CurDir"
