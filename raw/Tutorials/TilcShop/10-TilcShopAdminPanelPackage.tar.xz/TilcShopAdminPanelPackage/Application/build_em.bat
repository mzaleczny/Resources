@echo off

cls
rmdir /Q /S out
emcmake cmake -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang -DCMAKE_INSTALL_PREFIX=D:/wasm -DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
cmake --build out -j8
