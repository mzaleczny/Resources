#!/bin/bash

clear
rm -rf out
emcmake cmake -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang \
		-DCMAKE_INSTALL_PREFIX=$HOME/wasm \
		-DCMAKE_C_FLAGS="-I$HOME/wasm/include -I$HOME/wasm/repos/glm -I$HOME/wasm/repos/glades/include -I$HOME/wasm/repos/SDL_ttf/external/freetype/include -I$HOME/wasm/repos/SDL_ttf/external/harfbuzz/src -I$HOME/wasm/repos/SDL_image/out/external/zlib-build -I$HOME/wasm/repos/SDL_image/external/zlib" \
		-DCMAKE_CXX_FLAGS="-I$HOME/wasm/include -I$HOME/wasm/repos/glm -I$HOME/wasm/repos/glades/include -I$HOME/wasm/repos/SDL_ttf/external/freetype/include -I$HOME/wasm/repos/SDL_ttf/external/harfbuzz/src -I$HOME/wasm/repos/SDL_image/out/external/zlib-build -I$HOME/wasm/repos/SDL_image/external/zlib" \
		-DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
cmake --build out -j8
