#!/bin/bash

clear
if [ ! -f out/Tilc/libTilc.a ]; then
  emcmake cmake -DCMAKE_CXX_COMPILER=em++ -DCMAKE_C_COMPILER=emcc \
		-DCMAKE_INSTALL_PREFIX=$HOME/wasm \
		-DCMAKE_C_FLAGS="-I$HOME/wasm/include -I$HOME/wasm/repos/glm -I$HOME/wasm/repos/glades/include -I$HOME/wasm/repos/SDL_ttf/external/freetype/include -I$HOME/wasm/repos/SDL_ttf/external/harfbuzz/src -I$HOME/wasm/repos/SDL_image/out/external/zlib-build -I$HOME/wasm/repos/SDL_image/external/zlib" \
		-DCMAKE_CXX_FLAGS="-I$HOME/wasm/include -I$HOME/wasm/repos/glm -I$HOME/wasm/repos/glades/include -I$HOME/wasm/repos/SDL_ttf/external/freetype/include -I$HOME/wasm/repos/SDL_ttf/external/harfbuzz/src -I$HOME/wasm/repos/SDL_image/out/external/zlib-build -I$HOME/wasm/repos/SDL_image/external/zlib" \
		-DCMAKE_BUILD_TYPE=MinSizeRel -S . -B out
  cp out/Tilc/configure.h Tilc/src/Tilc/configure.h

  cmake --build out/Tilc -j8
fi
cp out/Tilc/libTilc.a $HOME/wasm/lib/libTilc.a

#rm -rf out/Application
#cmake --build out/Application -j8
#cd Application
#    ./build_em.sh
#cd ..
