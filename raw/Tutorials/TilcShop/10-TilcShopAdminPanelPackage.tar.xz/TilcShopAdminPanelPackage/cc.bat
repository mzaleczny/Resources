@echo off

cls
cmake --build out -j8
copy out\Tilc\libTilc.a ..\lib\libTilc.a
