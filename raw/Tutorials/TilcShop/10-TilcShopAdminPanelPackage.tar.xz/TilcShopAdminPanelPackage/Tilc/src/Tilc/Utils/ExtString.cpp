#include "Tilc/Globals.h"
#include "Tilc/Utils/ExtString.h"
#include "Tilc/Utils/ArrayUtils.h"
#include <codecvt>
#include <algorithm>
#include <locale>
#include <ranges>

// --------------------          ą       ć       ę       ł       ń       ó       ś       ź       ż       Ą       Ć       Ę       Ł       Ń       Ó       Ś       Ź       Ż
unsigned char allowed_codes_ansi[] = { 0xb9,   0xe6,   0xea,   0xb3,   0xf1,   0xf3,   0x9c,   0x9f,   0xbf,   0xa5,   0xc6,   0xca,   0xa3,   0xd1,   0xd3,   0x8c,   0x8f,   0xaf };
unsigned char allowed_codes_iso2[] = { 0xb1,   0xe6,   0xea,   0xb3,   0xf1,   0xf3,   0xb6,   0xbc,   0xbf,   0xa1,   0xc6,   0xca,   0xa3,   0xd1,   0xd3,   0xa6,   0xac,   0xaf };
unsigned char allowed_codes_oem_852[] = { 0xa5,   0x86,   0xa9,   0x88,   0xe4,   0xa2,   0x98,   0xab,   0xbe,   0xa4,   0x8f,   0xa8,   0x9d,   0xe3,   0xe0,   0x97,   0x8d,   0xbd };
unsigned short allowed_codes_utf8[] = { 0x85c4, 0x87c4, 0x99c4, 0x82c5, 0x84c5, 0xb3c3, 0x9bc5, 0xbac5, 0xbcc5, 0x84c4, 0x86c4, 0x98c4, 0x81c5, 0x83c5, 0x93c3, 0x9ac5, 0xb9c5, 0xbbc5 };
unsigned short allowed_codes_unicode[] = { 0x0105, 0x0107, 0x0119, 0x0142, 0x0144, 0x00f3, 0x015b, 0x017a, 0x017c, 0x0104, 0x0106, 0x0118, 0x0141, 0x0143, 0x00d3, 0x015a, 0x0179, 0x017b };

const constexpr int FORMAT_PARSING_STATE_NONE = 0;
const constexpr int FORMAT_PARSING_STATE_READFLAGS = 1;
const constexpr int FORMAT_PARSING_STATE_READWIDTH = 2;
const constexpr int FORMAT_PARSING_STATE_READPRECISION = 3;
const constexpr int FORMAT_PARSING_STATE_READTYPE = 4;

const constexpr int FORMAT_DEFAULT_PRECISION = 4;

const constexpr wchar_t* WORD_BOUNDARY_CHARS = L" \t.,;?!";


int Tilc::TExtString::TExtString::LettersArray[] = {
	' ', 'A', 0xc484, //'Ą',
    'B', 'C', 0xc486, //'Ć',
    'D', 'E', 0xc498, //'Ę',
    'F', 'G', 'H', 'I', 'J', 'K', 'L', 0xc581, //'Ł',
    'M', 'N', 0xc583, //'Ń',
    'O', 0xc393, //'Ó',
    'P', 'Q', 'R', 'S', 0xc59a, //'Ś',
    'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 0xc5b9, //'Ź',
    0xc5bb //'Ż'
};

Tilc::TExtString Tilc::TExtString::UnshiftLeft(char ToChar)
{
	Tilc::TExtString Result;
	size_t Pos = find(ToChar);
	if (Pos == std::string::npos)
	{
		Result = *this;
		*this = "";
		return Result;
	}
	Result = substr(0UL, Pos);
	*this = substr(Pos+1);
	return Result;
}

Tilc::TExtString Tilc::TExtString::UnshiftRight(char ToChar)
{
	Tilc::TExtString Result;
	size_t Pos = rfind(ToChar);
	if (Pos == std::string::npos)
	{
		Result = *this;
		*this = "";
		return Result;
	}
	Result = substr(Pos+1);
	*this = substr(0UL, Pos);
	return Result;
}

size_t Tilc::TExtString::Explode(char Explodechar, std::vector<Tilc::TExtString>& Items)
{
	char ch;
	Tilc::TExtString CurrentString = "";
	Items.clear();
	const char* String = c_str();
	for (size_t i = 0; i < length(); i++)
	{
		ch = String[i];
		if (ch == Explodechar)
		{
			Items.push_back(CurrentString);
			CurrentString = "";
		}
		else
		{
			CurrentString += ch;
		}
	}
	if (CurrentString.length() > 0)
	{
		Items.push_back(CurrentString);
	}

	return Items.size();
}

size_t Tilc::TExtString::Explode(const Tilc::TExtString& ExplodeString, std::vector<Tilc::TExtString>& Items)
{
	Tilc::TExtString CurrentString = "";
	Items.clear();
	size_t Pos = 0;
	size_t CurrentPos = 0;
	while ((Pos = find(ExplodeString.c_str(), CurrentPos)) != Tilc::TExtString::npos)
	{
		CurrentString = substr(CurrentPos, Pos - CurrentPos);
		Items.push_back(CurrentString);
		CurrentPos = Pos + ExplodeString.length();
	}
	if (CurrentPos < length())
	{
		Items.push_back(substr(CurrentPos));
	}
	return Items.size();
}

std::wstring Tilc::TExtString::ToWideString(unsigned int CodePage)
{
    /*
	// deal with trivial case of empty string
	if (empty())
	{
		return std::wstring();
	}

	// determine required length of new string
	size_t RequiredLength = ::MultiByteToWideChar(CodePage, 0, c_str(), static_cast<int>(length()), 0, 0);

	// construct new string of required length
	std::wstring Destination(RequiredLength, L'\0');

	// convert old string to new string
	::MultiByteToWideChar(CodePage, 0, c_str(), static_cast<int>(length()), &Destination[0], static_cast<int>(Destination.length()));

	// return new string ( compiler should optimize this away )
	return Destination;
    */
    return std::wstring();
}

const char* Tilc::TExtString::FromWideString(const std::wstring& Source, unsigned int CodePage)
{
    /*
	// deal with trivial case of empty string
	if (Source.empty())
	{
		assign("");
		return c_str();
	}

	// determine required length of new string
	size_t RequiredLength = ::WideCharToMultiByte(CodePage, 0, Source.c_str(), static_cast<int>(Source.length()), 0, 0, NULL, NULL);

	// construct new string of required length
	resize(RequiredLength, '\0');

	// convert old string to new string
	::WideCharToMultiByte(CodePage, 0, Source.c_str(), static_cast<int>(Source.length()), &(*this)[0], static_cast<int>(RequiredLength), NULL, NULL);
    */
	return c_str();
}

const char* Tilc::TExtString::FromWideString(const wchar_t* Source, size_t SourceLength, unsigned int CodePage)
{
    /*
	// deal with trivial case of empty string
	if (!Source || SourceLength < 1)
	{
		assign("");
		return c_str();
	}

	// determine required length of new string
	size_t RequiredLength = ::WideCharToMultiByte(CodePage, 0, Source, static_cast<int>(SourceLength), 0, 0, NULL, NULL);

	// construct new string of required length
	resize(RequiredLength, '\0');

	// convert old string to new string
	::WideCharToMultiByte(CodePage, 0, Source, static_cast<int>(SourceLength), &(*this)[0], static_cast<int>(RequiredLength), NULL, NULL);
    */
	return c_str();
}

Tilc::TExtString Tilc::TExtString::SplitIntoMultiline(int MaxcharCount)
{
	Tilc::TExtString Result;
	if (length() <= MaxcharCount)
	{
		return *this;
	}

	int LastStartLinePos = 0;
	int LastWordBreakPos = 0;
	const char* Source = c_str();
	size_t Pos = 0;
	while (Pos < length())
	{
		if (Pos - LastStartLinePos < MaxcharCount)
		{
			if (Pos > 0 && (Source[Pos] == ' ' || Source[Pos] == '\n' || Source[Pos] == '\t'))
			{
				LastWordBreakPos = static_cast<int>(Pos);
			}
			Pos++;
		}
		else {
			Result += substr(LastStartLinePos, LastWordBreakPos - LastStartLinePos) + "\n";
			Pos = LastWordBreakPos + 1;
			LastStartLinePos = static_cast<int>(Pos);
		}
	}
	Result += substr(LastStartLinePos);
	return Result;
}

const char* Tilc::TExtString::FromUtf8(const char* utf8str, const std::locale& loc)
{
	/*
	// UTF-8 to wstring
	std::wstring_convert<std::codecvt_utf8<wchar_t>> wconv;
	std::wstring wstr = wconv.from_unsigned chars(utf8str);
	// wstring to string
	std::vector<char> buf(wstr.size());
	std::use_facet<std::ctype<wchar_t>>(loc).narrow(wstr.data(), wstr.data() + wstr.size(), '?', buf.data());
	assign(buf.data(), buf.size());
	*/
	return c_str();
}

const char* Tilc::TExtString::AnsiToUtf8(const char* AnsiStr)
{
	/*
	std::locale loc(".1250");
	size_t len = strlen(AnsiStr);
	if (len < 1)
	{
		return "";
	}

	std::vector<wchar_t> buf(len);
	use_facet<std::ctype<wchar_t>>(loc).widen(AnsiStr, AnsiStr + len, buf.data());

	std::wstring ws(buf.data(), buf.size());
	std::wstring_convert<std::codecvt_utf8<wchar_t>> wconv;
	assign(wconv.to_unsigned chars(ws));
	*/
	return c_str();
}

const char* Tilc::TExtString::AnsiPlcharToUtf8PlString(char plchar)
{
	switch (plchar)
	{
	case '\xa5': return UTF8_PL_A;
	case '\xc6': return UTF8_PL_C;
	case '\xca': return UTF8_PL_E;
	case '\xa3': return UTF8_PL_L;
	case '\xd1': return UTF8_PL_N;
	case '\xd3': return UTF8_PL_O;
	case '\x8c': return UTF8_PL_S;
	case '\x8f': return UTF8_PL_Z1;
	case '\xaf': return UTF8_PL_Z2;
	}
	return "";
}

const char* Tilc::TExtString::ToUppercase()
{
	std::transform(begin(), end(), begin(), ::toupper);
	return c_str();
}

const char* Tilc::TExtString::ToLowercase()
{
	std::transform(begin(), end(), begin(), ::tolower);
	return c_str();
}

const char* Tilc::TExtString::StrReplace(Tilc::TExtString What, Tilc::TExtString ReplaceWith)
{
	size_t pos1, pos2;

	pos1 = 0UL;
	while ((pos1 = find(What, pos1)) != Tilc::TExtString::npos)
	{
		pos2 = pos1 + What.length();
		if (pos2 > length())
		{
			pos2 = length();
		}
		*this = substr(0, pos1) + ReplaceWith + substr(pos2);
		pos1 += ReplaceWith.length();
	}
	return c_str();
}

bool Tilc::TExtString::IsUtf8PL()
{
	// Jeśli w tekscie nie ma zadnej litery UTF-8 PL, to zakladamy ze jest kodowany w ANSI i konwertujemy go na UTF-8
	if (find(UTF8_PL_A_SM) == Tilc::TExtString::npos && find(UTF8_PL_C_SM) == Tilc::TExtString::npos &&
		find(UTF8_PL_E_SM) == Tilc::TExtString::npos && find(UTF8_PL_L_SM) == Tilc::TExtString::npos &&
		find(UTF8_PL_N_SM) == Tilc::TExtString::npos && find(UTF8_PL_O_SM) == Tilc::TExtString::npos &&
		find(UTF8_PL_S_SM) == Tilc::TExtString::npos && find(UTF8_PL_Z1_SM) == Tilc::TExtString::npos &&
		find(UTF8_PL_Z2_SM) == Tilc::TExtString::npos &&
		find(UTF8_PL_A) == Tilc::TExtString::npos && find(UTF8_PL_C) == Tilc::TExtString::npos &&
		find(UTF8_PL_E) == Tilc::TExtString::npos && find(UTF8_PL_L) == Tilc::TExtString::npos &&
		find(UTF8_PL_N) == Tilc::TExtString::npos && find(UTF8_PL_O) == Tilc::TExtString::npos &&
		find(UTF8_PL_S) == Tilc::TExtString::npos && find(UTF8_PL_Z1) == Tilc::TExtString::npos &&
		find(UTF8_PL_Z2) == Tilc::TExtString::npos)
	{
		return false;
	}
	return true;
}


bool Tilc::TExtString::isInt() const
{
    if (empty())
    {
        return false;
    }

    bool retval = true;
    size_t i = 0;
    size_t len = this->length();
    if (i < len && (this->c_str()[i] == '-' || this->c_str()[i] == '+'))
    {
        i++;
    }
    // jeśli łańcuch składa się z samego minusa lub plusa, to nie jest to liczba
    if (i == len)
    {
        return false;
    }

    for (; i < len; i++)
    {
        if (!iswdigit(this->c_str()[i]))
        {
            retval = false;
            break;
        }
    }

    return retval;
}

bool Tilc::TExtString::isDouble() const
{
    bool retval = true;
    bool decsep_found = false;
    size_t i = 0;
    size_t len = this->length();

    if (i < len && (this->c_str()[i] == '-' || this->c_str()[i] == '+'))
    {
        ++i;
    }
    // jeśli łańcuch składa się z samego minusa lub plusa, to nie jest to liczba
    if (i == len)
    {
        return false;
    }
    if (i < len && (this->c_str()[i] == ',' || this->c_str()[i] == '.'))
    {
        i++;
        decsep_found = true;
    }

    for (; i < len; i++)
    {
        if (iswdigit(this->c_str()[i]))
        {
            continue;
        }
        if ((this->c_str()[i] == ',' || this->c_str()[i] == '.') && !decsep_found)
        {
            decsep_found = true;
            continue;
        }
        retval = false;
        break;
    }

    return retval;
}


bool Tilc::TExtString::isNumeric(bool* isInt, bool* isDouble) const
{
    bool _isInt = true;
    bool _isDouble = true;
    //BOOL retval = true;
    bool decsep_found = false;
    size_t i = 0;
    size_t len = std::strlen(c_str());
    //CLocale* locale = new CLocale();

    if (i < len && (this->c_str()[i] == '-' || this->c_str()[i] == '+'))
    {
        ++i;
    }
    // jeśli łańcuch składa się z samego minusa lub plusa, to nie jest to liczba
    if (i == len)
    {
        *isInt = false;
        *isDouble = false;
        return false;
    }
    if (i < len && (this->c_str()[i] == ',' || this->c_str()[i] == '.'))
    {
        i++;
        decsep_found = true;
        _isInt = false;
    }

    for (; i < len; i++)
    {
        if (iswdigit(this->c_str()[i]))
        {
            continue;
        }
        if ((this->c_str()[i] == ',' || this->c_str()[i] == '.') && !decsep_found)
        {
            decsep_found = true;
            _isInt = false;
            continue;
        }
        _isDouble = false;
        _isInt = false;
        break;
    }

    if (isInt)
    {
        *isInt = _isInt;
    }
    if (isDouble)
    {
        *isDouble = _isDouble;
    }

    return _isInt || _isDouble;
}


inline Tilc::TExtString Tilc::TExtString::WidecharToString(wchar_t Widechar, unsigned int CodePage)
{
	Tilc::TExtString Result;
	Result.FromWideString(std::wstring(1, Widechar), CodePage);
	return Result;
}

void Tilc::TExtString::RTrim(char ch)
{
	size_t len = this->length();
	if (len > 0)
	{
		size_t i = len - 1;
		while (i >= 0 && (*this)[i] == ch)
		{
			(*this)[i] = '\0';
			i--;
		}
	}
}

void Tilc::TExtString::RTrimAllChars(const char* StringOfChars)
{
	size_t len = this->length();
	if (len > 0)
	{
		size_t i = len - 1;
		while (i >= 0 && strchr(StringOfChars, (*this)[i]) != nullptr)
		{
			(*this)[i] = '\0';
			i--;
		}
	}
}

void Tilc::TExtString::LTrim(char ch)
{
	size_t start_pos = 0;
	size_t len = this->length();
	while (start_pos < len && (*this)[start_pos] == ch)
	{
		start_pos++;
	}

	if (start_pos == this->length())
	{
		*this = "";
		return;
	}

    Tilc::TExtString Result{ &((*this)[start_pos]) };
	*this = Result;
}

void Tilc::TExtString::LTrimAllChars(const char* StringOfChars)
{
	size_t start_pos = 0;
	size_t len = this->length();
	while (start_pos < len && strchr(StringOfChars, (*this)[start_pos]) != nullptr)
	{
		start_pos++;
	}

	if (start_pos == this->length())
	{
        *this = "";
        return;
    }

    Tilc::TExtString Result{ &((*this)[start_pos]) };
    *this = Result;
}


void Tilc::TExtString::CutAtLast(char ch)
{
	size_t pos = length() - 1;
	while (pos >= 0 && c_str()[pos] != ch)
	{
		pos--;
	}

	if (pos >= 0)
	{
        *this = substr(0, pos);
	}
}

void Tilc::TExtString::CutAtLastchar(const char* StringOfChars)
{
	if (!StringOfChars || StringOfChars[0] == '\0')
	{
		return;
	}

	size_t len = length();
	if (len > 0)
	{
		size_t pos = len - 1;
		char ch;
		size_t len = strlen(StringOfChars);
		bool breakLoop = false;

		while (pos >= 0)
		{
			for (size_t i = 0; i < len; ++i)
			{
				ch = StringOfChars[i];
				if (c_str()[pos] == ch)
				{
					breakLoop = true;
					break;
				}
			}

			if (breakLoop)
			{
				break;
			}

			pos--;
		}

		if (pos >= 0)
		{
            *this = substr(0, pos);
		}
	}
}

Tilc::TExtString Tilc::TExtString::StrAfterLast(char ch)
{
	size_t len = length();
	if (len > 0)
	{
		size_t pos = len - 1;
		while (pos >= 0 && c_str()[pos] != ch)
		{
			pos--;
		}

		if (pos == this->length() - 1)
		{
			return "";
		}

		if (pos >= 0)
		{
			return substr(pos + 1);
		}
	}

	return "";
}

Tilc::TExtString Tilc::TExtString::StrAfterLastchar(const char* StringOfChars)
{
	if (!StringOfChars || StringOfChars[0] == '\0')
	{
		return "";
	}

	size_t thislen = length();
	if (thislen > 0)
	{
		size_t pos = thislen - 1;
		size_t len = strlen(StringOfChars);
		char ch;
		bool breakLoop = false;

		while (pos >= 0)
		{
			for (size_t i = 0; i < len; i++)
			{
				ch = StringOfChars[i];
				if (c_str()[pos] == ch)
				{
					breakLoop = true;
					break;
				}
			}
			if (breakLoop)
			{
				break;
			}
			pos--;
		}

		if (pos == thislen - 1)
		{
			return "";
		}

		if (pos >= 0)
		{
			return substr(pos + 1);
		}
	}

	return "";
}

void Tilc::TExtString::InsertAt(size_t pos, const TExtString& s)
{
    if (pos == 0)
    {
        *this = s + *this;
    }
    else if (pos < length())
    {
        *this = substr(0, pos) + s + substr(pos);
    }
    else
    {
        append(s.c_str());
    }
}

void Tilc::TExtString::DeleteCharAt(size_t pos)
{
    size_t str_len = length();
    if (pos < str_len)
    {
        if (str_len == 1)
        {
            *this = "";
            return;
        }
        *this = substr(0, pos) + substr(pos + 1);
    }
}

int Tilc::TExtString::DeleteSingleUtf8CharBeforePos(size_t pos)
{
    size_t str_len = length();
    if (str_len > 0 && pos > 0 && pos <= str_len)
    {
        if (str_len == 1)
        {
            *this = "";
            return 1;
        }
        size_t CurrentPos = pos - 1;
        while (CurrentPos >= 0 && IsUtf8ContinuationByte(c_str()[CurrentPos]))
        {
            --CurrentPos;
        }
        if (CurrentPos > 0 && pos < str_len)
        {
            *this = substr(0, CurrentPos) + substr(pos);
        }
        else if (CurrentPos > 0)
        {
            *this = substr(0, CurrentPos);
        }
        else if (pos < str_len)
        {
            *this = substr(pos);
        }
        else
        {
            *this = "";
        }
        return pos - CurrentPos;
    }
    return 0;
}

int Tilc::TExtString::DeleteSingleUtf8CharAtPos(size_t pos)
{
    size_t str_len = length();
    if (str_len > 0 && pos >= 0 && pos < str_len)
    {
        if (str_len == 1)
        {
            *this = "";
            return 1;
        }
        size_t CurrentPos = pos + 1;
        while (CurrentPos < str_len && IsUtf8ContinuationByte(c_str()[CurrentPos]))
        {
            ++CurrentPos;
        }
        if (pos == 0)
        {
            *this = substr(CurrentPos);
        }
        else if (pos < str_len)
        {
            if (CurrentPos < str_len)
            {
                *this = substr(0, pos) + substr(CurrentPos);
            }
            else
            {
                *this = substr(0, pos);
            }
        }
        else
        {
            *this = substr(pos);
        }
        return CurrentPos - pos;
    }
    return 0;
}


Tilc::TExtString& Tilc::TExtString::Prepend(TExtString& s)
{
	return Prepend(s.c_str());
}

Tilc::TExtString& Tilc::TExtString::Prepend(const char* s)
{
	if (s)
	{
		*this = s + *this;
	}

	return *this;
}

Tilc::TExtString& Tilc::TExtString::Prepend(char ch)
{
	*this = ch + *this;
	return *this;
}

Tilc::TExtString& Tilc::TExtString::Prepend(int num)
{
	*this = std::to_string(num) + *this;
	return *this;
}

Tilc::TExtString& Tilc::TExtString::Prepend(unsigned int num)
{
	*this = std::to_string(num) + *this;
	return *this;
}

Tilc::TExtString& Tilc::TExtString::Prepend(float num)
{
	*this = std::to_string(num) + *this;
	return *this;
}


size_t Tilc::TExtString::LinesCount()
{
	size_t count = 0;
	if (length() > 0)
	{
		count = 1;
	}

	size_t len = length();
	for (size_t i = 0; i < len; i++)
	{
		if (c_str()[i] == L'\n')
		{
			count++;
		}
	}

	return count;
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(Tilc::TExtString& s)
{
	return PrependEachLine(s.c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(const char* s)
{
	if (s)
	{
		size_t s_len = strlen(s);
		size_t this_len = length();
		if (s_len > 0)
		{
			size_t linesCount = LinesCount();
			if (linesCount == 0)
			{
				linesCount = 1;
			}

			size_t extrachars = linesCount * s_len;
			size_t new_buf_size = this_len + extrachars;
			TExtString new_buf;
			new_buf.reserve(new_buf_size);

			size_t src_i;
			size_t dst_i;

			new_buf = s;
			dst_i = s_len;
			for (src_i = 0; src_i < this_len; ++src_i)
			{
				new_buf[dst_i] = c_str()[src_i];
				dst_i++;
				if (c_str()[src_i] == '\n' && src_i + 1 < this_len)
				{
					new_buf += s;
					dst_i += s_len;
				}
			}

			*this = new_buf;
		}
	}

	return *this;
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(char ch)
{
	return PrependEachLine(std::to_string(ch).c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(int num)
{
	return PrependEachLine(std::to_string(num).c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(unsigned int num)
{
	return PrependEachLine(std::to_string(num).c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(long long num)
{
	return PrependEachLine(std::to_string(num).c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(unsigned long long num)
{
	return PrependEachLine(std::to_string(num).c_str());
}

Tilc::TExtString& Tilc::TExtString::PrependEachLine(float num)
{
	return PrependEachLine(std::to_string(num).c_str());
}

void Tilc::TExtString::TruncateAtEnd(size_t NumChars)
{
    if (NumChars > 0)
    {
        size_t len = this->length();
        if (NumChars > len) {
            NumChars = len;
        }
        size_t pos = len;
        if (pos > NumChars)
        {
            pos -= NumChars;
        }
        else
        {
            pos = 0;
        }
        if (pos > 0)
        {
            *this = substr(0, pos);
        }
        else
        {
            *this = "";
        }
    }
}

bool Tilc::TExtString::StartsWith(const Tilc::TExtString& s)
{
	return find(s) == 0;
}

bool Tilc::TExtString::StartsWithchar(char ch)
{
	return length() > 0 && c_str()[0] == ch;
}

bool Tilc::TExtString::StartsWithOneOfChars(const char* StringOfChars)
{
	if (length() == 0)
	{
		return false;
	}
	return strchr(StringOfChars, c_str()[0]) != nullptr;
}

bool Tilc::TExtString::EndsWith(const Tilc::TExtString& s)
{
	size_t slen = s.length();
	size_t len = length();
	if (len < slen)
	{
		return false;
	}
	const char* buf = c_str() + len - slen;
	return strstr(buf, s.c_str()) == buf;
}

bool Tilc::TExtString::EndsWithchar(char ch)
{
	size_t len = length();
	if (len > 0)
	{
		return c_str()[len - 1] == ch;
	}
	return false;
}

bool Tilc::TExtString::EndsWithOneOfChars(const char* StringOfChars)
{
	size_t Len = length();
	if (Len == 0)
	{
		return false;
	}
	wchar_t ch = c_str()[Len - 1];
	return strchr(StringOfChars, ch) != nullptr;
}

bool Tilc::TExtString::ContainsOneOfChars(const char* StringOfChars)
{
	size_t Len = length();
	for (size_t i = 0; i < Len; ++i)
	{
		if (strchr(StringOfChars, c_str()[i]) != nullptr)
		{
			return true;
		}
	}
	return false;
}

bool Tilc::TExtString::ContainsWhiteSpace()
{
	size_t Len = length();
	for (size_t i = 0; i < Len; ++i)
	{
		if (std::isspace(c_str()[i]))
		{
			return true;
		}
	}
	return false;
}

size_t Tilc::TExtString::RemoveCharsWithCodeLessThan(int CharCode)
{
    size_t count = 0;
    size_t len = length();
    char* buf = data();
    for (size_t i = 0; i < len; ++i)
    {
        if (buf[i] < CharCode)
        {
            for (size_t j = i + 1; j < len; ++j)
            {
                buf[j - 1] = buf[j];
            }
            --len;
            ++count;
            --i;
        }
    }
    buf[len] = '\0';

    return count;
}

int Tilc::TExtString::GetUtf8CharLength(size_t pos) const
{
    int Len = 0;
    size_t CurrentLength = length();
    if (IsUtf8StartByte(c_str()[pos]))
    {
        ++Len;
        ++pos;
        while (pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
        {
            ++Len;
            ++pos;
        }
    }
    return Len;
}

int Tilc::TExtString::GetUtf8CharsLength(size_t pos, int NumChars) const
{
    int Len = 0;
    size_t CurrentLength = length();
    if (IsUtf8StartByte(c_str()[pos]))
    {
        ++Len;
        ++pos;
        while (pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
        {
            ++Len;
            ++pos;
        }
        while (NumChars > 1)
        {
            --NumChars;
            ++Len;
            ++pos;
            while (pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
            {
                ++Len;
                ++pos;
            }
        }
    }
    return Len;
}

Tilc::TExtString Tilc::TExtString::GetUtf8Substring(size_t pos, int NumChars) const
{
    Tilc::TExtString Result;
    int Len = 0;
    size_t CurrentLength = length();
    if (IsUtf8StartByte(c_str()[pos]))
    {
        Result.push_back(c_str()[pos]);
        ++Len;
        ++pos;
        while (pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
        {
            Result.push_back(c_str()[pos]);
            ++Len;
            ++pos;
        }
        while (NumChars > 1)
        {
            Result.push_back(c_str()[pos]);
            --NumChars;
            ++Len;
            ++pos;
            while (pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
            {
                Result.push_back(c_str()[pos]);
                ++Len;
                ++pos;
            }
        }
    }
    return Result;
}

int Tilc::TExtString::GetPrecedingUtf8CharsLength(size_t pos, int NumChars) const
{
    int Len = 0;
    size_t CurrentLength = length();
    if (IsUtf8StartByte(c_str()[pos]))
    {
        ++Len;
        --pos;
        while (NumChars > 0)
        {
            --NumChars;
            while (pos >= 0 && pos < CurrentLength && IsUtf8ContinuationByte(c_str()[pos]))
            {
                ++Len;
                --pos;
            }
        }
    }
    return Len;
}

int Tilc::TExtString::TruncateUtf8AtEnd(size_t NumChars)
{
    if (NumChars > 0)
    {
        size_t len = this->length();
        if (NumChars > len) {
            NumChars = len;
        }
        size_t pos = len;
        if (pos > NumChars)
        {
            for (int i = 0; i < NumChars; ++i)
            {
                --pos;
                while (IsUtf8ContinuationByte(c_str()[pos]) && pos > 0)
                {
                    --pos;
                }
            }
        }
        else
        {
            pos = 0;
        }
        if (pos > 0)
        {
            *this = substr(0, pos);
        }
        else
        {
            *this = "";
        }
        return len - length();
    }
    return 0;
}

DECLSPEC long Tilc::DetectDataEncoding(unsigned char* buf, size_t buflen)
{
	if (buflen >= 3 && buf[0] == (unsigned char)0xef && buf[1] == (unsigned char)0xbb && buf[2] == (unsigned char)0xbf) {
		return ENC_UTF8_WITH_BOM;
	}
	unsigned long i;
	bool is_utf8 = true;
	bool is_unicode = true;
	bool is_ansi = true;
	bool is_iso2 = true;
	bool is_oem_852 = true;
	unsigned char b;
	unsigned short w;


	// najpierw sprawdzamy czy UTF8
	for (i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII lub znak końca linii, to pasuje do każdego kodowania
		if (b == (unsigned char)0x0a || b == (unsigned char)0x0d || (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f)) {
			continue;
		}

		// sprawdzaymy czy dopuszczalny znak utf8
		// pobieramy słowo
		w = 0;
		if (i + 1 < buflen) {
			w = buf[i + 1];
			w <<= 8;
			w |= b;
		}

		if (!InArray(allowed_codes_utf8, sizeof(allowed_codes_utf8), w))
		{
			is_utf8 = false;
			break;
		}

		i++;
	}

	if (is_utf8) {
		return ENC_UTF8;
	}


	// sprawdzamy czy UNICODE
	for (i = 0; i < buflen; i += 2) {
		b = buf[i];
		// pobieramy słowo
		w = 0;
		if (i + 1 < buflen) {
			w = buf[i + 1];
			w <<= 8;
			w |= b;
		}

		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (w >= (unsigned short)0x20 && w <= (unsigned short)0x7f) {
			continue;
		}


		if (!InArray(allowed_codes_unicode, sizeof(allowed_codes_unicode), w))
		{
			is_unicode = false;
			break;
		}
	}

	if (is_unicode) {
		return ENC_UNICODE;
	}

	// now we check if have one-unsigned char encoding such as ANSI/ISO2/OEM852
	for (i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f) {
			continue;
		}

		// sprawdzaymy czy dopuszczalny znak ansi
		if (is_ansi) {
			if (!InArray(allowed_codes_ansi, sizeof(allowed_codes_ansi), b))
			{
				is_ansi = false;
			}
		}

		// sprawdzaymy czy dopuszczalny znak ansi
		if (is_iso2) {
			if (!InArray(allowed_codes_iso2, sizeof(allowed_codes_iso2), b))
			{
				is_iso2 = false;
			}
		}

		// sprawdzaymy czy dopuszczalny znak oem_852
		if (is_oem_852) {
			if (!InArray(allowed_codes_oem_852, sizeof(allowed_codes_oem_852), b))
			{
				is_oem_852 = false;
			}
		}

		// jeśli wszystkie kodowania jednobajtowe już odpadły, to nie sprwdzamy dalej
		if (!is_ansi && !is_iso2 && !is_oem_852) {
			break;
		}
	}

	// We accept one-unsigned char encoding in order: ANSI, ISO2, OEM_852
	if (is_ansi) {
		return ENC_ANSI;
	}

	if (is_iso2) {
		return ENC_ISO2;
	}

	if (is_oem_852) {
		return ENC_OEM_852;
	}

	return 0;
}

DECLSPEC void Tilc::Iso2ToAnsi(unsigned char* buf, size_t buflen)
{
	unsigned char b;
	for (unsigned long i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f) {
			continue;
		}

		for (unsigned long k = 0; k < sizeof(allowed_codes_iso2); k++) {
			if (b == allowed_codes_iso2[k]) {
				buf[i] = allowed_codes_ansi[k];
				break;
			}
		}
	}
}

DECLSPEC void Tilc::AnsiToIso2(unsigned char* buf, size_t buflen)
{
	unsigned char b;
	for (unsigned long i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f) {
			continue;
		}

		for (unsigned long k = 0; k < sizeof(allowed_codes_ansi); k++) {
			if (b == allowed_codes_ansi[k]) {
				buf[i] = allowed_codes_iso2[k];
				break;
			}
		}
	}
}

DECLSPEC void Tilc::Oem852ToAnsi(unsigned char* buf, size_t buflen)
{
	unsigned char b;
	for (unsigned long i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f) {
			continue;
		}

		for (unsigned long k = 0; k < sizeof(allowed_codes_oem_852); k++) {
			if (b == allowed_codes_oem_852[k]) {
				buf[i] = allowed_codes_ansi[k];
				break;
			}
		}
	}
}

DECLSPEC void Tilc::AnsiToOem852(unsigned char* buf, size_t buflen)
{
	unsigned char b;
	for (unsigned long i = 0; i < buflen; i++) {
		b = buf[i];
		// jeśli mamy znak ASCII, to pasuje do każdego kodowania
		if (b >= (unsigned char)0x20 && b <= (unsigned char)0x7f) {
			continue;
		}

		for (unsigned long k = 0; k < sizeof(allowed_codes_ansi); k++) {
			if (b == allowed_codes_ansi[k]) {
				buf[i] = allowed_codes_oem_852[k];
				break;
			}
		}
	}
}

DECLSPEC bool Tilc::CharIsSentenceBoundary(wchar_t ch) {
	if (wcschr(WORD_BOUNDARY_CHARS, ch) != nullptr) {
		return true;
	}

	return false;
}

DECLSPEC bool Tilc::IsDecimal(const wchar_t* str) {
	if (!str) return false;

	size_t len = wcslen(str);
	if (len < 1) return false;

	for (size_t i = 0; i < len; i++) {
		if (i == 0 && str[i] == L'-') {
			continue;
		}

		if (!iswdigit(str[i])) {
			return false;
		}
	}

	return true;
}

DECLSPEC bool Tilc::IsDouble(const wchar_t* str) {
	if (!str) return false;

	size_t len = wcslen(str);
	bool hasDot = false;
	wchar_t ch;

	if (len < 1) return false;

	for (size_t i = 0; i < len; i++) {
		ch = str[i];

		if (i == 0 && ch == L'-') {
			continue;
		}

		if (!hasDot && (ch == L'.' || ch == L',')) {
			hasDot = true;
			continue;
		}

		if (!iswdigit(ch)) {
			return false;
		}
	}

	return true;
}

DECLSPEC Tilc::TExtString Tilc::GetRandomString(int DesiredLength, const char* Chars)
{
    /*
    auto d = std::uniform_int_distribution<>{ 0, static_cast<int>(strlen(Chars)) - 1 };
    auto random_char = [&] { return Chars[d(RandomGenerator)]; };
    auto s = std::string(DesiredLength, '\0');
    std::ranges::generate(s, random_char); // Requires C++20
    return s;
    */
	if (strlen(Chars) == 0)
	{
    	Chars = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM!@#$%^&*()-=_+[]{};:\'\"\\|,<.>/?";
	}
    size_t Len = strlen(Chars);
    Tilc::TExtString Result;
    for (int i = 0; i < DesiredLength; ++i)
    {
        Result.push_back(Chars[rand() % Len]);
    }
    return Result;
}


DECLSPEC Tilc::TExtString Tilc::Implode(char Implodechar, std::vector<int>& Items)
{
	Tilc::TExtString Result;
	for (int i = 0; i < Items.size(); i++)
	{
		Result += std::to_string(Items[i]);
		if (i < Items.size() - 1)
		{
			Result += Implodechar;
		}
	}
	return Result;
}

DECLSPEC Tilc::TExtString Tilc::Implode(char ImplodeChar, std::initializer_list<const char*>& Items)
{
    Tilc::TExtString Result;
    for (auto it = Items.begin(); it != Items.end(); ++it)
    {
        if (it != Items.begin())
        {
            Result.push_back(ImplodeChar);
        }
        Result.append(*it);
    }
    return Result;
}

DECLSPEC Tilc::TExtString Tilc::Implode(char ImplodeChar, std::vector<Tilc::TExtString>& Items)
{
    Tilc::TExtString Result;
    for (int i = 0; i < Items.size(); ++i)
    {
        Result.append(Items[i]);
        if (i < Items.size() - 1)
        {
            Result.push_back(ImplodeChar);
        }
    }
    return Result;
}

DECLSPEC Tilc::TExtString Tilc::ImplodeRepeatedString(char ImplodeChar, const char* RepeatString, int Count)
{
    Tilc::TExtString Result;
    for (int i = 0; i < Count; ++i)
    {
        Result.append(RepeatString);
        if (i < Count - 1)
        {
            Result.push_back(ImplodeChar);
        }
    }
    return Result;
}

DECLSPEC Tilc::TExtString Tilc::IntToHex(uint64_t num, size_t minHexNumberLength, bool useSmallAlpha, bool prependx0)
{
    Tilc::TExtString retval;
    const char* smallAlpha = "abcdef";
    const char* largeAlpha = "ABCDEF";
    const char* usedAlpha;
    if (useSmallAlpha)
    {
        usedAlpha = smallAlpha;
    }
    else
    {
        usedAlpha = largeAlpha;
    }

    // jeśliminHexNumberLength jest liczbą nieparzystą, to zwiększamy go o 1, żeby ilość
    // wyświetlanych cyfr była parzysta
    if (minHexNumberLength % 2)
    {
        minHexNumberLength += 1;
    }

    uint64_t len = sizeof(uint64_t) * 8; // rozmiar LONGLONG-a w bitach
    uint64_t numCompare = len / 4;   // porównujemy łańcuchy 4-bitowe, numCompare zawiera ilość tych
    // porównań
    int64_t mask = 0x0f; // maska wskazuje najpierw najmłodsze 4 bity
    int64_t out;
    for (uint64_t i = 0; i < numCompare; i++)
    {
        out = num & mask;
        out >>= i * 4;
        if (out < 10)
        {
            retval = std::to_string(out) + retval;
        }
        else
        {
            out -= 10;
            retval = usedAlpha[out] + retval;
        }
        // przesuwamy maskę o 4 bity w lewo
        mask <<= 4;
    }

    // usuwamy początkowe zera
    retval.LTrim('0');

    // jeśli minimalna długość łańcucha jest większa od aktualnej, to paddujemy łańcuch 0-ami
    // z lewej strony
    size_t padCount = 0;
    size_t retval_len = retval.length();
    if (minHexNumberLength >= retval_len)
    {
        padCount = minHexNumberLength - retval_len;
    }
    while (padCount > 0)
    {
        retval = "0" + retval;
        --padCount;
    }

    if (prependx0)
    {
        retval = "0x" + retval;
    }

    return retval;
}

DECLSPEC int Tilc::HexToInt(const Tilc::TExtString& hex)
{
    size_t StartFrom{ 0 };
    size_t len = hex.length();
    if (len < 1)
    {
        return 0;
    }
    size_t End{ len - 1 };

    const char* buf = hex.data();
    if (buf[len - 1] == 'h')
    {
        --End;
    }

    if (len == 0)
    {
        return 0;
    }

    if (buf[0] == '#')
    {
        StartFrom = 1;
    }

    if (len - StartFrom == 0)
    {
        return 0;
    }

    if (buf[StartFrom] == '0' && buf[StartFrom+1] == 'x')
    {
        StartFrom += 2;
    }

    if (len - StartFrom == 0)
    {
        return 0;
    }

    int retval{ 0 };
    buf = hex.data();
    int count{ 0 };
    int maxcount = sizeof(int) << 1;
    char c;
    int b;
    for (int i = (int)End; i >= (int)StartFrom; --i)
    {
        c = buf[i];
        if (c >= 0x30 && c <= 0x39)
        {
            b = (int)(c - 0x30);
        }
        else
        {
            if (c == 'a' || c == 'A')
            {
                b = 10;
            }
            else if (c == 'b' || c == 'B')
            {
                b = 11;
            }
            else if (c == 'c' || c == 'C')
            {
                b = 12;
            }
            else if (c == 'd' || c == 'D')
            {
                b = 13;
            }
            else if (c == 'e' || c == 'E')
            {
                b = 14;
            }
            else if (c == 'f' || c == 'F')
            {
                b = 15;
            }
            else
            {
                return 0;
            }
        }
        retval = retval | (b << (count * 4));
        ++count;
        if (count == maxcount)
        {
            break;
        }
    }

    return retval;
}

DECLSPEC char32_t Tilc::DecodeUtf8(const char*& p, const char* end)
{
    unsigned char c = *p++;

    if (c < 0x80) return c;

    if ((c >> 5) == 0x6)
    {
        if (p >= end) return U'?';
        return ((c & 0x1F) << 6) | (*(p++) & 0x3F);
    }

    if ((c >> 4) == 0xE)
    {
        if (p + 1 >= end) return U'?';
        char32_t r = ((c & 0x0F) << 12);
        r |= ((*p++ & 0x3F) << 6);
        r |= (*p++ & 0x3F);
        return r;
    }

    if ((c >> 3) == 0x1E)
    {
        if (p + 2 >= end) return U'?';
        char32_t r = ((c & 0x07) << 18);
        r |= ((*p++ & 0x3F) << 12);
        r |= ((*p++ & 0x3F) << 6);
        r |= (*p++ & 0x3F);
        return r;
    }

    return U'?';
}

DECLSPEC void Tilc::EncodeUtf8(uint32_t cp, TExtString& out)
{
    if (cp <= 0x7F) {
        out.push_back(static_cast<char>(cp));
    }
    else if (cp <= 0x7FF) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
    else if (cp <= 0xFFFF) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
    else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

DECLSPEC std::u32string Tilc::Utf8ToUtf32(const TExtString& s)
{
    std::u32string out;
    const char* p = s.data();
    const char* end = p + s.size();

    while (p < end)
    {
        out.push_back(DecodeUtf8(p, end));
    }

    return out;
}

DECLSPEC std::u16string Tilc::Utf32ToUtf16(const std::u32string& s)
{
    std::u16string out;
    for (char32_t cp : s)
    {
        if (cp <= 0xFFFF)
        {
            out.push_back(static_cast<char16_t>(cp));
        }
        else
        {
            cp -= 0x10000;
            out.push_back(static_cast<char16_t>(0xD800 + (cp >> 10)));
            out.push_back(static_cast<char16_t>(0xDC00 + (cp & 0x3FF)));
        }
    }
    return out;
}

DECLSPEC Tilc::TExtString Tilc::Utf16ToUtf8(const std::u16string& s)
{
    Tilc::TExtString out;
    out.reserve(s.size()); // minimalne, i tak się rozszerzy

    for (size_t i = 0; i < s.size(); ++i)
    {
        uint16_t w1 = s[i];

        // Para surogatowa?
        if (w1 >= 0xD800 && w1 <= 0xDBFF)
        {
            if (i + 1 < s.size())
            {
                uint16_t w2 = s[i + 1];
                if (w2 >= 0xDC00 && w2 <= 0xDFFF)
                {
                    uint32_t cp = 0x10000
                            + (((w1 - 0xD800) << 10)
                            | (w2 - 0xDC00));
                    EncodeUtf8(cp, out);
                    ++i; // zużyliśmy dwa
                    continue;
                }
            }
            // Niepoprawna para — zakoduj U+FFFD
            EncodeUtf8(0xFFFD, out);
        }
        else if (w1 >= 0xDC00 && w1 <= 0xDFFF)
        {
            // Samotny surogat dolny — błąd
            EncodeUtf8(0xFFFD, out);
        }
        else
        {
            // BMP
            EncodeUtf8(w1, out);
        }
    }

    return out;
}

DECLSPEC Tilc::TExtString Tilc::Utf32ToUtf8(const std::u32string& s)
{
    return Utf16ToUtf8(Utf32ToUtf16(s));
}

DECLSPEC Tilc::TExtString Tilc::SlowTrzy(int i)
{
    Tilc::TExtString tmp;
    Tilc::TExtString licz;

    //Jeśli błędna wartość nic nie rób
    if (i > 999 || i < 0)
    {
        return "";
    }

    //jeśli zero, to zwróć >>zero<<
    if (i == 0)
    {
        return "zero";
    }

    licz = std::to_string(i);
    // Ustaw tak wartość zmiennej licz, aby zawsze była 3-cyfrowa
    switch (licz.length())
    {
        case 1:
            licz = "00" + licz;
            break;
        case 2:
            licz = "0" + licz;
            break;
        default:
            break;
    }//switch
    tmp = "";

    // Ustal ilość setek i wpisz odpowiednią nazwę do zmiennej tmp
    if (licz[0] == '1')   tmp = "sto";
    else if (licz[0] == '2')   tmp = "dwieście";
    else if (licz[0] == '3')   tmp = "trzysta";
    else if (licz[0] == '4')   tmp = "czterysta";
    else if (licz[0] == '5')   tmp = "pięćset";
    else if (licz[0] == '6')   tmp = "sześćset";
    else if (licz[0] == '7')   tmp = "siedemset";
    else if (licz[0] == '8')   tmp = "osiemset";
    else if (licz[0] == '9')   tmp = "dziewięćset";
    else if (licz[0] == '0')   tmp = "";
    // Jeśli tmp nie jest już puste, to na końcu dopisz spację
    if (tmp != "") tmp += " ";

    // Ustal ilość dziesiątek i dopisz odpowiednią ilość dziesiątek do tmp
    if (licz[1] == '1')
    {
        //dla 1 dziesiątki będą brzmieć inaczej :
        if (licz[2] == '0') tmp += "dziesięć";
        else if (licz[2] == '1') tmp += "jedenaście";
        else if (licz[2] == '2') tmp += "dwanaście";
        else if (licz[2] == '3') tmp += "trzynaście";
        else if (licz[2] == '4') tmp += "czternaście";
        else if (licz[2] == '5') tmp += "piętnaście";
        else if (licz[2] == '6') tmp += "szesnaście";
        else if (licz[2] == '7') tmp += "siedemnaście";
        else if (licz[2] == '8') tmp += "osiemnaście";
        else if (licz[2] == '9') tmp += "dziewiętnaście";
        return tmp;
    }//if
    else if (licz[1] == '2') tmp += "dwadzieścia";
    else if (licz[1] == '3') tmp += "trzydzieści";
    else if (licz[1] == '4') tmp += "czterdzieści";
    else if (licz[1] == '5') tmp += "pięćdziesiąt";
    else if (licz[1] == '6') tmp += "sześćdziesiąt";
    else if (licz[1] == '7') tmp += "siedemdziesiąt";
    else if (licz[1] == '8') tmp += "osiemdziesiąt";
    else if (licz[1] == '9') tmp += "dziewięćdziesiąt";
    else if (licz[1] == '0') tmp += "";

    // Jeśli tmp nie jest puste i nie kończy się spacją, to dopisz spację
    if (tmp != "" && tmp[2] != '0')
    {
        tmp += " ";
    }
    // Ustal cyfrę jedności
    if (licz[2] == '1')  tmp += "jeden";
    else if (licz[2] == '2')  tmp += "dwa";
    else if (licz[2] == '3')  tmp += "trzy";
    else if (licz[2] == '4')  tmp += "cztery";
    else if (licz[2] == '5')  tmp += "pięć";
    else if (licz[2] == '6')  tmp += "sześć";
    else if (licz[2] == '7')  tmp += "siedem";
    else if (licz[2] == '8')  tmp += "osiem";
    else if (licz[2] == '9')  tmp += "dziewięć";
    else if (licz[2] == '0')  tmp += "";

    // Usuń początkowe i końcowe spacje
    tmp.Trim();

    return tmp;
}// SlowTrzy

//---------------------------------------------------------------------------
// Zamienia ona liczbę na jej wyrażenie słowne
DECLSPEC Tilc::TExtString Tilc::SlowSzesc(int i)
{
    Tilc::TExtString tmp;
    Tilc::TExtString licz;
    Tilc::TExtString result;
    Tilc::TExtString pom;

    if (i < 0 || i > 999999)
    {
        return "";
    }

    if (i == 0)
    {
        return "zero";
    }

    licz = std::to_string(i);
    // zadbaj, aby liczba była sześciocyfrowa
    switch (licz.length())
    {
    case 1:
        licz = "00000" + licz;
        break;
    case 2:
        licz = "0000" + licz;
        break;
    case 3:
        licz = "000" + licz;
        break;
    case 4:
        licz = "00" + licz;
        break;
    case 5:
        licz = "0" + licz;
        break;
    default:
        break;
    }//switch

    // Ustal ilość tysięcy
    pom = licz.substr(0, 3);
    tmp = SlowTrzy(std::atoi(pom.c_str()));
    if (tmp == "" || tmp == "zero")
    {
        tmp = "";
    }
    else
    {
        if (pom[1] != '1' && (pom[2] == '2' || pom[2] == '3' || pom[2] == '4'))
        {
            tmp += " tysiące";
        }
        else if (tmp == "jeden")
        {
            tmp = "tysiąc";
        }//else if
        else
        {
            tmp += " tysięcy";
        }
    }//else

    result = tmp;
    // Jeśli result nie jest pusty, to dodaj spację na końcu
    if (result != "")
    {
        result += " ";
    }
    // Ustal pozostałą ilość
    tmp = SlowTrzy(std::atoi(licz.substr(3, 3).c_str()));
    if (tmp == "" || tmp == "zero")
    {
        tmp = "";
    }
    result += tmp;
    result.Trim();
    return result;
}// SlowSzesc

//---------------------------------------------------------------------------
DECLSPEC Tilc::TExtString Tilc::SlowDziewiec(int i)
{
    Tilc::TExtString tmp;
    Tilc::TExtString licz;
    Tilc::TExtString result;
    Tilc::TExtString pom;

    if (i < 0 || i > 999999999)
    {
        return "";
    }

    if (i == 0)
    {
        return "zero";
    }

    result = "";
    tmp = "";
    licz = std::to_string(i);

    // zadbaj, aby liczba była dziewięciocyfrowa
    switch (licz.length())
    {
    case 1:
        licz = "00000000" + licz;
        break;
    case 2:
        licz = "0000000" + licz;
        break;
    case 3:
        licz = "000000" + licz;
        break;
    case 4:
        licz = "00000" + licz;
        break;
    case 5:
        licz = "0000" + licz;
        break;
    case 6:
        licz = "000" + licz;
        break;
    case 7:
        licz = "00" + licz;
        break;
    case 8:
        licz = "0" + licz;
        break;
    default:
        break;
    }//switch

    // Ustal ilość tysięcy
    pom = licz.substr(0, 3);
    tmp = SlowTrzy(std::atoi(pom.c_str()));

    if (tmp == "" || tmp == "zero")
    {
        tmp = "";
    }
    else
    {
        if (pom[1] != '1' && (pom[2] == '2' || pom[2] == '3' || pom[2] == '4'))
        {
            tmp += " miliony";
        }
        else if (tmp == "jeden")
        {
            tmp = "milion";
        }
        else
        {
            tmp += " milionów";
        }
    }

    result = tmp;
    // Jeśli result nie jest pusty, to dodaj spację na końcu
    if (result != "")
    {
        result += " ";
    }
    // Ustal pozostałą ilość
    pom = licz.substr(3, 3);
    tmp = SlowTrzy(std::atoi(pom.c_str()));

    if (tmp == "" || tmp == "zero")
    {
        tmp = "";
    }
    else
    {
        if (pom[1] != '1' && (pom[2] == '2' || pom[2] == '3' || pom[2] == '4'))
        {
            tmp += " tysiące";
        }
        else if (tmp == "jeden")
        {
            tmp = "tysiąc";
        }//else if
        else
            tmp += " tysięcy";
    }
    result += tmp;

    // Jeśli result nie jest pusty, to dodaj spację na końcu
    if (result != "")
    {
        result += " ";
    }

    // Ustal pozostałą ilość
    tmp = SlowTrzy(std::atoi(licz.substr(6, 3).c_str()));
    if (tmp == "" || tmp == "zero")
    {
        tmp = "";
    }
    result += tmp;
    result.Trim();
    return result;
}// SlowDziewiec


DECLSPEC Tilc::TExtString Tilc::FormatString(const Tilc::TExtString& s, int align, char fillChar, int width)
{
    Tilc::TExtString result(s);
    size_t len = result.length();

    if (width > 0 && width > len)
    {
        int paddingLen = static_cast<int>(width - len);
        Tilc::TExtString padding = Tilc::TExtString(paddingLen, fillChar);
        if (align == Tilc::FORMAT_ALIGN_RIGHT)
        {
            result.Prepend(padding);
        }
        else
        {
            result.append(padding);
        }
    }

    return result;
}

DECLSPEC Tilc::TExtString Tilc::FormatHexValue(int value, int align, char fillChar, int width, bool prepend0x, bool appendH, bool useSmallAlpha, int minLen)
{
    Tilc::TExtString result = IntToHex(value, minLen, useSmallAlpha, prepend0x);
    if (appendH)
    {
        result += 'h';
    }
    return FormatString(result, align, fillChar, width);
}
