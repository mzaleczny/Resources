#include <stdio.h>

int main()
{
    printf("Test Emcripten\n");
    return 0;
}
