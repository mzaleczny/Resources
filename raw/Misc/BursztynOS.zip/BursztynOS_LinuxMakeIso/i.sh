#!/bin/bash

rm -f BursztynOS.iso
grub-mkrescue -o BursztynOS.iso isodir -R -J -joliet-long
rm -rf isodir

