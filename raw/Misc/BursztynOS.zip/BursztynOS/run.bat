qemu-system-x86_64 ^
  -cdrom BursztynOS.iso ^
  -drive id=disk,file=wirtualny_dysk.img,format=raw,if=none ^
  -device ahci,id=ahci ^
  -device ide-hd,drive=disk,bus=ahci.0 ^
  -m 2G ^
  -serial stdio
