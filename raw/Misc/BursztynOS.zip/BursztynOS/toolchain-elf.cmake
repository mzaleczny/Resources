set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR x86_64)

# Wyłączamy całe środowisko Windows/MSVC
set(CMAKE_C_COMPILER "C:/cross/bin/x86_64-elf-gcc.exe")
set(CMAKE_CXX_COMPILER "C:/cross/bin/x86_64-elf-g++.exe")
set(CMAKE_ASM_COMPILER C:/cross/bin/x86_64-elf-as.exe)
set(LD_EXECUTABLE C:/cross/bin/x86_64-elf-ld.exe)
set(OBJCOPY_EXECUTABLE C:/cross/bin/x86_64-elf-objcopy.exe)

set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

# CMake nie może dodawać żadnych flag Windowsowych
set(CMAKE_C_FLAGS "")
set(CMAKE_CXX_FLAGS "")
set(CMAKE_EXE_LINKER_FLAGS "")
