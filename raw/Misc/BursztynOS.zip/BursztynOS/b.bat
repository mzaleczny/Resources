@echo off

cls
cmake --build out --config Release
REM cmake --install out

copy out\kalkulator.bin isodir\boot\
copy out\menedzer_okien.bin isodir\boot\
copy out\notatnik.bin isodir\boot\
copy out\shell.bin isodir\boot\
copy out\system_operacyjny.bin isodir\boot\
