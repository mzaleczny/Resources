@echo off

cls
rmdir /S /Q out
mkdir out
cmake -G Ninja -DCMAKE_TOOLCHAIN_FILE=toolchain-elf.cmake ^
  -DCMAKE_C_COMPILER=clang ^
  -DCMAKE_CXX_COMPILER=clang++ ^
  -DCMAKE_CXX_STANDARD=26 ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_INSTALL_PREFIX="d:/bur" ^
  -DCMAKE_PREFIX_PATH="d:/bur" ^
  -S . -B out
