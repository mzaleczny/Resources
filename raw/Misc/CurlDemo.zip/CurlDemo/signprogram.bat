signtool sign /n "Nazwa naszej jednostki dla certyfikatu" /t http://time.certum.pl/ /fd sha256 /v CurlDemo.exe
