clang++ -std=c++26 CurlDemoHttps.cpp -o CurlDemoHttps.exe -I.\curl-8.21.0_6-win64-mingw\include .\curl-8.21.0_6-win64-mingw\bin\libcurl-x64.lib
