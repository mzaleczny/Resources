lib /def:.\curl-8.21.0_6-win64-mingw\bin\libcurl-x64.def /out:.\curl-8.21.0_6-win64-mingw\bin\libcurl-x64.lib /machine:x64
