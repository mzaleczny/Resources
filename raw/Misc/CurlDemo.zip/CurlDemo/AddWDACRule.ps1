# 1) Utwórz katalog na politykę
New-Item -ItemType Directory -Path "C:\WDAC" -Force

# 2) Wygeneruj politykę dopuszczającą konkretny plik
New-CIPolicy -Level File -FilePath "C:\WDAC\policy.xml" -UserPEs "d:\sources\CurlDemo\CurlDemoHttps.exe"

# 3) Konwersja polityki do formatu binarnego
ConvertFrom-CIPolicy "C:\WDAC\policy.xml" "C:\WDAC\policy.bin"

# 4) Instalacja polityki WDAC
Copy-Item "C:\WDAC\policy.bin" "C:\Windows\System32\CodeIntegrity\SIPolicy.p7b" -Force

# 5) Restart systemu wymagany
Write-Host "Polityka WDAC zainstalowana. Uruchom ponownie komputer."
